import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Typography, Tag, Avatar, Button, Modal, Form, Input, Upload, Space, Empty, Spin, Tabs, Table, Tooltip as AntTooltip, Statistic, Select, Divider } from 'antd';
import { 
  ClockCircleOutlined, UserOutlined, FileTextOutlined, UploadOutlined, DashboardOutlined, SyncOutlined, 
  CalendarOutlined, HourglassOutlined, PlusCircleOutlined, CheckSquareOutlined, PrinterOutlined, 
  EditOutlined, BarChartOutlined, AppstoreOutlined, FireOutlined, DollarCircleOutlined, AlertOutlined,
  ThunderboltOutlined, InfoCircleOutlined, TagOutlined
} from '@ant-design/icons';
import { PieChart, Pie, Cell, Tooltip as RechartsTooltip, ResponsiveContainer, Legend } from 'recharts';
import { Link } from 'react-router-dom';
import axios from 'axios';
import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';
import 'dayjs/locale/th';
import { alertSuccess, alertError } from '../utils/alert';

dayjs.extend(duration);
dayjs.locale('th');

const { Title, Text, Paragraph } = Typography;
const { TextArea } = Input;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000';
const CHART_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

const AnimatedNumber = ({ value, isCurrency = false }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const end = parseInt(value, 10) || 0;
    if (end === 0) {
      setCount(0);
      return;
    }
    
    const durationObj = 800; 
    const incrementTime = Math.max(durationObj / end, 20);
    const step = Math.max(Math.ceil(end / (durationObj / incrementTime)), 1);

    const timer = setInterval(() => {
      start += step;
      if (start >= end) {
        clearInterval(timer);
        setCount(end);
      } else {
        setCount(start);
      }
    }, incrementTime);

    return () => clearInterval(timer);
  }, [value]);

  return <span>{isCurrency ? count.toLocaleString() : count}</span>;
};

export default function TicketDashboard({ project }) {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('1'); 
  
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [fileList, setFileList] = useState([]);
  const [form] = Form.useForm();

  const [now, setNow] = useState(dayjs());
  const [selectedPeriod, setSelectedPeriod] = useState('all');
  const [availablePeriods, setAvailablePeriods] = useState([]);
  const [slaStats, setSlaStats] = useState({ totalCM: 0, activeCM: [], breachedCount: 0, totalPenalty: 0 });

  const currentUser = JSON.parse(localStorage.getItem('lims_user')) || { user_id: 1, first_name: 'User', role: 'admin' };

  useEffect(() => {
    const timer = setInterval(() => setNow(dayjs()), 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const ticketRes = await axios.get(`${BACKEND_URL}/api/tickets`, { params: { project_id: project?.project_id } });
      const data = ticketRes.data || [];
      setTickets(data);

      // ✅ แก้บัคโดยการใช้ Number() แปลงค่าให้ชัวร์
      const cmData = data.filter(t => Number(t.is_cm) === 1);
      const periods = [...new Set(cmData.map(t => dayjs(t.created_at).format('YYYY-MM')))].sort((a,b) => b.localeCompare(a));
      setAvailablePeriods(periods);
      
      const currentMonth = dayjs().format('YYYY-MM');
      if (periods.includes(currentMonth) && selectedPeriod === 'all') {
        setSelectedPeriod(currentMonth);
      }

    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูลแดชบอร์ดได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [project]);

  useEffect(() => {
    const cmTickets = tickets.filter(t => Number(t.is_cm) === 1);
    let filteredCM = cmTickets;

    if (selectedPeriod !== 'all') {
      filteredCM = cmTickets.filter(t => dayjs(t.created_at).format('YYYY-MM') === selectedPeriod);
    }

    const activeCM = filteredCM.filter(t => !['Resolved', 'Closed'].includes(t.status));
    const breachedCount = filteredCM.filter(t => t.is_sla_breached === 1).length;
    const penaltySum = filteredCM.reduce((sum, t) => sum + (parseFloat(t.penalty_amount) || 0), 0);

    setSlaStats({ totalCM: filteredCM.length, activeCM, breachedCount, totalPenalty: penaltySum });
  }, [tickets, selectedPeriod]);

  const today = dayjs().format('YYYY-MM-DD');
  const currentMonth = dayjs().format('YYYY-MM');

  // ✅ เพิ่มฟิลด์ bgIcon และ anim สำหรับลูกเล่นไอคอนพื้นหลัง
  const stats = [
    { title: 'ใบงานทั้งหมด', value: tickets.length, bg: 'linear-gradient(135deg, #60a5fa 0%, #2563eb 100%)', shadow: 'rgba(59, 130, 246, 0.4)', icon: <FileTextOutlined />, bgIcon: <AppstoreOutlined />, anim: '' },
    { title: 'ใบงานเดือนนี้', value: tickets.filter(t => t.created_at?.startsWith(currentMonth)).length, bg: 'linear-gradient(135deg, #34d399 0%, #059669 100%)', shadow: 'rgba(16, 185, 129, 0.4)', icon: <CalendarOutlined />, bgIcon: <CalendarOutlined />, anim: 'icon-float' },
    { title: 'กำลังดำเนินการ', value: tickets.filter(t => t.status === 'Pending' || t.status === 'In Progress').length, bg: 'linear-gradient(135deg, #fbbf24 0%, #d97706 100%)', shadow: 'rgba(245, 158, 11, 0.4)', icon: <HourglassOutlined />, bgIcon: <SyncOutlined />, anim: 'icon-spin-slow' },
    { title: 'รอตรวจ / ปิดเคส', value: tickets.filter(t => t.status === 'Resolved' || t.status === 'Closed').length, bg: 'linear-gradient(135deg, #a78bfa 0%, #7c3aed 100%)', shadow: 'rgba(139, 92, 246, 0.4)', icon: <CheckSquareOutlined />, bgIcon: <CheckSquareOutlined />, anim: '' },
    { title: 'เปิดใหม่วันนี้', value: tickets.filter(t => t.created_at?.startsWith(today)).length, bg: 'linear-gradient(135deg, #f472b6 0%, #db2777 100%)', shadow: 'rgba(236, 72, 153, 0.4)', icon: <PlusCircleOutlined />, bgIcon: <PlusCircleOutlined />, anim: 'icon-pulse' },
    { title: 'อัปเดตวันนี้', value: tickets.filter(t => t.updated_at?.startsWith(today)).length, bg: 'linear-gradient(135deg, #2dd4bf 0%, #0d9488 100%)', shadow: 'rgba(20, 184, 166, 0.4)', icon: <SyncOutlined />, bgIcon: <ClockCircleOutlined />, anim: 'icon-spin-normal' },
  ];

  const boardColumns = [
    { id: 'Pending', title: 'รอดำเนินการ', color: '#ef4444', bgColor: '#fef2f2', borderColor: '#fecaca' },
    { id: 'In Progress', title: 'กำลังดำเนินการ', color: '#f59e0b', bgColor: '#fffbeb', borderColor: '#fde68a' },
    { id: 'Resolved', title: 'รอตรวจสอบ', color: '#3b82f6', bgColor: '#eff6ff', borderColor: '#bfdbfe' },
    { id: 'Closed', title: 'ปิดเคสสมบูรณ์', color: '#22c55e', bgColor: '#f0fdf4', borderColor: '#bbf7d0' }
  ];

  const handleOpenUpdateModal = (ticket) => {
    setSelectedTicket(ticket);
    setFileList([]);
    form.resetFields();
    setIsModalVisible(true);
  };

  const handleUpdateStatus = async (values) => {
    const formData = new FormData();
    formData.append('status', 'Resolved'); 
    formData.append('technician_id', currentUser.user_id);
    if (values.root_cause_and_solution) formData.append('root_cause_and_solution', values.root_cause_and_solution);

    fileList.forEach(file => formData.append('attachments', file.originFileObj));

    try {
      const res = await axios.put(`${BACKEND_URL}/api/tickets/${selectedTicket.ticket_id}/update-status`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setIsModalVisible(false);
      if (res.data.is_breached) alertError('ปิดงานล่าช้า!', res.data.message);
      else alertSuccess('ส่งตรวจสำเร็จ', 'ส่งให้ผู้แจ้งตรวจสอบเรียบร้อยแล้ว!');
      fetchData(); 
    } catch (error) {
      alertError('ผิดพลาด', 'เกิดข้อผิดพลาดในการอัปเดตสถานะ');
    }
  };

  const uploadProps = {
    onRemove: (file) => setFileList(prev => prev.filter(item => item.uid !== file.uid)),
    beforeUpload: (file) => { setFileList(prev => [...prev, file]); return false; },
    fileList,
  };

const renderSLATimer = (ticket) => {
    if (Number(ticket.is_cm) !== 1) return <Tag color="default" icon={<TagOutlined />}>ไม่นับ SLA</Tag>;

    // 🌟 1. เงื่อนไขใหม่: จับเวลา 2 ชม. สำหรับการเข้าดำเนินการ (รอกดรับงาน)
    if (ticket.status === 'Pending' && ['Hardware', 'Software'].includes(ticket.category_type)) {
      const ackDeadline = dayjs(ticket.created_at).add(2, 'hour'); // บวกไป 2 ชั่วโมงจากเวลาแจ้ง
      const diff = ackDeadline.diff(now);

      if (diff <= 0) return <span style={{ color: '#ef4444', fontWeight: 'bold', fontSize: 12, animation: 'pulse-alert 1.5s infinite', display: 'inline-flex', alignItems: 'center', gap: 4 }}><FireOutlined /> เกินเวลาเข้าดำเนินการ!</span>;

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const mins = Math.floor((diff / (1000 * 60)) % 60);
      const secs = Math.floor((diff / 1000) % 60);
      const timeString = `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

      return (
        <span style={{ color: '#f59e0b', fontWeight: 'bold', fontSize: 12, display: 'inline-flex', alignItems: 'center', gap: '4px', background: '#f59e0b15', padding: '2px 8px', borderRadius: '12px', border: '1px solid #f59e0b40' }}>
          <ClockCircleOutlined className="icon-spin-normal" /> รอดำเนินการ ({timeString})
        </span>
      );
    }

    // 🌟 2. เงื่อนไขเดิม: ใบงานถูกปิดไปแล้ว
    if (ticket.status === 'Resolved' || ticket.status === 'Closed') {
      if (ticket.is_sla_breached === 1) {
        return (
          <AntTooltip title={`ค่าปรับ: ${parseFloat(ticket.penalty_amount).toLocaleString()} ฿`}>
            <Tag color="red" style={{ margin: 0, borderRadius: 6, fontSize: 11, padding: '2px 6px' }}>
              ปรับ {parseFloat(ticket.penalty_amount).toLocaleString()}
            </Tag>
          </AntTooltip>
        );
      }
      return <Tag color="green" style={{ margin: 0, borderRadius: 6, fontSize: 11, padding: '2px 6px' }} icon={<CheckSquareOutlined />}>ทันเวลา</Tag>;
    }

    // 🌟 3. เงื่อนไขเดิม: กำลังดำเนินการ (นับเวลาไปจนถึง SLA Deadline รวม)
    if (!ticket.sla_deadline) return <Tag color="warning" icon={<HourglassOutlined spin />}>รอระบบจับเวลา</Tag>;

    const deadline = dayjs(ticket.sla_deadline);
    const diff = deadline.diff(now);

    if (diff <= 0) return <span style={{ color: '#ef4444', fontWeight: 'bold', fontSize: 12, animation: 'pulse-alert 1.5s infinite', display: 'inline-flex', alignItems: 'center', gap: 4 }}><FireOutlined /> เกินเวลา!</span>;

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff / (1000 * 60)) % 60);
    const secs = Math.floor((diff / 1000) % 60);
    const timeString = `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

    let color = '#10b981';
    let iconClass = 'icon-spin-slow';
    
    if (hours < 1) {
      color = '#ef4444';
      iconClass = 'icon-spin-fast';
    } else if (hours < 2) {
      color = '#f59e0b';
      iconClass = 'icon-spin-normal';
    }

    return (
      <span style={{ color: color, fontWeight: 'bold', fontSize: 12, display: 'inline-flex', alignItems: 'center', gap: '4px', background: `${color}15`, padding: '2px 8px', borderRadius: '12px', border: `1px solid ${color}40` }}>
        <ClockCircleOutlined className={iconClass} /> {timeString}
      </span>
    );
  };

  const TicketCard = ({ ticket, colorTheme }) => (
    <div 
      style={{ 
        marginBottom: 12, borderRadius: 10, backgroundColor: '#fff', borderLeft: `4px solid ${colorTheme}`, 
        boxShadow: '0 2px 6px rgba(0,0,0,0.04)', padding: '12px', transition: 'all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)', cursor: 'pointer'
      }}
      onMouseEnter={(e) => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = `0 6px 12px rgba(0,0,0,0.08), 0 0 8px ${colorTheme}20`; }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = '0 2px 6px rgba(0,0,0,0.04)'; }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6, gap: '6px' }}>
        <Text strong style={{ fontSize: 14, color: '#1e293b', flexShrink: 0 }}>{ticket.ticket_number}</Text>
        <AntTooltip title={ticket.category_name || 'ทั่วไป'} placement="topRight">
          <Tag color={colorTheme} style={{ borderRadius: 6, margin: 0, maxWidth: '100px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 11, padding: '0 6px' }}>
            {ticket.category_name || 'ทั่วไป'}
          </Tag>
        </AntTooltip>
      </div>
      
      <Paragraph ellipsis={{ rows: 1 }} type="secondary" style={{ marginBottom: 8, fontSize: 12, color: '#64748b' }}>
        {ticket.problem_detail}
      </Paragraph>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: currentUser.role !== 'user' ? 8 : 0 }}>
        <Space size={4}>
          <Avatar size={18} style={{ backgroundColor: '#f1f5f9', color: '#64748b' }} icon={<UserOutlined />} />
          <Text type="secondary" style={{ fontSize: 11, maxWidth: 70 }} ellipsis={{ tooltip: ticket.reporter_name }}>{ticket.reporter_name}</Text>
        </Space>
        {renderSLATimer(ticket)}
      </div>
      
      {currentUser.role !== 'user' && ticket.status === 'In Progress' && ticket.assigned_to === currentUser.user_id && (
        <Button type="dashed" size="small" block style={{ borderRadius: 6, borderColor: colorTheme, color: colorTheme, marginBottom: 6 }} onClick={() => handleOpenUpdateModal(ticket)}>
          ส่งผลงาน
        </Button>
      )}
      <Link to={`/ticket/${ticket.ticket_id}`}>
        <Button size="small" block style={{ borderRadius: 6, backgroundColor: '#f8fafc', borderColor: '#e2e8f0', color: '#475569' }}>ดูรายละเอียด</Button>
      </Link>
    </div>
  );

  const categoryCount = {};
  tickets.forEach(t => {
    const name = t.category_name || 'ไม่ระบุ';
    categoryCount[name] = (categoryCount[name] || 0) + 1;
  });
  const chartData = Object.keys(categoryCount).map(key => ({ name: key, value: categoryCount[key] }));

  // ✅ กรองให้เหลือแค่ 5 รายการล่าสุด และที่สถานะ "ยังไม่ปิด (Not Closed)"
  const activeRecentTickets = tickets
    .filter(t => t.status !== 'Closed')
    .slice(0, 5);

  const tableColumns = [
    { title: 'เลขที่', dataIndex: 'ticket_number', key: 'ticket_number', render: (text) => <Text strong style={{ color: '#0ea5e9' }}>{text}</Text> },
    { title: 'วันที่แจ้ง', dataIndex: 'created_at', key: 'created_at', render: (date) => dayjs(date).format('DD/MM/YY HH:mm') },
    { 
      title: 'หมวดหมู่ / รายการ', 
      key: 'category_name', 
      render: (_, record) => (
        <div>
          <Text strong>{record.category_name || 'ทั่วไป'}</Text><br/>
          <Text type="secondary" style={{ fontSize: '12px' }}>{record.equipment_no || '-'}</Text>
        </div>
      ) 
    },

    { 
      title: 'สถานะ', 
      key: 'status', 
      dataIndex: 'status', 
      render: (status) => {
        const statusConfig = boardColumns.find(c => c.id === status);
        return <Tag color={statusConfig ? statusConfig.color : 'default'} style={{ borderRadius: 10 }}>{statusConfig ? statusConfig.title : status}</Tag>;
      } 
    },

    { title: 'นับเวลา (SLA)', key: 'sla', align: 'center', render: (_, record) => renderSLATimer(record) },
    { 
      title: 'จัดการ', 
      key: 'action', 
      align: 'center',
      render: (_, record) => (
        <Link to={`/ticket/${record.ticket_id}`}>
          <Button type="primary" size="small" ghost style={{ borderRadius: 6 }}>เปิด</Button>
        </Link>
      )
    },
  ];

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      
      <style>{`
        /* แอนิเมชันลูกเล่นต่างๆ */
        @keyframes pulse-alert { 0% { opacity: 1; transform: scale(1); } 50% { opacity: 0.6; transform: scale(1.05); color: #b91c1c; } 100% { opacity: 1; transform: scale(1); } }
        @keyframes spin { 100% { transform: rotate(360deg); } }
        @keyframes float-icon { 0%, 100% { transform: translateY(0px) rotate(-15deg); } 50% { transform: translateY(-10px) rotate(-15deg); } }
        @keyframes pulse-icon { 0%, 100% { transform: scale(1) rotate(-15deg); } 50% { transform: scale(1.1) rotate(-15deg); } }
        
        .icon-spin-slow { animation: spin 4s linear infinite; }
        .icon-spin-normal { animation: spin 2s linear infinite; }
        .icon-spin-fast { animation: spin 1s linear infinite; color: #ef4444; }
        .icon-float { animation: float-icon 3s ease-in-out infinite; }
        .icon-pulse { animation: pulse-icon 2s ease-in-out infinite; }
        
        .stat-icon-bg {
          position: absolute;
          right: -15px;
          bottom: -20px;
          font-size: 110px;
          opacity: 0.15;
          transition: all 0.3s;
          pointer-events: none;
        }
        .stat-card:hover .stat-icon-bg {
          transform: scale(1.15) rotate(-5deg);
          opacity: 0.25;
        }
        
        .custom-tabs .ant-tabs-tab { background-color: #e2e8f0 !important; border-color: #cbd5e1 !important; }
        .custom-tabs .ant-tabs-tab-active { background-color: #ffffff !important; border-bottom-color: #ffffff !important; }
      `}</style>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <Title level={2} style={{ color: '#2a1a4a', margin: 0 }}><DashboardOutlined /> แดชบอร์ดภาพรวม</Title>
        <Button type="primary" icon={<SyncOutlined />} onClick={fetchData} loading={loading} size="large" style={{ borderRadius: 8 }}>รีเฟรชข้อมูล</Button>
      </div>

      <Row gutter={[16, 16]} style={{ marginBottom: 20 }}>
        {stats.map(s => (
          <Col xs={12} sm={8} lg={4} key={s.title}>
            {/* ✅ เพิ่ม Class stat-card และดึงไอคอนพื้นหลังมาแสดง */}
            <div className="stat-card" style={{ 
              position: 'relative', overflow: 'hidden',
              background: s.bg, borderRadius: 12, padding: '16px 12px', color: 'white', textAlign: 'center',
              boxShadow: `0 8px 16px ${s.shadow}`, transition: 'transform 0.3s ease, box-shadow 0.3s ease', cursor: 'default'
            }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = `0 12px 20px ${s.shadow}`; }}
            onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = `0 8px 16px ${s.shadow}`; }}
            >
              <div className={`stat-icon-bg ${s.anim}`}>{s.bgIcon}</div>
              <div style={{ opacity: 0.9, marginBottom: 4, position: 'relative', zIndex: 1 }}>{React.cloneElement(s.icon, { style: { fontSize: 24 } })}</div>
              <Title level={3} style={{ color: 'white', margin: 0, fontWeight: 900, position: 'relative', zIndex: 1 }}><AnimatedNumber value={s.value} /></Title>
              <Text style={{ color: 'white', fontSize: 12, opacity: 0.95, fontWeight: 500, position: 'relative', zIndex: 1 }}>{s.title}</Text>
            </div>
          </Col>
        ))}
      </Row>

      {(currentUser.role === 'admin' || currentUser.role === 'head_technician' || currentUser.role === 'technician') && (
        <Card style={{ borderRadius: 16, border: '1px solid #e2e8f0', boxShadow: '0 4px 15px rgba(0,0,0,0.03)', marginBottom: 30 }}>
          <Row justify="space-between" align="middle" style={{ borderBottom: '1px solid #f1f5f9', paddingBottom: 15, marginBottom: 15 }}>
            <Col>
              <Title level={4} style={{ color: '#334155', margin: 0 }}>
                <AlertOutlined style={{ color: '#ef4444', marginRight: 8 }}/> 
                SLA Monitor (ระบบจัดการค่าปรับ)
              </Title>
            </Col>
            <Col>
              <Space>
                <Text strong>เลือกงวดประเมิน:</Text>
                <Select value={selectedPeriod} onChange={setSelectedPeriod} style={{ width: 220, borderRadius: 8 }}>
                  <Option value="all">รวมทั้งหมดตั้งแต่เริ่มสัญญา</Option>
                  {availablePeriods.map(p => (
                    <Option key={p} value={p}>งวดเดือน {dayjs(p).format('MMMM YYYY')}</Option>
                  ))}
                </Select>
              </Space>
            </Col>
          </Row>

          <Row gutter={[16, 16]}>
            <Col xs={12} sm={6}>
              <Statistic title="ใบงานด่วน (CM) ประจำงวด" value={slaStats.totalCM} prefix={<ThunderboltOutlined />} styles={{ content: { color: '#3b82f6', fontWeight: 'bold' } }} />
            </Col>
            <Col xs={12} sm={6}>
              <Statistic title="กำลังนับถอยหลัง" value={slaStats.activeCM.length} prefix={<ClockCircleOutlined />} styles={{ content: { color: '#f59e0b', fontWeight: 'bold' } }} />
            </Col>
            <Col xs={12} sm={6}>
              <Statistic title="หลุด SLA ในงวดนี้ (ครั้ง)" value={slaStats.breachedCount} prefix={<FireOutlined />} styles={{ content: { color: '#ef4444', fontWeight: 'bold' } }} />
            </Col>
            <Col xs={12} sm={6}>
              <AntTooltip title="หักค่าปรับนี้ ออกจากใบแจ้งหนี้ประจำงวดที่เลือก">
                <Statistic 
                  title={<span style={{ cursor: 'help' }}>ค่าปรับสุทธิประจำงวด (บาท) <InfoCircleOutlined /></span>} 
                  value={slaStats.totalPenalty} 
                  precision={2} 
                  prefix={<DollarCircleOutlined />} 
                  styles={{ content: { color: '#be123c', fontWeight: 'bold', fontSize: '26px' } }} 
                />
              </AntTooltip>
            </Col>
          </Row>

          {slaStats.activeCM.length > 0 && (
            <>
              <Divider dashed />
              <Text strong style={{ color: '#475569', fontSize: '14px', marginBottom: '10px', display: 'block' }}>ใบงานที่กำลังจับเวลาในงวดนี้:</Text>
              <div style={{ display: 'flex', gap: '15px', overflowX: 'auto', paddingBottom: '10px' }}>
                {slaStats.activeCM.map(ticket => (
                  <div key={ticket.ticket_id} style={{ minWidth: '220px', border: '1px solid #e2e8f0', borderRadius: '10px', padding: '10px 15px', backgroundColor: '#f8fafc' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                      <Link to={`/ticket/${ticket.ticket_id}`} style={{ fontWeight: 'bold', color: '#0ea5e9' }}>#{ticket.ticket_number}</Link>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center' }}>
                      {renderSLATimer(ticket)}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </Card>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '50px' }}><Spin size="large" /></div>
      ) : (
        <Card styles={{ body: { padding: '10px 20px 20px' } }} style={{ borderRadius: 16, boxShadow: '0 4px 20px rgba(0,0,0,0.03)', border: 'none' }}>
          <Tabs 
            className="custom-tabs" 
            activeKey={activeTab}
            onChange={setActiveTab}
            type="card"
            size="large"
            tabBarStyle={{ marginBottom: 20 }}
            destroyOnHidden={true} 
            items={[
              {
                key: '1',
                label: (
                  <div style={{ padding: '4px 16px', fontSize: '15px', fontWeight: 'bold', color: activeTab === '1' ? '#1890ff' : '#64748b' }}>
                    <BarChartOutlined style={{ marginRight: 8 }} /> สถิติและรายการ (Analytics)
                  </div>
                ),
                children: (
                  <Row gutter={[24, 24]} style={{ marginTop: 10 }}>
                    <Col xs={24} lg={8}>
                      <Card 
                        title={<span style={{ color: '#334155' }}>📊 สัดส่วนใบงานตามหมวดหมู่</span>} 
                        variant="borderless" 
                        style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)' }}
                        styles={{ header: { backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                      >
                        {chartData.length > 0 ? (
                          <div style={{ width: '100%', height: 480, minWidth: 0, minHeight: 480 }}>
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie data={chartData} cx="50%" cy="40%" innerRadius={70} outerRadius={100} paddingAngle={5} dataKey="value" label>
                                  {chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />)}
                                </Pie>
                                <RechartsTooltip formatter={(value) => [`${value} ใบงาน`, 'จำนวน']} />
                                <Legend verticalAlign="bottom" wrapperStyle={{ paddingTop: '20px', lineHeight: '24px' }}/>
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                        ) : <Empty description="ไม่มีข้อมูลสถิติ" />}
                      </Card>
                    </Col>
                    <Col xs={24} lg={16}>
                      <Card 
                        title={<span style={{ color: '#334155' }}>📋 รายการ 5 ใบงานล่าสุด (ยังไม่ปิดงาน)</span>} 
                        variant="borderless" 
                        style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)' }}
                        styles={{ header: { backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                      >
                        <Table columns={tableColumns} dataSource={activeRecentTickets} rowKey="ticket_id" pagination={false} size="middle" scroll={{ x: 800 }} />
                      </Card>
                    </Col>
                  </Row>
                )
              },
              {
                key: '2',
                label: (
                  <div style={{ padding: '4px 16px', fontSize: '15px', fontWeight: 'bold', color: activeTab === '2' ? '#1890ff' : '#64748b' }}>
                    <AppstoreOutlined style={{ marginRight: 8 }} /> กระดานใบงาน
                  </div>
                ),
                children: (
                  <div style={{ display: 'flex', width: '100%', gap: '20px', paddingBottom: 10, minOverflowX: 'auto' }}>
                    {boardColumns.map(column => {
                      const columnTickets = tickets.filter(t => t.status === column.id);
                      return (
                        <div key={column.id} style={{ 
                          flex: 1, minWidth: 260, backgroundColor: column.bgColor, borderRadius: 16, 
                          padding: '16px', display: 'flex', flexDirection: 'column', border: `1px solid ${column.borderColor}` 
                        }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                            <Space>
                              <div style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: column.color }}></div>
                              <Title level={5} style={{ margin: 0, color: column.color }}>{column.title}</Title>
                            </Space>
                            <Tag style={{ borderRadius: 10, margin: 0, backgroundColor: column.color, color: '#fff', border: 'none' }}>{columnTickets.length}</Tag>
                          </div>
                          
                          <div style={{ flex: 1, overflowY: 'auto', paddingRight: 4, maxHeight: '600px' }}>
                            {columnTickets.length > 0 ? (
                              columnTickets.map(t => <TicketCard key={t.ticket_id} ticket={t} colorTheme={column.color} />)
                            ) : (
                              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="ว่าง" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )
              }
            ]}
          />
        </Card>
      )}

      <Modal title={<span><FileTextOutlined /> ส่งผลงานให้ผู้แจ้งตรวจสอบ: <Text type="danger">{selectedTicket?.ticket_number}</Text></span>} open={isModalVisible} onCancel={() => setIsModalVisible(false)} footer={null} destroyOnHidden>
        <Form form={form} layout="vertical" onFinish={handleUpdateStatus}>
          <Form.Item name="root_cause_and_solution" label="รายละเอียดการดำเนินการ" rules={[{ required: true, message: 'กรุณาระบุสิ่งที่ทำไป' }]}>
            <TextArea rows={4} placeholder="ระบุการดำเนินการที่ได้ทำไป เพื่อให้ผู้แจ้งตรวจงาน..." style={{ borderRadius: 8 }} />
          </Form.Item>
          <Form.Item label="แนบไฟล์รูปภาพอ้างอิง (ถ้ามี)">
            <Upload {...uploadProps}>
              <Button icon={<UploadOutlined />} style={{ borderRadius: 8 }}>คลิกเพื่อเลือกไฟล์</Button>
            </Upload>
          </Form.Item>
          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: 10, borderRadius: 8 }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#28a745', borderRadius: 8 }}>ส่งผลงาน</Button>
          </Form.Item>
        </Form>
      </Modal>

    </div>
  );
}