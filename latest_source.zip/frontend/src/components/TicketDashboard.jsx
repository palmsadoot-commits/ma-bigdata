import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Typography, Tag, Avatar, Button, Modal, Form, Input, Upload, Space, Empty, Spin, Tabs, Table, Tooltip as AntTooltip } from 'antd';
import { 
  ClockCircleOutlined, UserOutlined, FileTextOutlined, UploadOutlined, DashboardOutlined, SyncOutlined, 
  CalendarOutlined, HourglassOutlined, PlusCircleOutlined, CheckSquareOutlined, PrinterOutlined, EditOutlined, BarChartOutlined, AppstoreOutlined
} from '@ant-design/icons';
import { PieChart, Pie, Cell, Tooltip as RechartsTooltip, ResponsiveContainer, Legend } from 'recharts';
import { Link } from 'react-router-dom';
import axios from 'axios';
import dayjs from 'dayjs';
import 'dayjs/locale/th';
import { alertSuccess, alertError } from '../utils/alert';

dayjs.locale('th');

const { Title, Text, Paragraph } = Typography;
const { TextArea } = Input;
const BACKEND_URL = 'http://localhost:3000';
const CHART_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

// ✅ 1. 컴โพเนนต์สำหรับทำ "ตัวเลขวิ่งจาก 0"
const AnimatedNumber = ({ value }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const end = parseInt(value, 10) || 0;
    if (end === 0) {
      setCount(0);
      return;
    }
    
    const duration = 800; // ระยะเวลาแอนิเมชัน 0.8 วินาที
    const incrementTime = Math.max(duration / end, 20);
    const step = Math.max(Math.ceil(end / (duration / incrementTime)), 1);

    const timer = setInterval(() => {
      start += step;
      if (start >= end) {
        clearInterval(timer);
        setCount(end);
      } else {
        setCount(start);
      }
    }, incrementTime);

    return () => clearInterval(timer);
  }, [value]);

  return <>{count}</>;
};

export default function TicketDashboard({ project }) {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('1'); 
  
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [fileList, setFileList] = useState([]);
  const [form] = Form.useForm();

  const currentUser = JSON.parse(localStorage.getItem('lims_user')) || { user_id: 1, first_name: 'User' };

  const fetchData = async () => {
    setLoading(true);
    try {
      const ticketRes = await axios.get(`${BACKEND_URL}/api/tickets`, { params: { project_id: project?.project_id } });
      setTickets(ticketRes.data);
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูลแดชบอร์ดได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [project]);

  const today = dayjs().format('YYYY-MM-DD');
  const currentMonth = dayjs().format('YYYY-MM');

  // ข้อมูลสถิติ (Icon จะถูกปรับขนาดลงเล็กน้อยอัตโนมัติในส่วน Render)
  const stats = [
    { title: 'ใบงานทั้งหมด', value: tickets.length, bg: 'linear-gradient(135deg, #60a5fa 0%, #2563eb 100%)', shadow: 'rgba(59, 130, 246, 0.4)', icon: <FileTextOutlined /> },
    { title: 'ใบงานเดือนนี้', value: tickets.filter(t => t.created_at?.startsWith(currentMonth)).length, bg: 'linear-gradient(135deg, #34d399 0%, #059669 100%)', shadow: 'rgba(16, 185, 129, 0.4)', icon: <CalendarOutlined /> },
    { title: 'กำลังดำเนินการ', value: tickets.filter(t => t.status === 'Pending' || t.status === 'In Progress').length, bg: 'linear-gradient(135deg, #fbbf24 0%, #d97706 100%)', shadow: 'rgba(245, 158, 11, 0.4)', icon: <HourglassOutlined /> },
    { title: 'รอตรวจ / ปิดเคส', value: tickets.filter(t => t.status === 'Resolved' || t.status === 'Closed').length, bg: 'linear-gradient(135deg, #a78bfa 0%, #7c3aed 100%)', shadow: 'rgba(139, 92, 246, 0.4)', icon: <CheckSquareOutlined /> },
    { title: 'เปิดใหม่วันนี้', value: tickets.filter(t => t.created_at?.startsWith(today)).length, bg: 'linear-gradient(135deg, #f472b6 0%, #db2777 100%)', shadow: 'rgba(236, 72, 153, 0.4)', icon: <PlusCircleOutlined /> },
    { title: 'อัปเดตวันนี้', value: tickets.filter(t => t.updated_at?.startsWith(today)).length, bg: 'linear-gradient(135deg, #2dd4bf 0%, #0d9488 100%)', shadow: 'rgba(20, 184, 166, 0.4)', icon: <SyncOutlined /> },
  ];

  const boardColumns = [
    { id: 'Pending', title: 'รอดำเนินการ', color: '#ef4444', bgColor: '#fef2f2', borderColor: '#fecaca' },
    { id: 'In Progress', title: 'กำลังดำเนินการ', color: '#f59e0b', bgColor: '#fffbeb', borderColor: '#fde68a' },
    { id: 'Resolved', title: 'รอตรวจสอบ', color: '#3b82f6', bgColor: '#eff6ff', borderColor: '#bfdbfe' },
    { id: 'Closed', title: 'ปิดเคสสมบูรณ์', color: '#22c55e', bgColor: '#f0fdf4', borderColor: '#bbf7d0' }
  ];

  const handleOpenUpdateModal = (ticket) => {
    setSelectedTicket(ticket);
    setFileList([]);
    form.resetFields();
    setIsModalVisible(true);
  };

  const handleUpdateStatus = async (values) => {
    const formData = new FormData();
    formData.append('status', 'Resolved'); 
    formData.append('technician_id', currentUser.user_id);
    if (values.root_cause_and_solution) formData.append('root_cause_and_solution', values.root_cause_and_solution);

    fileList.forEach(file => formData.append('attachments', file.originFileObj));

    try {
      await axios.put(`${BACKEND_URL}/api/tickets/${selectedTicket.ticket_id}/update-status`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      alertSuccess('ส่งตรวจสำเร็จ', 'ส่งให้ผู้แจ้งตรวจสอบเรียบร้อยแล้ว!');
      setIsModalVisible(false);
      fetchData(); 
    } catch (error) {
      alertError('ผิดพลาด', 'เกิดข้อผิดพลาดในการอัปเดตสถานะ');
    }
  };

  const uploadProps = {
    onRemove: (file) => setFileList(prev => prev.filter(item => item.uid !== file.uid)),
    beforeUpload: (file) => { setFileList(prev => [...prev, file]); return false; },
    fileList,
  };

  const TicketCard = ({ ticket, colorTheme }) => (
    <div 
      style={{ 
        marginBottom: 12, 
        borderRadius: 10, 
        backgroundColor: '#fff',
        borderLeft: `4px solid ${colorTheme}`, 
        boxShadow: '0 2px 6px rgba(0,0,0,0.04)',
        padding: '12px', 
        transition: 'all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)',
        cursor: 'pointer'
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-3px)';
        e.currentTarget.style.boxShadow = `0 6px 12px rgba(0,0,0,0.08), 0 0 8px ${colorTheme}20`;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = '0 2px 6px rgba(0,0,0,0.04)';
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6, gap: '6px' }}>
        <Text strong style={{ fontSize: 14, color: '#1e293b', flexShrink: 0 }}>{ticket.ticket_number}</Text>
        
        <AntTooltip title={ticket.category_name || 'ทั่วไป'} placement="topRight">
          <Tag 
            color={colorTheme} 
            style={{ 
              borderRadius: 6, 
              margin: 0, 
              maxWidth: '100px', 
              overflow: 'hidden', 
              textOverflow: 'ellipsis', 
              whiteSpace: 'nowrap',
              fontSize: 11, 
              lineHeight: '18px',
              padding: '0 6px'
            }}
          >
            {ticket.category_name || 'ทั่วไป'}
          </Tag>
        </AntTooltip>
      </div>
      
      <Paragraph ellipsis={{ rows: 1 }} type="secondary" style={{ marginBottom: 8, fontSize: 12, color: '#64748b' }}>
        {ticket.problem_detail}
      </Paragraph>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: currentUser.role !== 'user' ? 8 : 0 }}>
        <Space size={4}>
          <Avatar size={18} style={{ backgroundColor: '#f1f5f9', color: '#64748b' }} icon={<UserOutlined />} />
          <Text type="secondary" style={{ fontSize: 11, maxWidth: 70 }} ellipsis={{ tooltip: ticket.reporter_name }}>
            {ticket.reporter_name}
          </Text>
        </Space>
        <Space size={4} style={{ color: '#94a3b8', fontSize: 11 }}>
          <ClockCircleOutlined style={{ fontSize: 10 }} />
          {dayjs(ticket.created_at).format('DD MMM')}
        </Space>
      </div>
      
      {currentUser.role !== 'user' && ticket.status === 'In Progress' && ticket.assigned_to === currentUser.user_id && (
        <Button type="dashed" size="small" block style={{ borderRadius: 6, borderColor: colorTheme, color: colorTheme, marginBottom: 6 }} onClick={() => handleOpenUpdateModal(ticket)}>
          ส่งผลงาน
        </Button>
      )}
      <Link to={`/ticket/${ticket.ticket_id}`}>
        <Button size="small" block style={{ borderRadius: 6, backgroundColor: '#f8fafc', borderColor: '#e2e8f0', color: '#475569' }}>
          ดูรายละเอียด
        </Button>
      </Link>
    </div>
  );

  const categoryCount = {};
  tickets.forEach(t => {
    const name = t.category_name || 'ไม่ระบุ';
    categoryCount[name] = (categoryCount[name] || 0) + 1;
  });
  const chartData = Object.keys(categoryCount).map(key => ({ name: key, value: categoryCount[key] }));

  const tableColumns = [
    { title: 'เลขที่', dataIndex: 'ticket_number', key: 'ticket_number', render: (text) => <b>{text}</b> },
    { title: 'วันที่แจ้ง', dataIndex: 'created_at', key: 'created_at', render: (date) => dayjs(date).format('DD/MM/YYYY HH:mm') },
    { title: 'ผู้แจ้ง', dataIndex: 'reporter_name', key: 'reporter_name' },
    { title: 'ระบบงาน', dataIndex: 'category_name', key: 'category_name' },
    { 
      title: 'สถานะ', 
      key: 'status', 
      dataIndex: 'status', 
      render: (status) => {
        const statusConfig = boardColumns.find(c => c.id === status);
        return <Tag color={statusConfig ? statusConfig.color : 'default'} style={{ borderRadius: 10 }}>{statusConfig ? statusConfig.title : status}</Tag>;
      } 
    },
    { 
      title: 'จัดการ', 
      key: 'action', 
      render: (_, record) => (
        <Space>
          <Link to={`/ticket/${record.ticket_id}`}>
            <Button type="primary" size="small" icon={<EditOutlined />} style={{ backgroundColor: '#1890ff', borderRadius: 6 }}>รายละเอียด</Button>
          </Link>
          {record.status !== 'Pending' && (
            <Link to={`/print/${record.ticket_id}`} target="_blank">
              <Button size="small" icon={<PrinterOutlined />} style={{ borderRadius: 6 }}>พิมพ์</Button>
            </Link>
          )}
        </Space>
      )
    },
  ];

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <Title level={2} style={{ color: '#2a1a4a', margin: 0 }}><DashboardOutlined /> แดชบอร์ดภาพรวม</Title>
        <Button type="primary" icon={<SyncOutlined />} onClick={fetchData} loading={loading} size="large" style={{ borderRadius: 8 }}>รีเฟรชข้อมูล</Button>
      </div>

      <Row gutter={[16, 16]} style={{ marginBottom: 30 }}>
        {stats.map(s => (
          <Col xs={12} sm={8} lg={4} key={s.title}>
            {/* ✅ 1. ลดขนาด Padding และมุมโค้ง ให้ Card เล็กลงและกระชับขึ้น */}
            <div style={{ 
              background: s.bg, 
              borderRadius: 12, 
              padding: '16px 12px', 
              color: 'white', 
              textAlign: 'center',
              boxShadow: `0 8px 16px ${s.shadow}`, 
              transition: 'transform 0.3s ease, box-shadow 0.3s ease',
              cursor: 'default'
            }}
            onMouseEnter={e => {
              e.currentTarget.style.transform = 'translateY(-4px)';
              e.currentTarget.style.boxShadow = `0 12px 20px ${s.shadow}`;
            }}
            onMouseLeave={e => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = `0 8px 16px ${s.shadow}`;
            }}
            >
              <div style={{ opacity: 0.9, marginBottom: 4 }}>{React.cloneElement(s.icon, { style: { fontSize: 24 } })}</div>
              <Title level={3} style={{ color: 'white', margin: 0, fontWeight: 900 }}>
                {/* ✅ เรียกใช้ตัวเลขวิ่งจาก 0 */}
                <AnimatedNumber value={s.value} />
              </Title>
              <Text style={{ color: 'white', fontSize: 12, opacity: 0.95, fontWeight: 500 }}>{s.title}</Text>
            </div>
          </Col>
        ))}
      </Row>

      <style>{`
        .custom-tabs .ant-tabs-tab {
          background-color: #e2e8f0 !important; 
          border-color: #cbd5e1 !important;
        }
        .custom-tabs .ant-tabs-tab-active {
          background-color: #ffffff !important; 
          border-bottom-color: #ffffff !important;
        }
      `}</style>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '50px' }}><Spin size="large" /></div>
      ) : (
        <Card 
          styles={{ body: { padding: '10px 20px 20px' } }} 
          style={{ borderRadius: 16, boxShadow: '0 4px 20px rgba(0,0,0,0.03)', border: 'none' }}
        >
          {/* ✅ 3. ใช้ destroyOnHidden={true} เพื่อแก้ Warning และ Error ของ Recharts */}
          <Tabs 
            className="custom-tabs" 
            activeKey={activeTab}
            onChange={setActiveTab}
            type="card"
            size="large"
            tabBarStyle={{ marginBottom: 20 }}
            destroyOnHidden={true} 
            items={[
              {
                // ✅ 2. สลับให้ "สถิติและรายการ" มาอยู่แท็บที่ 1
                key: '1',
                label: (
                  <div style={{ padding: '4px 16px', fontSize: '15px', fontWeight: 'bold', color: activeTab === '1' ? '#1890ff' : '#64748b' }}>
                    <BarChartOutlined style={{ marginRight: 8 }} /> สถิติและรายการ (Analytics)
                  </div>
                ),
                children: (
                  <Row gutter={[24, 24]} style={{ marginTop: 10 }}>
                    <Col xs={24} lg={8}>
                      <Card 
                        title={<span style={{ color: '#334155' }}>📊 สัดส่วนใบงานตามหมวดหมู่</span>} 
                        variant="borderless" 
                        style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)' }}
                        styles={{ header: { backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                      >
                        {chartData.length > 0 ? (
                          <div style={{ width: '100%', height: 480 }}>
                            <ResponsiveContainer>
                              <PieChart>
                                <Pie 
                                  data={chartData} 
                                  cx="50%" 
                                  cy="40%" 
                                  innerRadius={70} 
                                  outerRadius={100} 
                                  paddingAngle={5} 
                                  dataKey="value" 
                                  label 
                                >
                                  {chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />)}
                                </Pie>
                                <RechartsTooltip formatter={(value) => [`${value} ใบงาน`, 'จำนวน']} />
                                <Legend verticalAlign="bottom" wrapperStyle={{ paddingTop: '20px', lineHeight: '24px' }}/>
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                        ) : <Empty description="ไม่มีข้อมูลสถิติ" />}
                      </Card>
                    </Col>
                    <Col xs={24} lg={16}>
                      <Card 
                        title={<span style={{ color: '#334155' }}>📋 รายการแจ้งซ่อมทั้งหมด</span>} 
                        variant="borderless" 
                        style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)' }}
                        styles={{ header: { backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                      >
                        <Table 
                          columns={tableColumns} 
                          dataSource={tickets} 
                          rowKey="ticket_id" 
                          pagination={{ pageSize: 8 }} 
                          size="middle" 
                          scroll={{ x: 800 }} 
                        />
                      </Card>
                    </Col>
                  </Row>
                )
              },
              {
                // ✅ 2. สลับให้ "กระดานใบงาน" ไปอยู่แท็บที่ 2
                key: '2',
                label: (
                  <div style={{ padding: '4px 16px', fontSize: '15px', fontWeight: 'bold', color: activeTab === '2' ? '#1890ff' : '#64748b' }}>
                    <AppstoreOutlined style={{ marginRight: 8 }} /> กระดานใบงาน
                  </div>
                ),
                children: (
                  <div style={{ display: 'flex', width: '100%', gap: '20px', paddingBottom: 10, minOverflowX: 'auto' }}>
                    {boardColumns.map(column => {
                      const columnTickets = tickets.filter(t => t.status === column.id);
                      return (
                        <div key={column.id} style={{ 
                          flex: 1, 
                          minWidth: 260, 
                          backgroundColor: column.bgColor, 
                          borderRadius: 16, 
                          padding: '16px', 
                          display: 'flex', 
                          flexDirection: 'column', 
                          border: `1px solid ${column.borderColor}` 
                        }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                            <Space>
                              <div style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: column.color }}></div>
                              <Title level={5} style={{ margin: 0, color: column.color }}>{column.title}</Title>
                            </Space>
                            <Tag style={{ borderRadius: 10, margin: 0, backgroundColor: column.color, color: '#fff', border: 'none' }}>{columnTickets.length}</Tag>
                          </div>
                          
                          <div style={{ flex: 1, overflowY: 'auto', paddingRight: 4, maxHeight: '600px' }}>
                            {columnTickets.length > 0 ? (
                              columnTickets.map(t => <TicketCard key={t.ticket_id} ticket={t} colorTheme={column.color} />)
                            ) : (
                              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="ว่าง" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )
              }
            ]}
          />
        </Card>
      )}

      <Modal
        title={<span><FileTextOutlined /> ส่งผลงานให้ผู้แจ้งตรวจสอบ: <Text type="danger">{selectedTicket?.ticket_number}</Text></span>}
        open={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
        destroyOnHidden
      >
        <Form form={form} layout="vertical" onFinish={handleUpdateStatus}>
          <Form.Item name="root_cause_and_solution" label="รายละเอียดการดำเนินการ" rules={[{ required: true, message: 'กรุณาระบุสิ่งที่ทำไป' }]}>
            <TextArea rows={4} placeholder="ระบุการดำเนินการที่ได้ทำไป เพื่อให้ผู้แจ้งตรวจงาน..." style={{ borderRadius: 8 }} />
          </Form.Item>
          <Form.Item label="แนบไฟล์รูปภาพอ้างอิง (ถ้ามี)">
            <Upload {...uploadProps}>
              <Button icon={<UploadOutlined />} style={{ borderRadius: 8 }}>คลิกเพื่อเลือกไฟล์</Button>
            </Upload>
          </Form.Item>
          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: 10, borderRadius: 8 }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#28a745', borderRadius: 8 }}>ส่งผลงาน</Button>
          </Form.Item>
        </Form>
      </Modal>

    </div>
  );
} 