import React, { useState, useEffect } from 'react';
import { 
  SettingOutlined, 
  SaveOutlined, 
  MessageOutlined, 
  MailOutlined, 
  ClockCircleOutlined,
  UploadOutlined,
  SafetyCertificateOutlined,
  RocketOutlined,
  UserOutlined,
  EyeOutlined,
  EyeInvisibleOutlined,
  SyncOutlined,
  BgColorsOutlined,
  FontSizeOutlined,
  PictureOutlined,
  BulbOutlined,
  FileTextOutlined,
  SecurityScanOutlined
} from '@ant-design/icons';
import { Card, Tabs, Form, Input, Button, Row, Col, Typography, InputNumber, Divider, Upload, Space, Spin, Switch, Tag, Select, Radio, ColorPicker, theme } from 'antd';
import axiosInstance from '../services/api/axiosInstance';
import { alertSuccess, alertError } from '../utils/alert';

const { Title, Text } = Typography;
const { useToken } = theme;
const BACKEND_URL = 'http://localhost:3000';

export default function SystemSettings() {
  const { token } = useToken();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testingLine, setTestingLine] = useState(false);
  const [testingEmail, setTestingEmail] = useState(false);
  
  const [fileList, setFileList] = useState([]);
  const [faviconFileList, setFaviconFileList] = useState([]);
  
  const [currentLogo, setCurrentLogo] = useState(null);
  const [currentFavicon, setCurrentFavicon] = useState(null);
  
  const [previewUrl, setPreviewUrl] = useState(null);
  const [faviconPreviewUrl, setFaviconPreviewUrl] = useState(null);
  
  const [healthData, setHealthData] = useState(null);
  const [loadingHealth, setLoadingHealth] = useState(false);

  const fetchSettings = async () => {
    setLoading(true);
    try {
      const res = await axiosInstance.get('/settings');
      if (res.data) {
        const settings = res.data;
        form.setFieldsValue({
          ...settings,
          default_sla_hours: settings.default_sla_hours ?? 2,
          default_penalty_rate: settings.default_penalty_rate ?? 0.001,
          security_strict_mode: settings.security_strict_mode === 1,
          max_file_size_mb: settings.max_file_size_mb ?? 5,
          allowed_file_types: settings.allowed_file_types ? settings.allowed_file_types.split(',').map(e => e.trim()) : ['jpg', 'jpeg', 'png', 'pdf'],
          admin_email: settings.admin_email ? settings.admin_email.split(',').map(e => e.trim()) : [],
          enable_line: settings.enable_line === 1,
          enable_email: settings.enable_email === 1,
          notify_new_ticket: settings.notify_new_ticket === 1,
          notify_status_change: settings.notify_status_change === 1,
          maintenance_mode: settings.maintenance_mode === 1,
          sla_hardware_hours: settings.sla_hardware_hours || 6,
          sla_software_hours: settings.sla_software_hours || 6,
          sla_app_hours: settings.sla_app_hours || 12,
          ack_limit_hours: settings.ack_limit_hours || 2,
          theme_mode: settings.theme_mode || 'light',
          primary_color: settings.primary_color || '#1677ff',
          system_font: settings.system_font || 'Inter'
        });
        
        if (settings.system_logo) setCurrentLogo(settings.system_logo);
        if (settings.system_favicon) setCurrentFavicon(settings.system_favicon);
      }
    } catch (error) {
      console.error("Fetch settings error:", error);
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูลการตั้งค่าระบบได้');
    } finally {
      setLoading(false);
    }
  };

  const fetchHealth = async () => {
    setLoadingHealth(true);
    try {
      const res = await axiosInstance.get('/settings/health');
      setHealthData(res.data);
    } catch (error) {
      console.error("Fetch health error:", error);
    } finally {
      setLoadingHealth(false);
    }
  };

  useEffect(() => {
    fetchSettings();
    fetchHealth();
  }, []);

  const handleUploadChange = ({ fileList: newFileList }) => {
    setFileList(newFileList);
    if (newFileList.length > 0 && newFileList[0].originFileObj) {
      const url = URL.createObjectURL(newFileList[0].originFileObj);
      setPreviewUrl(url);
    } else {
      setPreviewUrl(null);
    }
  };

  const handleFaviconUploadChange = ({ fileList: newFileList }) => {
    setFaviconFileList(newFileList);
    if (newFileList.length > 0 && newFileList[0].originFileObj) {
      const url = URL.createObjectURL(newFileList[0].originFileObj);
      setFaviconPreviewUrl(url);
    } else {
      setFaviconPreviewUrl(null);
    }
  };

  const handleTestLine = async () => {
    setTestingLine(true);
    try {
      const res = await axiosInstance.post('/settings/test-line');
      alertSuccess('สำเร็จ', res.data.message);
    } catch (error) {
      alertError('ผิดพลาด', error.response?.data?.error || 'ไม่สามารถทดสอบการเชื่อมต่อได้');
    } finally {
      setTestingLine(false);
    }
  };

  const handleTestEmail = async () => {
    setTestingEmail(true);
    try {
      const res = await axiosInstance.post('/settings/test-email');
      alertSuccess('สำเร็จ', res.data.message);
    } catch (error) {
      alertError('ผิดพลาด', error.response?.data?.error || 'ไม่สามารถทดสอบการส่งอีเมลได้');
    } finally {
      setTestingEmail(false);
    }
  };

  const handleFinish = async (values) => {
    setSaving(true);
    try {
      const formData = new FormData();
      Object.keys(values).forEach(key => {
        let val = values[key];
        if (['security_strict_mode', 'notify_new_ticket', 'notify_status_change', 'enable_line', 'enable_email', 'maintenance_mode'].includes(key)) {
          val = val ? 1 : 0;
        }
        if ((key === 'admin_email' || key === 'allowed_file_types') && Array.isArray(val)) {
          val = val.join(',');
        }
        if (key === 'primary_color' && typeof val === 'object') {
          val = val.toHexString ? val.toHexString() : val;
        }
        formData.append(key, val !== undefined && val !== null ? val : '');
      });

      if (fileList.length > 0 && fileList[0].originFileObj) {
        formData.append('system_logo', fileList[0].originFileObj);
      }
      if (faviconFileList.length > 0 && faviconFileList[0].originFileObj) {
        formData.append('system_favicon', faviconFileList[0].originFileObj);
      }

      await axiosInstance.put('/settings', formData);
      
      // ✅ ส่ง Event เพื่อแจ้ง App.jsx ให้โหลดค่าใหม่ทันที
      window.dispatchEvent(new CustomEvent('system_settings_updated'));
      
      alertSuccess('บันทึกสำเร็จ', 'อัปเดตการตั้งค่าระบบและธีมเรียบร้อยแล้ว');
      setFileList([]);
      setFaviconFileList([]);
      setPreviewUrl(null);
      setFaviconPreviewUrl(null);
      fetchSettings();
    } catch (error) {
      alertError('เกิดข้อผิดพลาด', 'ไม่สามารถบันทึกได้');
    } finally {
      setSaving(false);
    }
  };

  const renderGeneralTab = () => (
    <div style={{ padding: '10px 0' }}>
      <Row gutter={[32, 32]}>
        <Col xs={24} lg={12}>
          <div style={{ marginBottom: 32 }}>
            <Title level={5}><FileTextOutlined /> ข้อมูลระบบพื้นฐาน</Title>
            <Divider style={{ margin: '12px 0' }} />
            <Form.Item name="system_name" label="ชื่อระบบ (Browser Title)" rules={[{ required: true }]}>
              <Input size="large" placeholder="เช่น LMIS Big Data" />
            </Form.Item>
            <Form.Item name="agency_name" label="ชื่อหน่วยงานที่แสดงในระบบ">
              <Input size="large" placeholder="เช่น บริษัท/หน่วยงานของคุณ" />
            </Form.Item>
            <Form.Item name="maintenance_mode" label={<Text strong style={{ color: token.colorWarning }}><SafetyCertificateOutlined /> โหมดปิดปรับปรุงระบบ</Text>} valuePropName="checked">
              <Switch checkedChildren="เปิดใช้งาน" unCheckedChildren="ปิดใช้งาน" />
            </Form.Item>
          </div>

          <div>
            <Title level={5}><BgColorsOutlined /> ธีมและการแสดงผล (Theming)</Title>
            <Divider style={{ margin: '12px 0' }} />
            <Row gutter={16}>
              <Col span={12}>
                <Form.Item name="theme_mode" label="โหมดสีพื้นฐาน">
                  <Radio.Group buttonStyle="solid" style={{ width: '100%' }}>
                    <Radio.Button value="light" style={{ width: '50%', textAlign: 'center' }}><BulbOutlined /> Light</Radio.Button>
                    <Radio.Button value="dark" style={{ width: '50%', textAlign: 'center' }}><BulbOutlined style={{ color: '#fadb14' }} /> Dark</Radio.Button>
                  </Radio.Group>
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item name="primary_color" label="สีหลัก (Brand Color)">
                  <ColorPicker showText style={{ width: '100%', justifyContent: 'flex-start' }} />
                </Form.Item>
              </Col>
              <Col span={24}>
                <Form.Item name="system_font" label="ฟอนต์ระบบ (Typography)">
                  <Select size="large" suffixIcon={<FontSizeOutlined />}>
                    <Select.Option value="Inter">Inter (Standard)</Select.Option>
                    <Select.Option value="Sarabun">Sarabun (ทางการ)</Select.Option>
                    <Select.Option value="Kanit">Kanit (ทันสมัย)</Select.Option>
                    <Select.Option value="Prompt">Prompt (สะอาดตา)</Select.Option>
                  </Select>
                </Form.Item>
              </Col>
            </Row>
          </div>
        </Col>

        <Col xs={24} lg={12}>
          <div style={{ background: token.colorBgContainer, padding: 24, borderRadius: 20, border: `1px solid ${token.colorBorderSecondary}` }}>
            <Title level={5}><PictureOutlined /> สื่อและอัตลักษณ์ (Media & Assets)</Title>
            <Divider style={{ margin: '12px 0' }} />
            
            <div style={{ marginBottom: 32 }}>
              <Text strong style={{ display: 'block', marginBottom: 12 }}>โลโก้ระบบ (Main Logo)</Text>
              <Space align="start" size={24}>
                <div style={{ textAlign: 'center', width: 120 }}>
                  <div style={{ height: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', background: token.colorBgContainer, borderRadius: 12, border: `1px dashed ${token.colorBorder}`, padding: 8, marginBottom: 8 }}>
                    {(previewUrl || currentLogo) ? (
                      <img src={previewUrl || `${BACKEND_URL}/uploads/${currentLogo}`} alt="Logo" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
                    ) : <PictureOutlined style={{ fontSize: 32, color: token.colorTextQuaternary }} />}
                  </div>
                  <Tag color={previewUrl ? 'blue' : 'default'} style={{ fontSize: 10 }}>{previewUrl ? 'ใหม่' : 'ปัจจุบัน'}</Tag>
                </div>
                <div style={{ paddingTop: 10 }}>
                  <Upload beforeUpload={() => false} showUploadList={false} onChange={handleUploadChange} maxCount={1} accept="image/*">
                    <Button icon={<UploadOutlined />} size="large">อัปโหลดโลโก้</Button>
                  </Upload>
                  <div style={{ marginTop: 8, fontSize: 12, color: token.colorTextSecondary }}>แนะนำไฟล์ PNG / SVG<br/>ขนาดไม่เกิน 2MB</div>
                </div>
              </Space>
            </div>

            <div>
              <Text strong style={{ display: 'block', marginBottom: 12 }}>ไอคอนเบราว์เซอร์ (Favicon)</Text>
              <Space align="start" size={24}>
                <div style={{ textAlign: 'center', width: 64 }}>
                  <div style={{ height: 64, width: 64, display: 'flex', alignItems: 'center', justifyContent: 'center', background: token.colorBgContainer, borderRadius: 8, border: `1px dashed ${token.colorBorder}`, padding: 4, marginBottom: 8 }}>
                    {(faviconPreviewUrl || currentFavicon) ? (
                      <img src={faviconPreviewUrl || `${BACKEND_URL}/uploads/${currentFavicon}`} alt="Favicon" style={{ width: 32, height: 32 }} />
                    ) : <RocketOutlined style={{ fontSize: 24, color: token.colorTextQuaternary }} />}
                  </div>
                  <Tag color={faviconPreviewUrl ? 'blue' : 'default'} style={{ fontSize: 9 }}>{faviconPreviewUrl ? 'ใหม่' : 'ปัจจุบัน'}</Tag>
                </div>
                <div style={{ paddingTop: 4 }}>
                  <Upload beforeUpload={() => false} showUploadList={false} onChange={handleFaviconUploadChange} maxCount={1} accept="image/x-icon,image/png,image/svg+xml">
                    <Button icon={<UploadOutlined />} size="middle">เปลี่ยน Favicon</Button>
                  </Upload>
                  <div style={{ marginTop: 8, fontSize: 12, color: token.colorTextSecondary }}>แนะนำ .ico หรือ .png<br/>ขนาด 32x32 px</div>
                </div>
              </Space>
            </div>
          </div>
        </Col>
      </Row>
    </div>
  );

  const tabItems = [
    { key: '1', label: <span><SettingOutlined /> ข้อมูลทั่วไป & ธีม</span>, children: renderGeneralTab() },
    { key: '2', label: <span><MessageOutlined style={{ color: '#00c300' }}/> LINE API</span>, children: (
      <div style={{ padding: '10px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Title level={5} style={{ margin: 0 }}><MessageOutlined style={{ color: '#00c300' }}/> LINE Messaging API</Title>
          <Form.Item name="enable_line" valuePropName="checked" noStyle>
            <Switch checkedChildren="เปิดใช้งาน" unCheckedChildren="ปิดใช้งาน" />
          </Form.Item>
        </div>
        <Divider style={{ margin: '12px 0' }} />
        <Form.Item name="line_notify_token" label="Channel Access Token">
          <Input.Password size="large" iconRender={visible => (visible ? <EyeOutlined /> : <EyeInvisibleOutlined />)} />
        </Form.Item>
        <Form.Item name="line_group_id" label="Target Group ID">
          <Input size="large" prefix={<UserOutlined style={{ color: '#00c300' }}/>} />
        </Form.Item>
        <Button type="dashed" icon={<RocketOutlined />} onClick={handleTestLine} loading={testingLine} style={{ color: '#00c300', borderColor: '#00c300' }}>ทดสอบส่ง LINE</Button>
      </div>
    )},
    { key: '3', label: <span><MailOutlined /> SMTP & Email</span>, children: (
      <div style={{ padding: '10px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Title level={5} style={{ margin: 0 }}><MailOutlined /> Email Server (SMTP)</Title>
          <Form.Item name="enable_email" valuePropName="checked" noStyle>
            <Switch checkedChildren="เปิดใช้งาน" unCheckedChildren="ปิดใช้งาน" />
          </Form.Item>
        </div>
        <Divider style={{ margin: '12px 0' }} />
        <Row gutter={16}>
          <Col span={16}><Form.Item name="smtp_host" label="SMTP Host"><Input size="large" /></Form.Item></Col>
          <Col span={8}><Form.Item name="smtp_port" label="Port"><Input size="large" /></Form.Item></Col>
          <Col span={12}><Form.Item name="smtp_user" label="Username"><Input size="large" /></Form.Item></Col>
          <Col span={12}><Form.Item name="smtp_pass" label="Password"><Input.Password size="large" /></Form.Item></Col>
          <Col span={24}>
            <Form.Item name="admin_email" label="อีเมลผู้รับแจ้ง">
              <Select mode="tags" size="large" style={{ width: '100%' }} tokenSeparators={[',', ' ']} open={false} />
            </Form.Item>
          </Col>
        </Row>
        <Button type="dashed" icon={<MailOutlined />} onClick={handleTestEmail} loading={testingEmail} style={{ color: '#1890ff', borderColor: '#1890ff' }}>ทดสอบส่ง Email</Button>
      </div>
    )},
    { key: '5', label: <span><ClockCircleOutlined /> SLA Policies</span>, children: (
      <div style={{ padding: '10px 0' }}>
        <Title level={5}><ClockCircleOutlined /> ระยะเวลา SLA ตามประเภทงาน</Title>
        <Divider style={{ margin: '12px 0' }} />
        <Row gutter={[16, 16]}>
          <Col xs={24} md={8}><Card size="small" title="💻 Hardware (ชม.)"><Form.Item name="sla_hardware_hours" noStyle><InputNumber size="large" style={{ width: '100%' }} /></Form.Item></Card></Col>
          <Col xs={24} md={8}><Card size="small" title="💿 Software (ชม.)"><Form.Item name="sla_software_hours" noStyle><InputNumber size="large" style={{ width: '100%' }} /></Form.Item></Card></Col>
          <Col xs={24} md={8}><Card size="small" title="🌐 Application (ชม.)"><Form.Item name="sla_app_hours" noStyle><InputNumber size="large" style={{ width: '100%' }} /></Form.Item></Card></Col>
        </Row>
      </div>
    )},
    { key: '9', label: <span><SecurityScanOutlined /> System Health</span>, children: (
      <div style={{ padding: '10px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <Title level={5} style={{ margin: 0 }}><RocketOutlined /> สุขภาพระบบ</Title>
          <Button icon={<SyncOutlined />} onClick={fetchHealth} loading={loadingHealth}>รีเฟรช</Button>
        </div>
        <Row gutter={[16, 16]}>
          <Col span={12}>
            <Card size="small" title="📡 Server Info">
              <p>DB: <Tag color="success">Connected</Tag></p>
              <p>Time: {healthData?.server_time}</p>
              <p>Node: {healthData?.node_version}</p>
            </Card>
          </Col>
          <Col span={12}>
            <Card size="small" title="📁 Permissions">
              {healthData?.folders.map(f => (
                <div key={f.name} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <Text size="small">{f.name}</Text>
                  <Tag color={f.status === 'Writable' ? 'success' : 'error'} size="small">{f.status}</Tag>
                </div>
              ))}
            </Card>
          </Col>
        </Row>
      </div>
    )}
  ];

  return (
    <div style={{ padding: '20px', backgroundColor: token.colorBgLayout, minHeight: '100vh' }}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: 24, gap: 12 }}>
        <div style={{ padding: 8, background: token.colorPrimary, borderRadius: 8 }}>
          <SettingOutlined style={{ fontSize: 24, color: token.colorTextLightSolid }} />
        </div>
        <Title level={2} style={{ margin: 0 }}>ตั้งค่าระบบและการแสดงผล</Title>
      </div>
      
      <Card style={{ borderRadius: 16, boxShadow: token.boxShadowTertiary, border: 'none' }}>
        <Spin spinning={loading}>
          <Form form={form} layout="vertical" onFinish={handleFinish}>
            <Tabs items={tabItems} size="large" style={{ marginBottom: 24 }} />
            <Divider style={{ margin: '0 0 24px 0' }} />
            <div style={{ textAlign: 'right' }}>
              <Space size="middle">
                <Button size="large" onClick={() => fetchSettings()} style={{ borderRadius: 8 }}>ยกเลิกการเปลี่ยนแปลง</Button>
                <Button type="primary" size="large" htmlType="submit" icon={<SaveOutlined />} loading={saving} style={{ backgroundColor: token.colorPrimary, borderColor: token.colorPrimary, borderRadius: 8, padding: '0 32px' }}>บันทึกการตั้งค่า</Button>
              </Space>
            </div>
          </Form>
        </Spin>
      </Card>
    </div>
  );
}
