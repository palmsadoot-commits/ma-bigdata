import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Space, Typography, Tag, Modal, Form, Input, InputNumber, Popconfirm, Select } from 'antd';
import { TagsOutlined, PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import axios from 'axios';
import { alertSuccess, alertError } from '../utils/alert';

const { Title } = Typography;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000';

export default function StatusManagement() {
  const [statuses, setStatuses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingStatus, setEditingStatus] = useState(null);
  const [form] = Form.useForm();

  const fetchStatuses = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${BACKEND_URL}/api/statuses`);
      setStatuses(res.data);
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูลสถานะได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchStatuses(); }, []);

  const handleAdd = () => {
    setEditingStatus(null);
    form.resetFields();
    form.setFieldsValue({ sort_order: statuses.length + 1 });
    setIsModalVisible(true);
  };

  const handleEdit = (record) => {
    setEditingStatus(record);
    form.setFieldsValue(record);
    setIsModalVisible(true);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/statuses/${id}`);
      alertSuccess('ลบสำเร็จ', 'ลบสถานะเรียบร้อยแล้ว');
      fetchStatuses();
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถลบสถานะนี้ได้');
    }
  };

  const handleSubmit = async (values) => {
    try {
      if (editingStatus) {
        await axios.put(`${BACKEND_URL}/api/statuses/${editingStatus.status_id}`, values);
        alertSuccess('อัปเดตสำเร็จ', 'แก้ไขป้ายสถานะเรียบร้อย ระบบจะอัปเดตใบงานที่ใช้สถานะนี้ให้อัตโนมัติ');
      } else {
        await axios.post(`${BACKEND_URL}/api/statuses`, values);
        alertSuccess('เพิ่มสำเร็จ', 'เพิ่มป้ายสถานะใหม่เรียบร้อย');
      }
      setIsModalVisible(false);
      fetchStatuses();
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถบันทึกข้อมูลได้');
    }
  };

  const columns = [
    { title: 'ลำดับขั้นตอน (Order)', dataIndex: 'sort_order', key: 'sort_order', align: 'center', width: 150 },
    { 
      title: 'ชื่อสถานะ (ป้ายแท็ก)', 
      dataIndex: 'status_name', 
      key: 'status_name',
      render: (text, record) => <Tag color={record.status_color} style={{ fontSize: '14px', padding: '4px 10px' }}>{text}</Tag>
    },
    { title: 'สี (Color Code)', dataIndex: 'status_color', key: 'status_color', align: 'center' },
    {
      title: 'จัดการ',
      key: 'action',
      align: 'right',
      width: 150,
      render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleEdit(record)}>แก้ไข</Button>
          <Popconfirm title="ยืนยันการลบ? (หากลบ ใบงานที่ใช้สถานะนี้อาจไม่แสดงบนกระดาน)" onConfirm={() => handleDelete(record.status_id)}>
            <Button type="primary" danger size="small" icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  // สีที่มีให้เลือกใน Ant Design
  const colorOptions = [
    { label: 'แดง (Red)', value: 'red' }, { label: 'ส้ม (Orange)', value: 'orange' }, 
    { label: 'ทอง (Gold)', value: 'gold' }, { label: 'เขียว (Green)', value: 'green' },
    { label: 'ฟ้า (Blue)', value: 'blue' }, { label: 'ม่วง (Purple)', value: 'purple' },
    { label: 'เทา (Gray)', value: 'gray' }, { label: 'ดำ (Black)', value: 'black' }
  ];

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <Title level={2} style={{ color: '#2a1a4a', margin: 0 }}><TagsOutlined /> จัดการป้ายสถานะ / ขั้นตอน</Title>
        <Button type="primary" icon={<PlusOutlined />} size="large" style={{ backgroundColor: '#28a745' }} onClick={handleAdd}>
          เพิ่มสถานะใหม่
        </Button>
      </div>

      <Card style={{ borderRadius: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
        <Table columns={columns} dataSource={statuses} rowKey="status_id" loading={loading} pagination={false} />
      </Card>

      <Modal 
        title={editingStatus ? "✏️ แก้ไขป้ายสถานะ" : "➕ เพิ่มป้ายสถานะใหม่"} 
        open={isModalVisible} 
        onCancel={() => setIsModalVisible(false)}
        footer={null}
        destroyOnHidden
      >
        <Form form={form} layout="vertical" onFinish={handleSubmit}>
          <Form.Item name="status_name" label="ชื่อสถานะ (เช่น รอดำเนินการ, ตรวจสอบงาน)" rules={[{ required: true }]}>
            <Input placeholder="ระบุชื่อสถานะ" />
          </Form.Item>
          
          <Form.Item name="status_color" label="สีของป้าย" rules={[{ required: true }]}>
            <Select placeholder="เลือกสี" showSearch>
              {colorOptions.map(c => (
                <Option key={c.value} value={c.value}>
                  <Tag color={c.value}>{c.label}</Tag>
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item name="sort_order" label="ลำดับที่ (1 คือขั้นแรกสุด)" rules={[{ required: true }]}>
            <InputNumber min={1} max={99} style={{ width: '100%' }} />
          </Form.Item>

          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: 10 }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit">บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}