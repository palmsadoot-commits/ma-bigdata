import React, { useState, useEffect } from 'react';
import { Table, Button, Modal, Form, Input, Select, Space, Typography, InputNumber, DatePicker, Popconfirm, Row, Col } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, FileProtectOutlined } from '@ant-design/icons';
import axios from 'axios';
import dayjs from 'dayjs';
import { alertSuccess, alertError } from '../utils/alert';

const { Title, Text } = Typography;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000';

export default function ContractManagement() {
  const [contracts, setContracts] = useState([]);
  const [projects, setProjects] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingContract, setEditingContract] = useState(null);
  const [form] = Form.useForm();

  const fetchData = async () => {
    try {
      const [contRes, projRes, vendRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/contracts`),
        axios.get(`${BACKEND_URL}/api/projects`),
        axios.get(`${BACKEND_URL}/api/vendors`)
      ]);
      setContracts(contRes.data);
      setProjects(projRes.data);
      setVendors(vendRes.data);
    } catch (err) { alertError('โหลดข้อมูลไม่สำเร็จ'); }
  };

  useEffect(() => { fetchData(); }, []);

  const openModal = (contract = null) => {
    setEditingContract(contract);
    if (contract) {
      form.setFieldsValue({
        ...contract,
        start_date: contract.start_date ? dayjs(contract.start_date) : null,
        end_date: contract.end_date ? dayjs(contract.end_date) : null,
      });
    } else {
      form.resetFields();
    }
    setIsModalVisible(true);
  };

  const handleFinish = async (values) => {
    const data = {
      ...values,
      start_date: values.start_date ? values.start_date.format('YYYY-MM-DD') : null,
      end_date: values.end_date ? values.end_date.format('YYYY-MM-DD') : null,
    };
    try {
      if (editingContract) {
        await axios.put(`${BACKEND_URL}/api/contracts/${editingContract.contract_id}`, data);
        alertSuccess('อัปเดตสัญญาสำเร็จ');
      } else {
        await axios.post(`${BACKEND_URL}/api/contracts`, data);
        alertSuccess('เพิ่มสัญญาสำเร็จ');
      }
      setIsModalVisible(false);
      fetchData();
    } catch (error) { alertError('บันทึกไม่สำเร็จ'); }
  };

  const handleDelete = async (id) => {
    try {
        await axios.delete(`${BACKEND_URL}/api/contracts/${id}`);
        alertSuccess('ลบสัญญาสำเร็จ');
        fetchData();
    } catch (error) {
        alertError('ลบสัญญาไม่สำเร็จ');
    }
  }

  const columns = [
    { title: 'เลขที่สัญญา', dataIndex: 'contract_number', key: 'contract_number', render: (text) => <Text strong>{text}</Text> },
    { title: 'โครงการ', dataIndex: 'project_name', key: 'project_name' },
    { title: 'ผู้รับจ้าง', dataIndex: 'vendor_name', key: 'vendor_name' },
    { title: 'มูลค่าสัญญา', dataIndex: 'contract_value', render: (val) => `${parseFloat(val).toLocaleString()} ฿` },
    { title: 'ค่าปรับ/วัน (%)', dataIndex: 'penalty_rate', render: (val) => `${(val * 100).toFixed(2)}%` },
    {
      title: 'จัดการ', key: 'action', align: 'center',
      render: (_, record) => (
        <Space>
          <Button type="text" icon={<EditOutlined />} onClick={() => openModal(record)} />
          <Popconfirm title="ลบสัญญา?" onConfirm={() => handleDelete(record.contract_id)}>
            <Button type="text" danger icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      )
    }
  ];

  return (
    <div style={{ backgroundColor: '#fff', padding: 24, borderRadius: 8, margin: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
        <Title level={4}><FileProtectOutlined /> จัดการสัญญาและเงื่อนไขค่าปรับ</Title>
        <Button type="primary" icon={<PlusOutlined />} onClick={() => openModal()} style={{ borderRadius: 8 }}>เพิ่มสัญญา</Button>
      </div>
      <Table columns={columns} dataSource={contracts} rowKey="contract_id" />

      <Modal title={editingContract ? "แก้ไขสัญญา" : "เพิ่มสัญญาใหม่"} open={isModalVisible} onCancel={() => setIsModalVisible(false)} footer={null} width={700}>
        <Form form={form} layout="vertical" onFinish={handleFinish}>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="project_id" label="โครงการ" rules={[{ required: true, message: 'กรุณาเลือกโครงการ' }]}>
                <Select placeholder="เลือกโครงการ">
                  {projects.map(p => <Option key={p.project_id} value={p.project_id}>{p.project_name}</Option>)}
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="vendor_id" label="บริษัทผู้รับจ้าง" rules={[{ required: true, message: 'กรุณาเลือกผู้รับจ้าง' }]}>
                <Select placeholder="เลือกผู้รับจ้าง">
                  {vendors.map(v => <Option key={v.vendor_id} value={v.vendor_id}>{v.vendor_name}</Option>)}
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="contract_number" label="เลขที่สัญญา" rules={[{ required: true, message: 'กรุณากรอกเลขที่สัญญา' }]}>
                <Input placeholder="เช่น 19/2569" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="contract_value" label="มูลค่าสัญญา (บาท)" rules={[{ required: true, message: 'กรุณากรอกมูลค่าสัญญา' }]}>
                <InputNumber style={{ width: '100%' }} formatter={value => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="penalty_rate" label="อัตราค่าปรับต่อวัน (ทศนิยม)" tooltip="ร้อยละ 0.1 ให้ใส่ 0.001">
                <InputNumber step={0.0001} style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={12}>
                <Space style={{ width: '100%' }}>
                    <Form.Item name="start_date" label="วันเริ่มสัญญา">
                        <DatePicker style={{ width: '100%' }} format="DD/MM/YYYY" />
                    </Form.Item>
                    <Form.Item name="end_date" label="วันสิ้นสุดสัญญา">
                        <DatePicker style={{ width: '100%' }} format="DD/MM/YYYY" />
                    </Form.Item>
                </Space>
            </Col>
          </Row>
          <div style={{ textAlign: 'right', marginTop: 15 }}>
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: 10, borderRadius: 8 }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ borderRadius: 8 }}>บันทึกข้อมูล</Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
}