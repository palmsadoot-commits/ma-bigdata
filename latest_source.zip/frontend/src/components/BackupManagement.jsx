import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Typography, Button, Table, Space, Tag, Form, Radio, Checkbox, TimePicker, Popconfirm, Divider, Tabs, Select, Empty, message, Progress, Input } from 'antd';
import { 
  DatabaseOutlined, SettingOutlined, DownloadOutlined, RollbackOutlined, 
  CloudServerOutlined, SaveOutlined, DeleteOutlined, CheckCircleOutlined, 
  CloseCircleOutlined, CodeOutlined, FileZipOutlined, GithubOutlined
} from '@ant-design/icons';
import dayjs from 'dayjs';
import axios from 'axios';
import { alertSuccess, alertError, alertConfirm } from '../utils/alert';

const { Title, Text } = Typography;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000';

export default function BackupManagement() {
  const [logs, setLogs] = useState([]);
  const [sourceLogs, setSourceLogs] = useState([]);
  const [githubLogs, setGithubLogs] = useState([]); 
  
  const [loading, setLoading] = useState(false);
  const [sourceLoading, setSourceLoading] = useState(false);
  const [githubLoading, setGithubLoading] = useState(false); 
  
  // ✅ States สำหรับหลอด Loading แบบ % 
  const [isZipping, setIsZipping] = useState(false);
  const [zipProgress, setZipProgress] = useState(0);

  const [isDbBackingUp, setIsDbBackingUp] = useState(false);
  const [dbProgress, setDbProgress] = useState(0);

  const [isGithubPushing, setIsGithubPushing] = useState(false);
  const [githubProgress, setGithubProgress] = useState(0);

  const [form] = Form.useForm(); 
  const [sourceForm] = Form.useForm(); 
  const [githubForm] = Form.useForm(); 
  
  const fetchData = async () => {
    setLoading(true);
    try {
      const [logRes, settingRes, srcLogRes, srcSettingRes, githubLogRes, githubSettingRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/backup/logs`),
        axios.get(`${BACKEND_URL}/api/backup/settings`),
        axios.get(`${BACKEND_URL}/api/backup/source/logs`),
        axios.get(`${BACKEND_URL}/api/backup/source/settings`),
        axios.get(`${BACKEND_URL}/api/github/logs`),
        axios.get(`${BACKEND_URL}/api/github/settings`)
      ]);
      
      setLogs(logRes.data);
      setSourceLogs(srcLogRes.data);
      setGithubLogs(githubLogRes.data);
      
      if (settingRes.data) {
        form.setFieldsValue({
          schedule_type: settingRes.data.schedule_type,
          schedule_days: settingRes.data.schedule_type === 'weekly' ? settingRes.data.schedule_days.split(',') : settingRes.data.schedule_days,
          schedule_time: dayjs(settingRes.data.schedule_time, 'HH:mm:ss'),
          is_active: settingRes.data.is_active === 1
        });
      }

      if (srcSettingRes.data) {
        sourceForm.setFieldsValue({
          target_folders: srcSettingRes.data.target_folders ? srcSettingRes.data.target_folders.split(',') : ['frontend', 'backend'],
          schedule_type: srcSettingRes.data.schedule_type,
          schedule_days: srcSettingRes.data.schedule_type === 'weekly' ? srcSettingRes.data.schedule_days.split(',') : srcSettingRes.data.schedule_days,
          schedule_time: dayjs(srcSettingRes.data.schedule_time, 'HH:mm:ss'),
          is_active: srcSettingRes.data.is_active === 1
        });
      }

      if (githubSettingRes.data) {
        githubForm.setFieldsValue({
          github_token: githubSettingRes.data.github_token,
          repo_url: githubSettingRes.data.repo_url,
          branch_name: githubSettingRes.data.branch_name || 'main',
          sync_targets: githubSettingRes.data.sync_targets ? githubSettingRes.data.sync_targets.split(',') : ['database', 'source'],
          schedule_type: githubSettingRes.data.schedule_type || 'daily',
          schedule_days: githubSettingRes.data.schedule_type === 'weekly' ? (githubSettingRes.data.schedule_days ? githubSettingRes.data.schedule_days.split(',') : []) : githubSettingRes.data.schedule_days,
          schedule_time: dayjs(githubSettingRes.data.schedule_time || '05:00:00', 'HH:mm:ss'),
          is_active: githubSettingRes.data.is_active === 1
        });
      }

    } catch (err) {
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูล Backup ได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  // ==========================================
  // 💻 ฟังก์ชัน: Source Code Backup (Tab 1)
  // ==========================================
  const handleSaveSourceSettings = async (values) => {
    try {
      let days = '';
      if (values.schedule_type === 'weekly') days = values.schedule_days ? values.schedule_days.join(',') : '';
      else if (values.schedule_type === 'monthly') days = values.schedule_days || '1';

      const payload = {
        target_folders: values.target_folders ? values.target_folders.join(',') : '',
        schedule_type: values.schedule_type,
        schedule_days: days,
        schedule_time: values.schedule_time.format('HH:mm:ss'),
        is_active: values.is_active ? 1 : 0
      };
      await axios.put(`${BACKEND_URL}/api/backup/source/settings`, payload);
      alertSuccess('บันทึกสำเร็จ', 'อัปเดตเวลาสำรอง Source Code เรียบร้อยแล้ว');
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่าได้');
    }
  };

  const handleManualSourceBackup = async () => {
    const folders = sourceForm.getFieldValue('target_folders');
    if (!folders || folders.length === 0) return alertError('ผิดพลาด', 'กรุณาเลือกโฟลเดอร์ที่ต้องการบีบอัดอย่างน้อย 1 รายการ');
    
    setIsZipping(true);
    setZipProgress(0);

    const progressInterval = setInterval(() => {
      setZipProgress(prev => prev >= 90 ? prev : prev + Math.floor(Math.random() * 10) + 1);
    }, 500);

    try {
      await axios.post(`${BACKEND_URL}/api/backup/source/manual`, { target_folders: folders });
      clearInterval(progressInterval);
      setZipProgress(100);
      setTimeout(() => {
        setIsZipping(false);
        message.success({ content: 'บีบอัดไฟล์เสร็จสมบูรณ์!', key: 'zipping', duration: 3 });
        fetchData();
      }, 500);
    } catch (error) {
      clearInterval(progressInterval);
      setIsZipping(false);
      setZipProgress(0);
      message.error({ content: 'เกิดข้อผิดพลาดในการบีบอัดไฟล์!', key: 'zipping', duration: 3 });
    }
  };

  const handleDeleteSource = async (fileName) => {
    try {
      setSourceLoading(true);
      await axios.delete(`${BACKEND_URL}/api/backup/source/${fileName}`);
      alertSuccess('ลบสำเร็จ', 'ลบไฟล์ Zip ออกจากระบบแล้ว');
      fetchData();
    } catch (error) { alertError('ผิดพลาด', 'ไม่สามารถลบไฟล์ได้'); } finally { setSourceLoading(false); }
  };


  // ==========================================
  // 🗄️ ฟังก์ชัน: Database Backup (Tab 2)
  // ==========================================
  const handleSaveSettings = async (values) => {
    try {
      let days = '';
      if (values.schedule_type === 'weekly') days = values.schedule_days ? values.schedule_days.join(',') : '';
      else if (values.schedule_type === 'monthly') days = values.schedule_days || '1';

      const payload = {
        schedule_type: values.schedule_type,
        schedule_days: days,
        schedule_time: values.schedule_time.format('HH:mm:ss'),
        is_active: values.is_active ? 1 : 0
      };
      await axios.put(`${BACKEND_URL}/api/backup/settings`, payload);
      alertSuccess('บันทึกสำเร็จ', 'อัปเดตเวลาสำรองข้อมูล Database แล้ว');
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่าได้');
    }
  };

  const handleManualBackup = async () => {
    setIsDbBackingUp(true);
    setDbProgress(0);

    const progressInterval = setInterval(() => {
      setDbProgress(prev => prev >= 90 ? prev : prev + Math.floor(Math.random() * 10) + 1);
    }, 400);

    try {
      await axios.post(`${BACKEND_URL}/api/backup/manual`);
      clearInterval(progressInterval);
      setDbProgress(100);
      setTimeout(() => {
        setIsDbBackingUp(false);
        alertSuccess('แบ็คอัพสำเร็จ', 'สำรองข้อมูลฐานข้อมูลเรียบร้อยแล้ว');
        fetchData();
      }, 500);
    } catch (error) {
      clearInterval(progressInterval);
      setIsDbBackingUp(false);
      setDbProgress(0);
      alertError('ผิดพลาด', 'การสำรองข้อมูลล้มเหลว');
    }
  };

  const handleRestore = async (fileName) => {
    const result = await alertConfirm('อันตราย! ยืนยันการกู้คืน?', `ข้อมูลปัจจุบันทั้งหมดจะถูกเขียนทับด้วยไฟล์ ${fileName} คุณแน่ใจหรือไม่?`);
    if (result.isConfirmed) {
      try {
        setLoading(true);
        await axios.post(`${BACKEND_URL}/api/backup/restore`, { file_name: fileName });
        alertSuccess('กู้คืนสำเร็จ', 'กู้คืนฐานข้อมูลเรียบร้อยแล้ว ระบบพร้อมใช้งาน');
        fetchData();
      } catch (error) { alertError('ผิดพลาด', 'การกู้คืนข้อมูลล้มเหลว'); } finally { setLoading(false); }
    }
  };

  const handleDelete = async (fileName) => {
    try {
      setLoading(true);
      await axios.delete(`${BACKEND_URL}/api/backup/${fileName}`);
      alertSuccess('ลบสำเร็จ', 'ลบไฟล์สำรองข้อมูลออกจากระบบแล้ว');
      fetchData();
    } catch (error) { alertError('ผิดพลาด', 'ไม่สามารถลบไฟล์ได้'); } finally { setLoading(false); }
  };


  // ==========================================
  // 🐙 ฟังก์ชัน: GitHub Sync (Tab 3)
  // ==========================================
  const handleSaveGithubSettings = async (values) => {
    try {
      let days = '';
      if (values.schedule_type === 'weekly') days = values.schedule_days ? values.schedule_days.join(',') : '';
      else if (values.schedule_type === 'monthly') days = values.schedule_days || '1';

      const payload = {
        github_token: values.github_token,
        repo_url: values.repo_url,
        branch_name: values.branch_name,
        sync_targets: values.sync_targets ? values.sync_targets.join(',') : '',
        schedule_type: values.schedule_type,
        schedule_days: days,
        schedule_time: values.schedule_time.format('HH:mm:ss'),
        is_active: values.is_active ? 1 : 0
      };
      
      await axios.put(`${BACKEND_URL}/api/github/settings`, payload);
      alertSuccess('บันทึกสำเร็จ', 'อัปเดตการตั้งค่า GitHub เรียบร้อยแล้ว');
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่า GitHub ได้');
    }
  };

  const handleManualGithubPush = async () => {
    const targets = githubForm.getFieldValue('sync_targets');
    if (!targets || targets.length === 0) return alertError('ผิดพลาด', 'กรุณาเลือกข้อมูลที่ต้องการ Push อย่างน้อย 1 รายการ');

    setIsGithubPushing(true);
    setGithubProgress(0);

    const progressInterval = setInterval(() => {
      setGithubProgress(prev => prev >= 90 ? prev : prev + Math.floor(Math.random() * 5) + 1);
    }, 400);

    try {
      const res = await axios.post(`${BACKEND_URL}/api/github/manual`, { sync_targets: targets });
      
      clearInterval(progressInterval);
      setGithubProgress(100);

      setTimeout(() => {
        setIsGithubPushing(false);
        message.success({ content: `สำเร็จ! ${res.data.message}`, key: 'githubPush', duration: 4 });
        fetchData();
      }, 500);

    } catch (error) {
      clearInterval(progressInterval);
      setIsGithubPushing(false);
      setGithubProgress(0);
      const errMsg = error.response?.data?.error || 'เกิดข้อผิดพลาดในการ Push ตรวจสอบ Token และ URL';
      message.error({ content: errMsg, key: 'githubPush', duration: 5 });
      fetchData(); 
    }
  };


  // ==========================================
  // ⚙️ การตั้งค่า Column ในตาราง
  // ==========================================
  const columns = [
    { title: 'ชื่อไฟล์', dataIndex: 'file_name', key: 'file_name', align: 'center', render: (text, record) => <Text strong style={{ color: '#0369a1' }}><DatabaseOutlined /> db_{dayjs(record.created_at).format('DD-MM-YYYY')}.sql</Text> },
    { title: 'ขนาดไฟล์', dataIndex: 'file_size', key: 'file_size', align: 'center' },
    { title: 'วันที่ทำรายการ', dataIndex: 'created_at', key: 'created_at', align: 'center', render: date => dayjs(date).format('DD/MM/YYYY HH:mm:ss') },
    { title: 'สถานะ', dataIndex: 'status', key: 'status', align: 'center', render: status => status.includes('Success') ? <Tag color="success" icon={<CheckCircleOutlined />}>สำเร็จ</Tag> : <Tag color="error" icon={<CloseCircleOutlined />}>ล้มเหลว</Tag> },
    { title: 'จัดการ', key: 'action', align: 'center', render: (_, record) => (
        <Space>
          <Button size="small" type="dashed" icon={<DownloadOutlined />} href={`${BACKEND_URL}/backups/${record.file_name}`} target="_blank">โหลด</Button>
          <Button size="small" type="primary" style={{ backgroundColor: '#f59e0b', borderColor: '#f59e0b' }} icon={<RollbackOutlined />} onClick={() => handleRestore(record.file_name)} disabled={!record.status.includes('Success')}>กู้คืน</Button>
          <Popconfirm title="ยืนยันการลบ?" onConfirm={() => handleDelete(record.file_name)}><Button size="small" type="primary" danger icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    }
  ];

  const sourceColumns = [
    { title: 'ชื่อไฟล์', dataIndex: 'file_name', key: 'file_name', align: 'center', render: (text, record) => <Text strong style={{ color: '#6d28d9' }}><FileZipOutlined /> src_{dayjs(record.created_at).format('DD-MM-YYYY')}.zip</Text> },
    { title: 'เป้าหมาย', dataIndex: 'target_folders', key: 'target_folders', align: 'center', render: folders => (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
           {folders?.includes('frontend') && <Text type="secondary" style={{fontSize: '12px'}}>- Frontend</Text>}
           {folders?.includes('backend') && <Text type="secondary" style={{fontSize: '12px'}}>- Backend</Text>}
           {folders?.includes('node_modules') && <Text type="danger" style={{fontSize: '12px'}}>- node_modules</Text>}
        </div>
      )
    },
    { title: 'ขนาดไฟล์', dataIndex: 'file_size', key: 'file_size', align: 'center' },
    { title: 'วันที่ทำรายการ', dataIndex: 'created_at', key: 'created_at', align: 'center', render: date => dayjs(date).format('DD/MM/YYYY HH:mm:ss') },
    { title: 'สถานะ', dataIndex: 'status', key: 'status', align: 'center', render: status => status.includes('Success') ? <Tag color="success" icon={<CheckCircleOutlined />}>สำเร็จ</Tag> : <Tag color="error" icon={<CloseCircleOutlined />}>ล้มเหลว</Tag> },
    { title: 'จัดการ', key: 'action', align: 'center', render: (_, record) => (
        <Space>
          <Button size="small" type="dashed" icon={<DownloadOutlined />} href={`${BACKEND_URL}/backups/source/${record.file_name}`} target="_blank">โหลด</Button>
          <Popconfirm title="ยืนยันการลบ?" onConfirm={() => handleDeleteSource(record.file_name)}><Button size="small" type="primary" danger icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    }
  ];

  const githubColumns = [
    { title: 'เป้าหมายที่ Sync', dataIndex: 'sync_targets', key: 'sync_targets', align: 'center', render: folders => (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
           {folders?.includes('database') && <Text type="secondary" style={{fontSize: '12px'}}><DatabaseOutlined/> ล่าสุด (.sql)</Text>}
           {folders?.includes('source') && <Text type="secondary" style={{fontSize: '12px'}}><FileZipOutlined/> ล่าสุด (.zip)</Text>}
        </div>
      )
    },
    { title: 'สถานะ', dataIndex: 'status', key: 'status', align: 'center', render: status => status.includes('สำเร็จ') ? <Tag color="success" icon={<CheckCircleOutlined />}>{status}</Tag> : <Tag color="error" icon={<CloseCircleOutlined />}>{status}</Tag> },
    { title: 'ผู้ทำรายการ', dataIndex: 'created_by', key: 'created_by', align: 'center', render: text => <Tag color="default"><GithubOutlined /> {text}</Tag> },
    { title: 'วันที่ทำรายการ', dataIndex: 'created_at', key: 'created_at', align: 'center', render: date => dayjs(date).format('DD/MM/YYYY HH:mm:ss') }
  ];

  const weekOptions = [
    { label: 'จ.', value: '1' }, { label: 'อ.', value: '2' }, { label: 'พ.', value: '3' },
    { label: 'พฤ.', value: '4' }, { label: 'ศ.', value: '5' }, { label: 'ส.', value: '6' }, { label: 'อา.', value: '0' }
  ];
  const monthOptions = Array.from({ length: 31 }, (_, i) => ({ label: `วันที่ ${i + 1}`, value: `${i + 1}` }));

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <Title level={2} style={{ color: '#1e293b', margin: 0 }}>
            <CloudServerOutlined style={{ color: '#0ea5e9', marginRight: '8px' }}/> ระบบจัดการสำรองข้อมูลและกู้คืน (Database & Source Code)
          </Title>
        </div>
      </div>

      <style>{`
        .backup-tabs .ant-tabs-tab { padding: 12px 24px; font-size: 16px; border-radius: 8px 8px 0 0 !important; }
        .backup-tabs .ant-tabs-tab-active { background-color: #0ea5e9 !important; border-bottom: none !important; }
        .backup-tabs .ant-tabs-tab-active .ant-tabs-tab-btn { color: #ffffff !important; }
      `}</style>

      <Tabs 
        type="card" 
        className="backup-tabs"
        items={[
          // ==========================================
          // TAB 1: Source Code
          // ==========================================
          {
            key: '1',
            label: <span><CodeOutlined /> สำรองข้อมูล (Source Code)</span>,
            forceRender: true,
            children: (
              <Row gutter={[24, 24]} style={{ marginTop: '10px' }}>
                <Col xs={24} lg={8}>
                  <Card 
                    title={<><SettingOutlined /> ตั้งค่าและสำรอง Source Code</>}
                    variant="borderless"
                    style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 15px rgba(0,0,0,0.02)' }}
                    styles={{ header: { backgroundColor: '#faf5ff', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                  >
                    <Form form={sourceForm} layout="vertical" onFinish={handleSaveSourceSettings}>
                      <Form.Item name="target_folders" label={<Text strong>เลือกส่วนที่ต้องการบีบอัด (.zip)</Text>}>
                        <Checkbox.Group style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          <Checkbox value="frontend"><Text strong>1. Frontend (React)</Text></Checkbox>
                          <Checkbox value="backend"><Text strong>2. Backend (Node.js/Express)</Text></Checkbox>
                          <Checkbox value="node_modules"><Text type="danger">3. รวมโฟลเดอร์ node_modules (ระวังไฟล์ใหญ่มาก)</Text></Checkbox>
                        </Checkbox.Group>
                      </Form.Item>

                      <Divider style={{ margin: '15px 0' }}/>

                      <Form.Item name="is_active" valuePropName="checked" style={{ backgroundColor: '#faf5ff', padding: '10px 15px', borderRadius: 8, border: '1px solid #d8b4fe' }}>
                        <Checkbox><Text strong style={{ color: '#7e22ce' }}>เปิดใช้งาน Auto Backup (Source Code)</Text></Checkbox>
                      </Form.Item>
                      
                      <Form.Item name="schedule_type" label={<Text strong>รูปแบบรอบการทำงาน</Text>}>
                        <Radio.Group buttonStyle="solid" style={{ width: '100%' }}>
                          <Radio.Button value="daily" style={{ width: '30.33%', textAlign: 'center' }}>รายวัน</Radio.Button>
                          <Radio.Button value="weekly" style={{ width: '37.34%', textAlign: 'center' }}>รายสัปดาห์</Radio.Button>
                          <Radio.Button value="monthly" style={{ width: '32.33%', textAlign: 'center' }}>รายเดือน</Radio.Button>
                        </Radio.Group>
                      </Form.Item>

                      <Form.Item noStyle shouldUpdate={(prev, current) => prev.schedule_type !== current.schedule_type}>
                        {({ getFieldValue }) => {
                          const type = getFieldValue('schedule_type');
                          if (type === 'weekly') return (
                            <Form.Item name="schedule_days" label={<Text strong>เลือกวันในสัปดาห์</Text>}>
                              <Checkbox.Group options={weekOptions} style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }} />
                            </Form.Item>
                          );
                          if (type === 'monthly') return (
                            <Form.Item name="schedule_days" label={<Text strong>เลือกวันที่ของทุกเดือน</Text>}>
                              <Select placeholder="เลือกวันที่" size="large" options={monthOptions} />
                            </Form.Item>
                          );
                          return null;
                        }}
                      </Form.Item>

                      <Form.Item name="schedule_time" label={<Text strong>เวลาที่ระบบประมวลผล (แนะนำ 04:00 น.)</Text>}>
                        <TimePicker format="HH:mm" style={{ width: '100%' }} size="large" />
                      </Form.Item>

                      <Divider style={{ margin: '15px 0' }}/>
                      <Button type="primary" htmlType="submit" icon={<SaveOutlined />} block size="large" style={{ backgroundColor: '#8b5cf6' }}>
                        บันทึกการตั้งเวลา Source Code
                      </Button>
                    </Form>
                  </Card>
                </Col>

                <Col xs={24} lg={16}>
                  <Card 
                    title={<span><CodeOutlined /> ประวัติการสำรอง Source Code (Zip)</span>} 
                    extra={
                      <Button type="primary" icon={<FileZipOutlined />} onClick={handleManualSourceBackup} disabled={isZipping} style={{ backgroundColor: '#8b5cf6', whiteSpace: 'nowrap' }}>
                        {isZipping ? 'กำลังประมวลผล...' : 'เริ่มบีบอัด Source Code ทันที'}
                      </Button>
                    }
                    variant="borderless"
                    style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 15px rgba(0,0,0,0.02)' }}
                    styles={{ header: { backgroundColor: '#faf5ff', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                  >
                    {isZipping && (
                      <div style={{ padding: '0 20px 20px' }}>
                        <Text strong style={{ color: '#8b5cf6' }}>กำลังรวมและบีบอัดไฟล์...</Text>
                        <Progress percent={zipProgress} status="active" strokeColor="#8b5cf6" />
                      </div>
                    )}

                    <Table 
                      columns={sourceColumns} 
                      dataSource={sourceLogs} 
                      rowKey="log_id" 
                      pagination={{ pageSize: 8 }} 
                      loading={sourceLoading}
                      size="middle"
                      scroll={{ x: 'max-content' }} 
                      locale={{ emptyText: <Empty description="ยังไม่มีประวัติการสำรอง Source Code" /> }}
                    />
                  </Card>
                </Col>
              </Row>
            )
          },
          // ==========================================
          // TAB 2: Database 
          // ==========================================
          {
            key: '2',
            label: <span><DatabaseOutlined /> สำรองข้อมูล (Database)</span>,
            forceRender: true,
            children: (
              <Row gutter={[24, 24]} style={{ marginTop: '10px' }}>
                <Col xs={24} lg={8}>
                  <Card 
                    title={<><SettingOutlined /> ตั้งเวลาสำรองข้อมูลอัตโนมัติ</>}
                    variant="borderless" style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 15px rgba(0,0,0,0.02)' }}
                    styles={{ header: { backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                  >
                    <Form form={form} layout="vertical" onFinish={handleSaveSettings}>
                      <Form.Item name="is_active" valuePropName="checked" style={{ backgroundColor: '#f0fdf4', padding: '10px 15px', borderRadius: 8, border: '1px solid #bbf7d0' }}>
                        <Checkbox><Text strong style={{ color: '#16a34a' }}>เปิดใช้งาน Auto Backup (Database)</Text></Checkbox>
                      </Form.Item>
                      <Form.Item name="schedule_type" label={<Text strong>รูปแบบรอบการทำงาน</Text>}>
                        <Radio.Group buttonStyle="solid" style={{ width: '100%' }}>
                          <Radio.Button value="daily" style={{ width: '30.33%', textAlign: 'center' }}>รายวัน</Radio.Button>
                          <Radio.Button value="weekly" style={{ width: '37.34%', textAlign: 'center' }}>รายสัปดาห์</Radio.Button>
                          <Radio.Button value="monthly" style={{ width: '32.33%', textAlign: 'center' }}>รายเดือน</Radio.Button>
                        </Radio.Group>
                      </Form.Item>
                      <Form.Item noStyle shouldUpdate={(prev, current) => prev.schedule_type !== current.schedule_type}>
                        {({ getFieldValue }) => {
                          const type = getFieldValue('schedule_type');
                          if (type === 'weekly') return <Form.Item name="schedule_days" label={<Text strong>เลือกวันในสัปดาห์</Text>}><Checkbox.Group options={weekOptions} style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }} /></Form.Item>;
                          if (type === 'monthly') return <Form.Item name="schedule_days" label={<Text strong>เลือกวันที่ของทุกเดือน</Text>}><Select placeholder="เลือกวันที่" size="large" options={monthOptions} /></Form.Item>;
                          return null;
                        }}
                      </Form.Item>
                      <Form.Item name="schedule_time" label={<Text strong>เวลาที่ระบบประมวลผล (แนะนำ 02:00 น.)</Text>}><TimePicker format="HH:mm" style={{ width: '100%' }} size="large" /></Form.Item>
                      <Divider style={{ margin: '15px 0' }}/><Button type="primary" htmlType="submit" icon={<SaveOutlined />} block size="large" style={{ backgroundColor: '#0ea5e9' }}>บันทึกการตั้งเวลา DB</Button>
                    </Form>
                  </Card>
                </Col>

                <Col xs={24} lg={16}>
                  <Card 
                    title={<span><DatabaseOutlined /> ประวัติการสำรองฐานข้อมูล</span>} 
                    extra={
                      <Button type="primary" icon={<DatabaseOutlined />} onClick={handleManualBackup} disabled={isDbBackingUp} style={{ backgroundColor: '#10b981', whiteSpace: 'nowrap' }}>
                        {isDbBackingUp ? 'กำลังประมวลผล...' : 'สำรอง DB ทันที'}
                      </Button>
                    }
                    variant="borderless" style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 15px rgba(0,0,0,0.02)' }}
                    styles={{ header: { backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                  >
                    {isDbBackingUp && (
                      <div style={{ padding: '0 20px 20px' }}>
                        <Text strong style={{ color: '#10b981' }}>กำลังส่งออกไฟล์ฐานข้อมูล...</Text>
                        <Progress percent={dbProgress} status="active" strokeColor="#10b981" />
                      </div>
                    )}
                    <Table columns={columns} dataSource={logs} rowKey="log_id" pagination={{ pageSize: 8 }} loading={loading && !isDbBackingUp} size="middle" scroll={{ x: 'max-content' }} />
                  </Card>
                </Col>
              </Row>
            )
          },
          // ==========================================
          // TAB 3: GitHub Sync
          // ==========================================
          {
            key: '3',
            label: <span><GithubOutlined /> อัปโหลดขึ้น Cloud (GitHub)</span>,
            forceRender: true,
            children: (
              <Row gutter={[24, 24]} style={{ marginTop: '10px' }}>
                <Col xs={24} lg={10}>
                  <Card 
                    title={<><SettingOutlined /> ตั้งค่า GitHub (Auto Push)</>}
                    variant="borderless"
                    style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 15px rgba(0,0,0,0.02)' }}
                    styles={{ header: { backgroundColor: '#1f2937', color: '#fff', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                  >
                    <Form form={githubForm} layout="vertical" onFinish={handleSaveGithubSettings}>
                      
                      <Form.Item name="is_active" valuePropName="checked" style={{ backgroundColor: '#f3f4f6', padding: '10px 15px', borderRadius: 8, border: '1px solid #d1d5db' }}>
                        <Checkbox><Text strong>เปิดใช้งาน Auto Push ไปยัง GitHub</Text></Checkbox>
                      </Form.Item>

                      <Form.Item label={<Text strong>GitHub Token (PAT)</Text>} name="github_token" rules={[{ required: true, message: 'กรุณากรอก Token' }]}>
                        <Input.Password placeholder="ghp_xxxxxxxxxxxx" size="large" />
                      </Form.Item>

                      <Form.Item label={<Text strong>Repository URL</Text>} name="repo_url" rules={[{ required: true, message: 'กรุณากรอก URL' }]}>
                        <Input placeholder="https://github.com/user/repo.git" size="large" />
                      </Form.Item>

                      <Form.Item label={<Text strong>Branch เป้าหมาย</Text>} name="branch_name" initialValue="main">
                        <Input placeholder="main" size="large" />
                      </Form.Item>

                      <Form.Item name="sync_targets" label={<Text strong>ข้อมูลที่ต้องการ Push</Text>}>
                        <Checkbox.Group style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                          <Checkbox value="database"><Text strong>ไฟล์ .sql (Database Dump ล่าสุด)</Text></Checkbox>
                          <Checkbox value="source"><Text strong>ไฟล์ Source Code ทั้งโปรเจกต์ (.zip)</Text></Checkbox>
                        </Checkbox.Group>
                      </Form.Item>

                      <Divider style={{ margin: '15px 0' }}/>
                      
                      <Form.Item name="schedule_type" label={<Text strong>รอบการทำงาน</Text>}>
                        <Radio.Group buttonStyle="solid" style={{ width: '100%' }}>
                          <Radio.Button value="daily" style={{ width: '50%', textAlign: 'center' }}>รายวัน</Radio.Button>
                          <Radio.Button value="weekly" style={{ width: '50%', textAlign: 'center' }}>รายสัปดาห์</Radio.Button>
                        </Radio.Group>
                      </Form.Item>

                      <Form.Item noStyle shouldUpdate={(prev, current) => prev.schedule_type !== current.schedule_type}>
                        {({ getFieldValue }) => {
                          const type = getFieldValue('schedule_type');
                          if (type === 'weekly') return <Form.Item name="schedule_days" label={<Text strong>เลือกวันในสัปดาห์</Text>}><Checkbox.Group options={weekOptions} style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }} /></Form.Item>;
                          return null;
                        }}
                      </Form.Item>

                      <Form.Item name="schedule_time" label={<Text strong>เวลาดำเนินการ (แนะนำ 05:00 น.)</Text>}>
                        <TimePicker format="HH:mm" style={{ width: '100%' }} size="large" />
                      </Form.Item>

                      <Button type="primary" htmlType="submit" icon={<SaveOutlined />} block size="large" style={{ backgroundColor: '#111827' }}>
                        บันทึกการตั้งค่า GitHub
                      </Button>
                    </Form>
                  </Card>
                </Col>

                <Col xs={24} lg={14}>
                  <Card 
                    title={<span><GithubOutlined /> ประวัติการ Push ไปยัง GitHub</span>} 
                    extra={
                      <Button type="primary" icon={<GithubOutlined />} onClick={handleManualGithubPush} disabled={isGithubPushing} style={{ backgroundColor: '#111827', whiteSpace: 'nowrap' }}>
                        {isGithubPushing ? 'กำลังประมวลผล...' : 'Push ขึ้น GitHub ทันที'}
                      </Button>
                    }
                    variant="borderless"
                    style={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 15px rgba(0,0,0,0.02)', height: '100%' }}
                    styles={{ header: { backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0', borderRadius: '12px 12px 0 0' } }}
                  >
                    {isGithubPushing && (
                      <div style={{ padding: '0 20px 20px' }}>
                        <Text strong style={{ color: '#111827' }}>กำลังเชื่อมต่อและส่งข้อมูลขึ้น Cloud...</Text>
                        <Progress percent={githubProgress} status="active" strokeColor="#111827" />
                      </div>
                    )}
                    <Table 
                      columns={githubColumns} 
                      dataSource={githubLogs} 
                      rowKey="log_id" 
                      pagination={{ pageSize: 8 }} 
                      loading={githubLoading && !isGithubPushing}
                      size="middle"
                      scroll={{ x: 'max-content' }} 
                      locale={{ emptyText: <Empty description="ยังไม่มีประวัติการ Push ขึ้น GitHub" /> }}
                    />
                  </Card>
                </Col>
              </Row>
            )
          }
        ]}
      />
    </div>
  );
}