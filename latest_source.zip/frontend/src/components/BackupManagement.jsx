import React, { useState, useEffect } from 'react';
import { 
  Card, Row, Col, Typography, Button, Table, Space, Tag, Form, Radio, Checkbox, 
  TimePicker, Popconfirm, Divider, Tabs, Select, Empty, message, Progress, 
  Input, Calendar, Tooltip, ConfigProvider, App 
} from 'antd';
import { 
  DatabaseOutlined, SettingOutlined, DownloadOutlined, RollbackOutlined, 
  CloudServerOutlined, SaveOutlined, DeleteOutlined, CheckCircleOutlined, 
  CloseCircleOutlined, CodeOutlined, FileZipOutlined, GithubOutlined, 
  CalendarOutlined, LeftOutlined, RightOutlined, SyncOutlined
} from '@ant-design/icons';
import dayjs from 'dayjs';
import axiosInstance from '../services/api/axiosInstance';
import { alertSuccess, alertError, alertConfirm } from '../utils/alert';

// 🇹🇭 โหลดภาษาไทยให้กับ Ant Design และ DayJS
import thTH from 'antd/locale/th_TH';
import 'dayjs/locale/th';
dayjs.locale('th');

const { Title, Text } = Typography;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000'; // สำหรับ Download Link

export default function BackupManagement() {
  const { message: msg, modal } = App.useApp();
  
  const [logs, setLogs] = useState([]);
  const [sourceLogs, setSourceLogs] = useState([]);
  const [githubLogs, setGithubLogs] = useState([]); 
  
  const [activeTab, setActiveTab] = useState('0');
  const [calendarValue, setCalendarValue] = useState(() => dayjs());
  
  const [dbSetting, setDbSetting] = useState(null);
  const [sourceSetting, setSourceSetting] = useState(null);
  const [githubSetting, setGithubSetting] = useState(null);
  
  const [loading, setLoading] = useState(false);
  const [sourceLoading, setSourceLoading] = useState(false);
  const [githubLoading, setGithubLoading] = useState(false); 
  
  const [isZipping, setIsZipping] = useState(false);
  const [zipProgress, setZipProgress] = useState(0);

  const [isDbBackingUp, setIsDbBackingUp] = useState(false);
  const [dbProgress, setDbProgress] = useState(0);

  const [isGithubPushing, setIsGithubPushing] = useState(false);
  const [githubProgress, setGithubProgress] = useState(0);

  const [form] = Form.useForm(); 
  const [sourceForm] = Form.useForm(); 
  const [githubForm] = Form.useForm(); 
  
  const fetchData = async () => {
    setLoading(true);
    try {
      const [logRes, settingRes, srcLogRes, srcSettingRes, githubLogRes, githubSettingRes] = await Promise.all([
        axiosInstance.get('/backup/logs'),
        axiosInstance.get('/backup/settings'),
        axiosInstance.get('/backup/source/logs'),
        axiosInstance.get('/backup/source/settings'),
        axiosInstance.get('/backup/github/logs'),
        axiosInstance.get('/backup/github/settings')
      ]);
      
      setLogs(logRes.data || []);
      setSourceLogs(srcLogRes.data || []);
      setGithubLogs(githubLogRes.data || []);
      
      setDbSetting(settingRes.data);
      setSourceSetting(srcSettingRes.data);
      setGithubSetting(githubSettingRes.data);
      
      if (settingRes.data) {
        form.setFieldsValue({
          schedule_type: settingRes.data.schedule_type,
          schedule_days: settingRes.data.schedule_type === 'weekly' ? settingRes.data.schedule_days?.split(',') : settingRes.data.schedule_days,
          schedule_time: dayjs(settingRes.data.schedule_time, 'HH:mm:ss'),
          is_active: settingRes.data.is_active === 1
        });
      }

      if (srcSettingRes.data) {
        sourceForm.setFieldsValue({
          target_folders: srcSettingRes.data.target_folders ? srcSettingRes.data.target_folders.split(',') : ['frontend', 'backend'],
          schedule_type: srcSettingRes.data.schedule_type,
          schedule_days: srcSettingRes.data.schedule_type === 'weekly' ? srcSettingRes.data.schedule_days?.split(',') : srcSettingRes.data.schedule_days,
          schedule_time: dayjs(srcSettingRes.data.schedule_time, 'HH:mm:ss'),
          is_active: srcSettingRes.data.is_active === 1
        });
      }

      if (githubSettingRes.data) {
        githubForm.setFieldsValue({
          github_token: githubSettingRes.data.github_token,
          repo_url: githubSettingRes.data.repo_url,
          branch_name: githubSettingRes.data.branch_name || 'main',
          sync_targets: githubSettingRes.data.sync_targets ? githubSettingRes.data.sync_targets.split(',') : ['database', 'source'],
          schedule_type: githubSettingRes.data.schedule_type || 'daily',
          schedule_days: githubSettingRes.data.schedule_type === 'weekly' ? (githubSettingRes.data.schedule_days ? githubSettingRes.data.schedule_days.split(',') : []) : githubSettingRes.data.schedule_days,
          schedule_time: dayjs(githubSettingRes.data.schedule_time || '05:00:00', 'HH:mm:ss'),
          is_active: githubSettingRes.data.is_active === 1
        });
      }

    } catch (err) {
      console.error(err);
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูล Backup ได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const checkScheduleMatch = (date, setting) => {
    if (!setting || setting.is_active !== 1) return false;
    if (setting.schedule_type === 'daily') return true;
    if (setting.schedule_type === 'weekly') {
      const days = setting.schedule_days ? setting.schedule_days.split(',') : [];
      return days.includes(String(date.day())); 
    }
    if (setting.schedule_type === 'monthly') {
      return String(date.date()) === String(setting.schedule_days);
    }
    return false;
  };

  const getListData = (value) => {
    const listData = [];
    const dateString = value.format('YYYY-MM-DD');
    const isToday = value.isSame(dayjs(), 'day');
    const isFuture = value.isAfter(dayjs(), 'day');

    let hasDbLog = false, hasSrcLog = false, hasGitLog = false;

    logs.forEach(log => {
      if (dayjs(log.created_at).format('YYYY-MM-DD') === dateString) {
        const isSuccess = log.status.includes('Success');
        listData.push({ type: 'db', status: isSuccess ? 'success' : 'error', time: dayjs(log.created_at).format('HH:mm'), content: 'DB Backup' });
        hasDbLog = true;
      }
    });

    sourceLogs.forEach(log => {
      if (dayjs(log.created_at).format('YYYY-MM-DD') === dateString) {
        const isSuccess = log.status.includes('Success');
        listData.push({ type: 'src', status: isSuccess ? 'success' : 'error', time: dayjs(log.created_at).format('HH:mm'), content: 'Code Backup' });
        hasSrcLog = true;
      }
    });

    githubLogs.forEach(log => {
      if (dayjs(log.created_at).format('YYYY-MM-DD') === dateString) {
        const isSuccess = log.status.includes('สำเร็จ') || log.status.includes('Success'); 
        listData.push({ type: 'git', status: isSuccess ? 'success' : 'error', time: dayjs(log.created_at).format('HH:mm'), content: 'Git Push' });
        hasGitLog = true;
      }
    });

    if (isFuture || isToday) {
      if (checkScheduleMatch(value, dbSetting) && (!isToday || !hasDbLog)) {
        listData.push({ type: 'db', status: 'pending', time: dayjs(dbSetting.schedule_time, 'HH:mm:ss').format('HH:mm'), content: 'DB Backup' });
      }
      if (checkScheduleMatch(value, sourceSetting) && (!isToday || !hasSrcLog)) {
        listData.push({ type: 'src', status: 'pending', time: dayjs(sourceSetting.schedule_time, 'HH:mm:ss').format('HH:mm'), content: 'Code Backup' });
      }
      if (checkScheduleMatch(value, githubSetting) && (!isToday || !hasGitLog)) {
        listData.push({ type: 'git', status: 'pending', time: dayjs(githubSetting.schedule_time, 'HH:mm:ss').format('HH:mm'), content: 'Git Push' });
      }
    }
    return listData.sort((a, b) => a.time.localeCompare(b.time));
  };

  const dateCellRender = (value) => {
    const listData = getListData(value);
    const isDark = document.body.classList.contains('dark-mode');
    return (
      <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
        {listData.map((item, index) => {
          let bgColor = isDark ? '#2d3238' : '#f8fafc', textColor = isDark ? '#ffffff' : '#475569', borderColor = isDark ? '#4b5563' : '#e2e8f0', icon = null;

          if (item.status === 'success') { bgColor = isDark ? 'rgba(64, 192, 87, 0.15)' : '#dcfce7'; textColor = isDark ? '#4ade80' : '#166534'; borderColor = isDark ? '#40c057' : '#bbf7d0'; } 
          else if (item.status === 'error') { bgColor = isDark ? 'rgba(250, 82, 82, 0.15)' : '#fee2e2'; textColor = isDark ? '#fca5a5' : '#991b1b'; borderColor = isDark ? '#fa5252' : '#fecaca'; } 
          else if (item.status === 'pending') { bgColor = isDark ? 'rgba(250, 176, 5, 0.15)' : '#fef9c3'; textColor = isDark ? '#fde047' : '#854d0e'; borderColor = isDark ? '#fab005' : '#fef08a'; }

          if (item.type === 'db') icon = <DatabaseOutlined style={{ marginRight: 4 }}/>;
          if (item.type === 'src') icon = <FileZipOutlined style={{ marginRight: 4 }}/>;
          if (item.type === 'git') icon = <GithubOutlined style={{ marginRight: 4 }}/>;

          return (
            <li key={index} style={{ marginBottom: 6 }}>
              <Tooltip title={`เวลา ${item.time} - สถานะ: ${item.status === 'pending' ? 'รอดำเนินการ' : item.status === 'success' ? 'สำเร็จ' : 'ล้มเหลว'}`}>
                <div style={{
                  fontSize: '11px', padding: '4px 6px', borderRadius: '6px',
                  backgroundColor: bgColor, color: textColor, border: `1px solid ${borderColor}`,
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer',
                  boxShadow: '0 1px 2px rgba(0,0,0,0.02)'
                }}>
                  <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {icon} {item.content}
                  </span>
                  <span style={{ fontWeight: 'bold', fontSize: '10px', opacity: 0.8 }}>{item.time}</span>
                </div>
              </Tooltip>
            </li>
          );
        })}
      </ul>
    );
  };

  const cellRender = (current, info) => {
    if (info.type === 'date') return dateCellRender(current);
    return info.originNode;
  };

  const customCalendarHeader = ({ value, type, onChange, onTypeChange }) => {
    const currentMonth = value.month();
    const currentYear = value.year();
    const isDark = document.body.classList.contains('dark-mode');
    const thaiMonths = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];

    const yearOptions = [];
    for (let i = currentYear - 5; i <= currentYear + 5; i++) {
      yearOptions.push(<Option key={i} value={i}>{i}</Option>);
    }

    return (
      <div className="modern-calendar-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <CalendarOutlined style={{ fontSize: '22px', color: '#6366f1' }} />
          <Text strong className="calendar-title" style={{ color: 'var(--text-main)' }}>ปฏิทินสำรองข้อมูล</Text>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', backgroundColor: isDark ? 'var(--bg-app)' : '#f8fafc', padding: '6px 16px', borderRadius: '30px', border: '1px solid var(--border-color)', boxShadow: '0 2px 4px rgba(0,0,0,0.02)' }}>
          <Button 
            shape="round" 
            size="small" 
            style={{ border: '1px solid var(--border-color)', boxShadow: 'none', fontWeight: '500', padding: '0 12px' }} 
            onClick={() => {
              const today = dayjs();
              onChange(today);
              setCalendarValue(today);
            }}
          >
            วันนี้
          </Button>
          
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <Button type="text" size="small" icon={<LeftOutlined style={{color: 'var(--text-sub)'}}/>} onClick={() => { const newValue = value.clone().subtract(1, 'month'); onChange(newValue); setCalendarValue(newValue); }} />
            
            <Space size={0} style={{ margin: '0 4px' }}>
              <Select 
                value={currentMonth} 
                onChange={(newMonth) => { const newValue = value.clone().month(newMonth); onChange(newValue); setCalendarValue(newValue); }}
                variant="borderless"
                popupMatchSelectWidth={false}
                style={{ fontWeight: 'bold', color: 'var(--text-main)', minWidth: '95px' }}
              >
                {thaiMonths.map((m, i) => <Option key={i} value={i}>{m}</Option>)}
              </Select>
              <Select 
                value={currentYear} 
                onChange={(newYear) => { const newValue = value.clone().year(newYear); onChange(newValue); setCalendarValue(newValue); }}
                variant="borderless"
                popupMatchSelectWidth={false}
                style={{ fontWeight: 'bold', color: 'var(--text-main)' }}
              >
                {yearOptions}
              </Select>
            </Space>

            <Button type="text" size="small" icon={<RightOutlined style={{color: 'var(--text-sub)'}}/>} onClick={() => { const newValue = value.clone().add(1, 'month'); onChange(newValue); setCalendarValue(newValue); }} />
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '13px', color: 'var(--text-sub)', marginRight: '4px' }}>สัญลักษณ์:</span>
          <div style={{ fontSize: '12px', padding: '3px 10px', borderRadius: '6px', backgroundColor: isDark ? 'rgba(64, 192, 87, 0.15)' : '#dcfce7', color: isDark ? '#4ade80' : '#166534', border: '1px solid var(--border-color)', fontWeight: '500' }}>สำเร็จ</div>
          <div style={{ fontSize: '12px', padding: '3px 10px', borderRadius: '6px', backgroundColor: isDark ? 'rgba(250, 82, 82, 0.15)' : '#fee2e2', color: isDark ? '#fca5a5' : '#991b1b', border: '1px solid var(--border-color)', fontWeight: '500' }}>ล้มเหลว</div>
          <div style={{ fontSize: '12px', padding: '3px 10px', borderRadius: '6px', backgroundColor: isDark ? 'rgba(250, 176, 5, 0.15)' : '#fef9c3', color: isDark ? '#fde047' : '#854d0e', border: '1px solid var(--border-color)', fontWeight: '500' }}>รอดำเนินการ</div>
        </div>
      </div>
    );
  };

  const handleSaveSourceSettings = async (values) => {
    try {
      let days = '';
      if (values.schedule_type === 'weekly') days = values.schedule_days ? values.schedule_days.join(',') : '';
      else if (values.schedule_type === 'monthly') days = values.schedule_days || '1';

      const payload = {
        target_folders: values.target_folders ? values.target_folders.join(',') : '',
        schedule_type: values.schedule_type,
        schedule_days: days,
        schedule_time: values.schedule_time.format('HH:mm:ss'),
        is_active: values.is_active ? 1 : 0
      };
      await axiosInstance.put('/backup/source/settings', payload);
      alertSuccess('บันทึกสำเร็จ', 'อัปเดตเวลาสำรอง Source Code เรียบร้อยแล้ว');
      fetchData(); 
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่าได้');
    }
  };

  const handleManualSourceBackup = async () => {
    const folders = sourceForm.getFieldValue('target_folders');
    if (!folders || folders.length === 0) return alertError('ผิดพลาด', 'กรุณาเลือกโฟลเดอร์ที่ต้องการบีบอัดอย่างน้อย 1 รายการ');
    
    setIsZipping(true);
    setZipProgress(0);
    const progressInterval = setInterval(() => {
      setZipProgress(prev => prev >= 90 ? prev : prev + Math.floor(Math.random() * 10) + 1);
    }, 500);

    try {
      await axiosInstance.post('/backup/source/manual', { target_folders: folders });
      clearInterval(progressInterval);
      setZipProgress(100);
      setTimeout(() => {
        setIsZipping(false);
        msg.success({ content: 'บีบอัดไฟล์เสร็จสมบูรณ์!', key: 'zipping', duration: 3 });
        fetchData();
      }, 500);
    } catch (error) {
      clearInterval(progressInterval);
      setIsZipping(false);
      setZipProgress(0);
      msg.error({ content: 'เกิดข้อผิดพลาดในการบีบอัดไฟล์!', key: 'zipping', duration: 3 });
    }
  };

  const handleDeleteSource = async (fileName) => {
    try {
      setSourceLoading(true);
      await axiosInstance.delete(`/backup/source/${fileName}`);
      alertSuccess('ลบสำเร็จ', 'ลบไฟล์ Zip ออกจากระบบแล้ว');
      fetchData();
    } catch (error) { alertError('ผิดพลาด', 'ไม่สามารถลบไฟล์ได้'); } finally { setSourceLoading(false); }
  };

  const handleSaveSettings = async (values) => {
    try {
      let days = '';
      if (values.schedule_type === 'weekly') days = values.schedule_days ? values.schedule_days.join(',') : '';
      else if (values.schedule_type === 'monthly') days = values.schedule_days || '1';

      const payload = {
        schedule_type: values.schedule_type,
        schedule_days: days,
        schedule_time: values.schedule_time.format('HH:mm:ss'),
        is_active: values.is_active ? 1 : 0
      };
      await axiosInstance.put('/backup/settings', payload);
      alertSuccess('บันทึกสำเร็จ', 'อัปเดตเวลาสำรองข้อมูล Database แล้ว');
      fetchData();
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่าได้');
    }
  };

  const handleManualBackup = async () => {
    setIsDbBackingUp(true);
    setDbProgress(0);
    const progressInterval = setInterval(() => {
      setDbProgress(prev => prev >= 90 ? prev : prev + Math.floor(Math.random() * 10) + 1);
    }, 400);

    try {
      await axiosInstance.post('/backup/manual');
      clearInterval(progressInterval);
      setDbProgress(100);
      setTimeout(() => {
        setIsDbBackingUp(false);
        alertSuccess('แบ็คอัพสำเร็จ', 'สำรองข้อมูลฐานข้อมูลเรียบร้อยแล้ว');
        fetchData();
      }, 500);
    } catch (error) {
      clearInterval(progressInterval);
      setIsDbBackingUp(false);
      setDbProgress(0);
      alertError('ผิดพลาด', 'การสำรองข้อมูลล้มเหลว');
    }
  };

  const handleRestore = async (fileName) => {
    const result = await alertConfirm('อันตราย! ยืนยันการกู้คืน?', `ข้อมูลปัจจุบันทั้งหมดจะถูกเขียนทับด้วยไฟล์ ${fileName} คุณแน่ใจหรือไม่?`);
    if (result.isConfirmed) {
      try {
        setLoading(true);
        await axiosInstance.post('/backup/restore', { file_name: fileName });
        alertSuccess('กู้คืนสำเร็จ', 'กู้คืนฐานข้อมูลเรียบร้อยแล้ว ระบบพร้อมใช้งาน');
        fetchData();
      } catch (error) { alertError('ผิดพลาด', 'การกู้คืนข้อมูลล้มเหลว'); } finally { setLoading(false); }
    }
  };

  const handleDelete = async (fileName) => {
    try {
      setLoading(true);
      await axiosInstance.delete(`/backup/${fileName}`);
      alertSuccess('ลบสำเร็จ', 'ลบไฟล์สำรองข้อมูลออกจากระบบแล้ว');
      fetchData();
    } catch (error) { alertError('ผิดพลาด', 'ไม่สามารถลบไฟล์ได้'); } finally { setLoading(false); }
  };

  const handleSaveGithubSettings = async (values) => {
    try {
      let days = '';
      if (values.schedule_type === 'weekly') days = values.schedule_days ? values.schedule_days.join(',') : '';
      else if (values.schedule_type === 'monthly') days = values.schedule_days || '1';

      const payload = {
        github_token: values.github_token,
        repo_url: values.repo_url,
        branch_name: values.branch_name,
        sync_targets: values.sync_targets ? values.sync_targets.join(',') : '',
        schedule_type: values.schedule_type,
        schedule_days: days,
        schedule_time: values.schedule_time.format('HH:mm:ss'),
        is_active: values.is_active ? 1 : 0
      };
      
      await axiosInstance.put('/backup/github/settings', payload);
      alertSuccess('บันทึกสำเร็จ', 'อัปเดตการตั้งค่า GitHub เรียบร้อยแล้ว');
      fetchData();
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่า GitHub ได้');
    }
  };

  const handleManualGithubPush = async () => {
    const targets = githubForm.getFieldValue('sync_targets');
    if (!targets || targets.length === 0) return alertError('ผิดพลาด', 'กรุณาเลือกข้อมูลที่ต้องการ Push อย่างน้อย 1 รายการ');

    setIsGithubPushing(true);
    setGithubProgress(0);
    const progressInterval = setInterval(() => {
      setGithubProgress(prev => prev >= 90 ? prev : prev + Math.floor(Math.random() * 5) + 1);
    }, 400);

    try {
      const res = await axiosInstance.post('/backup/github/manual', { sync_targets: targets });
      clearInterval(progressInterval);
      setGithubProgress(100);
      setTimeout(() => {
        setIsGithubPushing(false);
        msg.success({ content: `สำเร็จ! ${res.data.message}`, key: 'githubPush', duration: 4 });
        fetchData();
      }, 500);

    } catch (error) {
      clearInterval(progressInterval);
      setIsGithubPushing(false);
      setGithubProgress(0);
      const errMsg = error.response?.data?.error || 'เกิดข้อผิดพลาดในการ Push ตรวจสอบ Token และ URL';
      msg.error({ content: errMsg, key: 'githubPush', duration: 5 });
      fetchData(); 
    }
  };

  const handleDeleteGithubLog = async (logId) => {
    try {
      setGithubLoading(true);
      await axiosInstance.delete(`/backup/github/logs/${logId}`);
      alertSuccess('ลบสำเร็จ', 'ลบประวัติการ Push เรียบร้อยแล้ว');
      fetchData();
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถลบประวัติได้');
    } finally {
      setGithubLoading(false);
    }
  };

  const sourceColumns = [
    { title: 'ชื่อไฟล์', dataIndex: 'file_name', key: 'file_name', align: 'center', render: (text, record) => <Text strong style={{ color: '#8b5cf6' }}><FileZipOutlined /> {text}</Text> },
    { title: 'เป้าหมาย', dataIndex: 'target_folders', key: 'target_folders', align: 'center', render: folders => (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
           {folders?.includes('frontend') && <Text type="secondary" style={{fontSize: '12px'}}>- Frontend</Text>}
           {folders?.includes('backend') && <Text type="secondary" style={{fontSize: '12px'}}>- Backend</Text>}
           {folders?.includes('node_modules') && <Text type="danger" style={{fontSize: '12px'}}>- node_modules</Text>}
        </div>
      )
    },
    { title: 'ขนาดไฟล์', dataIndex: 'file_size', key: 'file_size', align: 'center' },
    { title: 'วันที่ทำรายการ', dataIndex: 'created_at', key: 'created_at', align: 'center', render: date => dayjs(date).format('DD/MM/YYYY HH:mm:ss') },
    { title: 'สถานะ', dataIndex: 'status', key: 'status', align: 'center', render: status => status.includes('Success') ? <Tag color="success" icon={<CheckCircleOutlined />}>สำเร็จ</Tag> : <Tag color="error" icon={<CloseCircleOutlined />}>ล้มเหลว</Tag> },
    { title: 'จัดการ', key: 'action', align: 'center', render: (_, record) => (
        <Space>
          <Button size="small" type="dashed" icon={<DownloadOutlined />} href={`${BACKEND_URL}/backups/source/${record.file_name}`} target="_blank">โหลด</Button>
          <Popconfirm title="ยืนยันการลบ?" onConfirm={() => handleDeleteSource(record.file_name)}><Button size="small" type="primary" danger icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    }
  ];

  const columns = [
    { title: 'ชื่อไฟล์', dataIndex: 'file_name', key: 'file_name', align: 'center', render: (text, record) => <Text strong style={{ color: '#0ea5e9' }}><DatabaseOutlined /> {text}</Text> },
    { title: 'ขนาดไฟล์', dataIndex: 'file_size', key: 'file_size', align: 'center' },
    { title: 'วันที่ทำรายการ', dataIndex: 'created_at', key: 'created_at', align: 'center', render: date => dayjs(date).format('DD/MM/YYYY HH:mm:ss') },
    { title: 'สถานะ', dataIndex: 'status', key: 'status', align: 'center', render: status => status.includes('Success') ? <Tag color="success" icon={<CheckCircleOutlined />}>สำเร็จ</Tag> : <Tag color="error" icon={<CloseCircleOutlined />}>ล้มเหลว</Tag> },
    { title: 'จัดการ', key: 'action', align: 'center', render: (_, record) => (
        <Space>
          <Button size="small" type="dashed" icon={<DownloadOutlined />} href={`${BACKEND_URL}/backups/database/${record.file_name}`} target="_blank">โหลด</Button>
          <Button size="small" type="primary" style={{ backgroundColor: '#f59e0b', borderColor: '#f59e0b' }} icon={<RollbackOutlined />} onClick={() => handleRestore(record.file_name)} disabled={!record.status.includes('Success')}>กู้คืน</Button>
          <Popconfirm title="ยืนยันการลบ?" onConfirm={() => handleDelete(record.file_name)}><Button size="small" type="primary" danger icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    }
  ];
  
  const githubColumns = [
    { title: 'เป้าหมายที่ Sync', dataIndex: 'sync_targets', key: 'sync_targets', align: 'center', render: folders => (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
           {folders?.includes('database') && <Text type="secondary" style={{fontSize: '12px'}}><DatabaseOutlined/> ล่าสุด (.sql)</Text>}
           {folders?.includes('source') && <Text type="secondary" style={{fontSize: '12px'}}><FileZipOutlined/> ล่าสุด (.zip)</Text>}
        </div>
      )
    },
    { title: 'สถานะ', dataIndex: 'status', key: 'status', align: 'center', render: status => (status.includes('สำเร็จ') || status.includes('Success')) ? <Tag color="success" icon={<CheckCircleOutlined />}>สำเร็จ</Tag> : <Tag color="error" icon={<CloseCircleOutlined />}>ล้มเหลว</Tag> },
    { title: 'ผู้ทำรายการ', dataIndex: 'created_by', key: 'created_by', align: 'center', render: text => <Tag color="default"><GithubOutlined /> {text}</Tag> },
    { title: 'วันที่ทำรายการ', dataIndex: 'created_at', key: 'created_at', align: 'center', render: date => dayjs(date).format('DD/MM/YYYY HH:mm:ss') },
    { title: 'จัดการ', key: 'action', align: 'center', render: (_, record) => (
        <Space>
          <Popconfirm title="ยืนยันการลบประวัตินี้?" onConfirm={() => handleDeleteGithubLog(record.log_id)}><Button size="small" type="primary" danger icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    }
  ];

  const weekOptions = [
    { label: 'จ.', value: '1' }, { label: 'อ.', value: '2' }, { label: 'พ.', value: '3' },
    { label: 'พฤ.', value: '4' }, { label: 'ศ.', value: '5' }, { label: 'ส.', value: '6' }, { label: 'อา.', value: '0' }
  ];
  const monthOptions = Array.from({ length: 31 }, (_, i) => ({ label: `วันที่ ${i + 1}`, value: `${i + 1}` }));

  return (
    <div style={{ padding: '20px', backgroundColor: 'var(--bg-app)', minHeight: '100vh' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <Title level={2} style={{ color: 'var(--text-main)', margin: 0 }}>
            <CloudServerOutlined style={{ color: '#0ea5e9', marginRight: '8px' }}/> ระบบจัดการสำรองข้อมูลและกู้คืน (Database & Source Code)
          </Title>
        </div>
        <Button icon={<SyncOutlined />} onClick={fetchData} loading={loading}>รีเฟรชข้อมูล</Button>
      </div>

      <style>{`
        .backup-tabs .ant-tabs-nav { background: var(--bg-card); border-radius: 12px; padding: 4px 8px; margin-bottom: 24px; border: 1px solid var(--border-color); }
        .backup-tabs .ant-tabs-tab { padding: 12px 24px; font-size: 16px; border-radius: 8px 8px 0 0 !important; }
        .backup-tabs .ant-tabs-tab-active { background-color: #0ea5e9 !important; border-bottom: none !important; }
        .backup-tabs .ant-tabs-tab-active .ant-tabs-tab-btn { color: #ffffff !important; }
        
        .modern-calendar-header { display: flex; justify-content: space-between; align-items: center; padding: 16px 24px; background-color: var(--bg-card); border-bottom: 1px solid var(--border-color); flex-wrap: wrap; gap: 16px; border-radius: 12px 12px 0 0; }
        .calendar-title { font-size: 18px; margin: 0; }
        @media (max-width: 768px) { .modern-calendar-header { flex-direction: column; align-items: flex-start; } .calendar-title { font-size: 15px; } }
        
        .modern-calendar table thead tr th { font-size: 0 !important; text-align: center !important; padding-bottom: 12px; font-weight: 600; }
        .modern-calendar table thead tr th:nth-child(1)::after { content: 'อาทิตย์'; font-size: 14px; color: #ef4444; } 
        .modern-calendar table thead tr th:nth-child(2)::after { content: 'จันทร์'; font-size: 14px; color: #eab308; } 
        .modern-calendar table thead tr th:nth-child(3)::after { content: 'อังคาร'; font-size: 14px; color: #ec4899; } 
        .modern-calendar table thead tr th:nth-child(4)::after { content: 'พุธ'; font-size: 14px; color: #10b981; } 
        .modern-calendar table thead tr th:nth-child(5)::after { content: 'พฤหัส'; font-size: 14px; color: #f97316; } 
        .modern-calendar table thead tr th:nth-child(6)::after { content: 'ศุกร์'; font-size: 14px; color: #3b82f6; } 
        .modern-calendar table thead tr th:nth-child(7)::after { content: 'เสาร์'; font-size: 14px; color: #a855f7; } 

        .modern-calendar-card .ant-card-body { padding: 0 !important; overflow: hidden; }
        .modern-calendar { background-color: var(--bg-app); background-image: radial-gradient(var(--border-color) 1px, transparent 0); background-size: 20px 20px; }
        .modern-calendar .ant-picker-calendar-header { padding: 0 !important; border-bottom: none !important; }
        
        .modern-calendar .ant-picker-cell-inner, .modern-calendar .ant-picker-calendar-date { 
          height: auto !important; min-height: 120px !important; max-height: none !important;
          background: var(--bg-card) !important; opacity: 0.9; margin: 4px !important; border-radius: 8px !important; 
          border: 1px solid var(--border-color) !important; transition: all 0.3s ease; overflow: visible !important;
        }
        .modern-calendar .ant-picker-cell:not(.ant-picker-cell-in-view) .ant-picker-cell-inner { background: var(--bg-app) !important; opacity: 0.5; }
        .modern-calendar .ant-picker-calendar-date-content { height: auto !important; overflow: visible !important; }
        .modern-calendar .ant-picker-cell-inner:hover { background: var(--bg-card) !important; box-shadow: 0 4px 10px rgba(0,0,0,0.2); border-color: #ffffff !important; }
        .modern-calendar .ant-picker-cell-in-view.ant-picker-cell-today .ant-picker-cell-inner::before { border: 2px solid #6366f1 !important; border-radius: 8px; }
        .modern-calendar .ant-picker-cell-selected .ant-picker-cell-inner { background-color: rgba(99, 102, 241, 0.2) !important; border: 1px solid #6366f1 !important; }
        body.dark-mode .ant-picker-calendar { background: transparent; }
      `}</style>

      <Tabs 
        type="card" 
        className="backup-tabs"
        activeKey={activeTab}
        onChange={setActiveTab}
        items={[
          {
            key: '0',
            label: <span><CalendarOutlined /> ภาพรวม (Calendar)</span>,
            children: (
              <Card className="modern-calendar-card" variant="borderless" style={{ borderRadius: 12, border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', boxShadow: 'var(--card-shadow)', marginTop: 10 }}>
                <ConfigProvider locale={thTH}>
                  <Calendar className="modern-calendar" value={calendarValue} onChange={setCalendarValue} headerRender={customCalendarHeader} cellRender={cellRender} mode="month" />
                </ConfigProvider>
              </Card>
            )
          },
          {
            key: '1',
            label: <span><CodeOutlined /> สำรองข้อมูล (Source Code)</span>,
            forceRender: true,
            children: (
              <Row gutter={[24, 24]} style={{ marginTop: '10px' }}>
                <Col xs={24} lg={8}>
                  <Card title={<><SettingOutlined /> ตั้งค่าและสำรอง Source Code</>} variant="borderless" style={{ borderRadius: 12, border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', boxShadow: 'var(--card-shadow)' }} styles={{ header: { backgroundColor: 'var(--bg-app)', borderBottom: '1px solid var(--border-color)' } }}>
                    <Form form={sourceForm} layout="vertical" onFinish={handleSaveSourceSettings}>
                      <Form.Item name="target_folders" label={<Text strong style={{ color: 'var(--text-main)' }}>เลือกส่วนที่ต้องการบีบอัด (.zip)</Text>}>
                        <Checkbox.Group style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          <Checkbox value="frontend"><Text strong style={{ color: 'var(--text-main)' }}>1. Frontend (React)</Text></Checkbox>
                          <Checkbox value="backend"><Text strong style={{ color: 'var(--text-main)' }}>2. Backend (Node.js/Express)</Text></Checkbox>
                          <Checkbox value="node_modules"><Text type="danger">3. รวมโฟลเดอร์ node_modules (ระวังไฟล์ใหญ่มาก)</Text></Checkbox>
                        </Checkbox.Group>
                      </Form.Item>
                      <Divider style={{ borderColor: 'var(--border-color)' }}/>
                      <Form.Item name="is_active" valuePropName="checked" style={{ backgroundColor: 'var(--bg-app)', padding: '10px 15px', borderRadius: 8, border: '1px solid var(--border-color)' }}>
                        <Checkbox><Text strong style={{ color: '#8b5cf6' }}>เปิดใช้งาน Auto Backup (Source Code)</Text></Checkbox>
                      </Form.Item>
                      <Form.Item name="schedule_type" label={<Text strong style={{ color: 'var(--text-main)' }}>รูปแบบรอบการทำงาน</Text>}>
                        <Radio.Group buttonStyle="solid" style={{ width: '100%' }}>
                          <Radio.Button value="daily" style={{ width: '33.33%', textAlign: 'center' }}>รายวัน</Radio.Button>
                          <Radio.Button value="weekly" style={{ width: '33.34%', textAlign: 'center' }}>รายสัปดาห์</Radio.Button>
                          <Radio.Button value="monthly" style={{ width: '33.33%', textAlign: 'center' }}>รายเดือน</Radio.Button>
                        </Radio.Group>
                      </Form.Item>
                      <Form.Item noStyle shouldUpdate={(prev, current) => prev.schedule_type !== current.schedule_type}>
                        {({ getFieldValue }) => {
                          const type = getFieldValue('schedule_type');
                          if (type === 'weekly') return <Form.Item name="schedule_days" label={<Text strong style={{ color: 'var(--text-main)' }}>เลือกวันในสัปดาห์</Text>}><Checkbox.Group options={weekOptions} style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }} /></Form.Item>;
                          if (type === 'monthly') return <Form.Item name="schedule_days" label={<Text strong style={{ color: 'var(--text-main)' }}>เลือกวันที่ของทุกเดือน</Text>}><Select placeholder="เลือกวันที่" size="large" options={monthOptions} /></Form.Item>;
                          return null;
                        }}
                      </Form.Item>
                      <Form.Item name="schedule_time" label={<Text strong style={{ color: 'var(--text-main)' }}>เวลาที่ระบบประมวลผล (แนะนำ 04:00 น.)</Text>}><TimePicker format="HH:mm" style={{ width: '100%' }} size="large" />
                      </Form.Item>
                      <Divider style={{ borderColor: 'var(--border-color)' }}/><Button type="primary" htmlType="submit" icon={<SaveOutlined />} block size="large" style={{ backgroundColor: '#8b5cf6' }}>บันทึกการตั้งเวลา</Button>
                    </Form>
                  </Card>
                </Col>
                <Col xs={24} lg={16}>
                  <Card title={<span><CodeOutlined /> ประวัติการสำรอง Source Code (Zip)</span>} extra={<Button type="primary" icon={<FileZipOutlined />} onClick={handleManualSourceBackup} disabled={isZipping} style={{ backgroundColor: '#8b5cf6' }}>เริ่มบีบอัดทันที</Button>} variant="borderless" style={{ borderRadius: 12, border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', boxShadow: 'var(--card-shadow)' }} styles={{ header: { backgroundColor: 'var(--bg-app)', borderBottom: '1px solid var(--border-color)' } }}>
                    {isZipping && <div style={{ padding: '0 20px 20px' }}><Text strong style={{ color: '#8b5cf6' }}>กำลังบีบอัดไฟล์...</Text><Progress percent={zipProgress} status="active" strokeColor="#8b5cf6" /></div>}
                    <Table columns={sourceColumns} dataSource={sourceLogs} rowKey="log_id" pagination={{ pageSize: 8 }} loading={sourceLoading} size="middle" scroll={{ x: 'max-content' }} />
                  </Card>
                </Col>
              </Row>
            )
          },
          {
            key: '2',
            label: <span><DatabaseOutlined /> สำรองข้อมูล (Database)</span>,
            forceRender: true,
            children: (
              <Row gutter={[24, 24]} style={{ marginTop: '10px' }}>
                <Col xs={24} lg={8}>
                  <Card title={<><SettingOutlined /> ตั้งเวลาสำรองข้อมูลอัตโนมัติ</>} variant="borderless" style={{ borderRadius: 12, border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', boxShadow: 'var(--card-shadow)' }} styles={{ header: { backgroundColor: 'var(--bg-app)', borderBottom: '1px solid var(--border-color)' } }}>
                    <Form form={form} layout="vertical" onFinish={handleSaveSettings}>
                      <Form.Item name="is_active" valuePropName="checked" style={{ backgroundColor: 'var(--bg-app)', padding: '10px 15px', borderRadius: 8, border: '1px solid var(--border-color)' }}>
                        <Checkbox><Text strong style={{ color: '#16a34a' }}>เปิดใช้งาน Auto Backup (Database)</Text></Checkbox>
                      </Form.Item>
                      <Form.Item name="schedule_type" label={<Text strong style={{ color: 'var(--text-main)' }}>รูปแบบรอบการทำงาน</Text>}>
                        <Radio.Group buttonStyle="solid" style={{ width: '100%' }}>
                          <Radio.Button value="daily" style={{ width: '33.33%', textAlign: 'center' }}>รายวัน</Radio.Button>
                          <Radio.Button value="weekly" style={{ width: '33.34%', textAlign: 'center' }}>รายสัปดาห์</Radio.Button>
                          <Radio.Button value="monthly" style={{ width: '33.33%', textAlign: 'center' }}>รายเดือน</Radio.Button>
                        </Radio.Group>
                      </Form.Item>
                      <Form.Item noStyle shouldUpdate={(prev, current) => prev.schedule_type !== current.schedule_type}>
                        {({ getFieldValue }) => {
                          const type = getFieldValue('schedule_type');
                          if (type === 'weekly') return <Form.Item name="schedule_days" label={<Text strong style={{ color: 'var(--text-main)' }}>เลือกวันในสัปดาห์</Text>}><Checkbox.Group options={weekOptions} style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }} /></Form.Item>;
                          if (type === 'monthly') return <Form.Item name="schedule_days" label={<Text strong style={{ color: 'var(--text-main)' }}>เลือกวันที่ของทุกเดือน</Text>}><Select placeholder="เลือกวันที่" size="large" options={monthOptions} /></Form.Item>;
                          return null;
                        }}
                      </Form.Item>
                      <Form.Item name="schedule_time" label={<Text strong style={{ color: 'var(--text-main)' }}>เวลาที่ระบบประมวลผล (แนะนำ 02:00 น.)</Text>}><TimePicker format="HH:mm" style={{ width: '100%' }} size="large" /></Form.Item>
                      <Divider style={{ borderColor: 'var(--border-color)' }}/><Button type="primary" htmlType="submit" icon={<SaveOutlined />} block size="large" style={{ backgroundColor: '#0ea5e9' }}>บันทึกการตั้งเวลา</Button>
                    </Form>
                  </Card>
                </Col>
                <Col xs={24} lg={16}>
                  <Card title={<span><DatabaseOutlined /> ประวัติการสำรองฐานข้อมูล</span>} extra={<Button type="primary" icon={<DatabaseOutlined />} onClick={handleManualBackup} disabled={isDbBackingUp} style={{ backgroundColor: '#10b981' }}>สำรอง DB ทันที</Button>} variant="borderless" style={{ borderRadius: 12, border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', boxShadow: 'var(--card-shadow)' }} styles={{ header: { backgroundColor: 'var(--bg-app)', borderBottom: '1px solid var(--border-color)' } }}>
                    {isDbBackingUp && <div style={{ padding: '0 20px 20px' }}><Text strong style={{ color: '#10b981' }}>กำลังส่งออกไฟล์...</Text><Progress percent={dbProgress} status="active" strokeColor="#10b981" /></div>}
                    <Table columns={columns} dataSource={logs} rowKey="log_id" pagination={{ pageSize: 8 }} loading={loading && !isDbBackingUp} size="middle" scroll={{ x: 'max-content' }} />
                  </Card>
                </Col>
              </Row>
            )
          },
          {
            key: '3',
            label: <span><GithubOutlined /> อัปโหลดขึ้น Cloud (GitHub)</span>,
            forceRender: true,
            children: (
              <Row gutter={[24, 24]} style={{ marginTop: '10px' }}>
                <Col xs={24} lg={10}>
                  <Card title={<><SettingOutlined /> ตั้งค่า GitHub (Auto Push)</>} variant="borderless" style={{ borderRadius: 12, border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', boxShadow: 'var(--card-shadow)' }} styles={{ header: { backgroundColor: '#1f2937', color: '#fff', borderBottom: '1px solid var(--border-color)' } }}>
                    <Form form={githubForm} layout="vertical" onFinish={handleSaveGithubSettings}>
                      <Form.Item name="is_active" valuePropName="checked" style={{ backgroundColor: 'var(--bg-app)', padding: '10px 15px', borderRadius: 8, border: '1px solid var(--border-color)' }}><Checkbox><Text strong style={{ color: 'var(--text-main)' }}>เปิดใช้งาน Auto Push</Text></Checkbox></Form.Item>
                      <Form.Item label={<Text strong style={{ color: 'var(--text-main)' }}>GitHub Token (PAT)</Text>} name="github_token" rules={[{ required: true }]}><Input.Password placeholder="ghp_xxxx" size="large" /></Form.Item>
                      <Form.Item label={<Text strong style={{ color: 'var(--text-main)' }}>Repository URL</Text>} name="repo_url" rules={[{ required: true }]}><Input placeholder="https://github.com/..." size="large" /></Form.Item>
                      <Form.Item label={<Text strong style={{ color: 'var(--text-main)' }}>Branch เป้าหมาย</Text>} name="branch_name"><Input placeholder="main" size="large" /></Form.Item>
                      <Form.Item name="sync_targets" label={<Text strong style={{ color: 'var(--text-main)' }}>ข้อมูลที่ต้องการ Push</Text>}><Checkbox.Group style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}><Checkbox value="database"><Text strong style={{ color: 'var(--text-main)' }}>ไฟล์ .sql</Text></Checkbox><Checkbox value="source"><Text strong style={{ color: 'var(--text-main)' }}>ไฟล์ Source Code</Text></Checkbox></Checkbox.Group></Form.Item>
                      <Divider style={{ borderColor: 'var(--border-color)' }}/><Button type="primary" htmlType="submit" icon={<SaveOutlined />} block size="large" style={{ backgroundColor: '#111827' }}>บันทึก GitHub</Button>
                    </Form>
                  </Card>
                </Col>
                <Col xs={24} lg={14}>
                  <Card title={<span><GithubOutlined /> ประวัติการ Push</span>} extra={<Button type="primary" icon={<GithubOutlined />} onClick={handleManualGithubPush} disabled={isGithubPushing} style={{ backgroundColor: '#111827' }}>Push ทันที</Button>} variant="borderless" style={{ borderRadius: 12, border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', boxShadow: 'var(--card-shadow)', height: '100%' }} styles={{ header: { backgroundColor: 'var(--bg-app)', borderBottom: '1px solid var(--border-color)' } }}>
                    {isGithubPushing && <div style={{ padding: '0 20px 20px' }}><Text strong style={{ color: '#111827' }}>กำลังส่งข้อมูล...</Text><Progress percent={githubProgress} status="active" strokeColor="#111827" /></div>}
                    <Table columns={githubColumns} dataSource={githubLogs} rowKey="log_id" pagination={{ pageSize: 8 }} loading={githubLoading} size="middle" scroll={{ x: 'max-content' }} />
                  </Card>
                </Col>
              </Row>
            )
          }
        ]}
      />
    </div>
  );
}
