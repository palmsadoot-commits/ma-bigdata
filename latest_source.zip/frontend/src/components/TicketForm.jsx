import React, { useState, useEffect } from 'react';
import { Form, Input, Select, Button, Typography, Result, Upload, message, Card, Row, Col, Alert, Space, Tag, Divider, AutoComplete, Radio } from 'antd';
import { UploadOutlined, ClockCircleOutlined, ToolOutlined, InfoCircleOutlined, DesktopOutlined, AppstoreOutlined, ThunderboltOutlined, GlobalOutlined } from '@ant-design/icons';
import axios from 'axios';

// ✅ 1. นำเข้า React Quill เวอร์ชันใหม่ (react-quill-new)
import ReactQuill from 'react-quill-new';
import 'react-quill-new/dist/quill.snow.css'; 

// ✅ 2. นำเข้า DOMPurify สำหรับทำความสะอาด HTML
import DOMPurify from 'dompurify';

import { alertSuccess, alertError } from '../utils/alert';

const { Title, Text } = Typography;
const { Option } = Select;

export default function TicketForm({ project }) {
  const [categories, setCategories] = useState([]);
  const [form] = Form.useForm();
  const [isSuccess, setIsSuccess] = useState(false);
  const [ticketNumber, setTicketNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [fileList, setFileList] = useState([]);

  const [ticketType, setTicketType] = useState('general'); // 'general' | 'cm'
  const [subType, setSubType] = useState(null); // เก็บค่า Radio ที่เลือก
  const [selectedCatType, setSelectedCatType] = useState(null); // ใช้แสดง SLA
  
  const equipmentOptions = [
    { value: 'SGH031WCZZ' }, { value: 'SGH031WD01' }, { value: 'ACM028T387' },
    { value: 'CZC018WZ73' }, { value: 'CZC018WZ0D' }, { value: 'SGH031WD20' },
    { value: 'SGH031W5SX' }, { value: 'SG03G4904L' }, { value: 'https://bigdata.mol.go.th' }
  ];

  const currentUser = JSON.parse(localStorage.getItem('lims_user'));

  useEffect(() => {
    axios.get('http://localhost:3000/api/categories')
      .then(res => {
        if (project && project.project_id) {
           const filtered = res.data.filter(cat => cat.project_id === project.project_id || !cat.project_id);
           setCategories(filtered.length > 0 ? filtered : res.data);
        } else {
           setCategories(res.data);
        }
      })
      .catch(err => alertError('ข้อผิดพลาด', 'ไม่สามารถโหลดข้อมูลหมวดหมู่ได้'));
  }, [project]);

  // ✅ อัปเดต SLA ทันทีที่เลือก Radio ย่อย (สำหรับ CM)
  useEffect(() => {
    if (subType === 'hardware') setSelectedCatType('Hardware');
    else if (subType === 'software') setSelectedCatType('Software');
    else if (subType === 'app_cm' || subType === 'app_update') setSelectedCatType('Application');
    else setSelectedCatType(null);
  }, [subType]);

  const handleUploadChange = ({ fileList: newFileList, file }) => {
    setFileList(newFileList.slice(-1)); 
    if (file.status !== 'removed' && file.name) {
      message.success(`แนบไฟล์ ${file.name} สำเร็จ!`);
    }
  };

  const onFinish = async (values) => {
    const cleanHTML = DOMPurify.sanitize(values.problem_detail);

    if (!cleanHTML || cleanHTML === '<p><br></p>' || cleanHTML.trim() === '') {
      message.error('กรุณาระบุรายละเอียดปัญหา!');
      return;
    }

    setLoading(true); 
    try {
      const formData = new FormData();
      formData.append('reporter_id', currentUser?.user_id); 
      
      // ✅ จัดการ Category ID ตามเงื่อนไข "อื่นๆ"
      let finalCategoryId = values.category_id;
      let finalDetail = cleanHTML;

      if (subType === 'other_general' || subType === 'other_cm') {
         // หา ID ของหมวดหมู่ 'Other' (ระบบอื่นๆ) ในฐานข้อมูล
         const otherCat = categories.find(c => c.category_type === 'Other' || c.category_name.includes('อื่น'));
         finalCategoryId = otherCat ? otherCat.category_id : categories[0]?.category_id;
         
         // ถ้าเลือก อื่นๆ (CM) ให้เอาข้อความที่พิมพ์ไปต่อหน้า Problem Detail
         if (subType === 'other_cm' && values.custom_category) {
            finalDetail = `<p><strong style="color:red;">[แจ้งซ่อมระบบ/อุปกรณ์อื่นๆ]:</strong> ${values.custom_category}</p>` + cleanHTML;
         }
      }

      formData.append('category_id', finalCategoryId);
      formData.append('equipment_no', values.equipment_no || '');
      formData.append('problem_detail', finalDetail); 

      let slaHours = 0;
      if (ticketType === 'cm') {
        // อ้างอิงตาม SLA: HW/SW = 6 ชม. | App/อื่นๆ = 12 ชม.
        slaHours = (selectedCatType === 'Hardware' || selectedCatType === 'Software') ? 6 : 12;
      }
      formData.append('is_cm', ticketType === 'cm' ? '1' : '0');
      formData.append('sla_hours', slaHours);

      if (fileList.length > 0) {
        formData.append('attachment', fileList[0].originFileObj);
      }

      const res = await axios.post('http://localhost:3000/api/tickets', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      
      setTicketNumber(res.data.ticket_number);
      await alertSuccess('ส่งใบแจ้งซ่อมสำเร็จ!', `หมายเลขใบงานของคุณคือ: ${res.data.ticket_number}`);
      setIsSuccess(true);
    } catch (err) {
      alertError('เกิดข้อผิดพลาด!', 'ระบบไม่สามารถส่งข้อมูลได้ กรุณาลองใหม่อีกครั้ง');
    } finally {
      setLoading(false); 
    }
  };

  const handleReset = () => {
    form.resetFields();
    setFileList([]);
    setIsSuccess(false);
    setTicketType('general');
    setSubType(null);
    setSelectedCatType(null);
  };

  // ✅ ฟังก์ชันกรอง Dropdown หมวดหมู่ตาม Radio ที่เลือก
  const getFilteredCategories = () => {
    if (subType === 'app_update' || subType === 'app_cm') return categories.filter(c => c.category_type === 'Application');
    if (subType === 'service') return categories.filter(c => c.category_type === 'Service');
    if (subType === 'hardware') return categories.filter(c => c.category_type === 'Hardware');
    if (subType === 'software') return categories.filter(c => c.category_type === 'Software');
    return [];
  };

  if (isSuccess) {
    return (
      <div style={{ maxWidth: 600, margin: '40px auto', textAlign: 'center' }}>
        <Card style={{ borderRadius: '16px', boxShadow: '0 10px 30px rgba(0,0,0,0.05)' }}>
          <Result
            status="success"
            title="สร้างใบงานสำเร็จ!"
            subTitle={<span>ระบบได้รับข้อมูลแล้ว หมายเลขใบแจ้งซ่อมของคุณคือ: <strong style={{color: '#1890ff', fontSize: '18px'}}>{ticketNumber}</strong></span>}
            extra={[
              <Button type="primary" size="large" key="console" onClick={handleReset} style={{ borderRadius: '8px', padding: '0 30px' }}>
                สร้างใบงานใหม่
              </Button>
            ]}
          />
        </Card>
      </div>
    );
  }

  const renderSLADisplay = () => {
    if (ticketType !== 'cm' || !selectedCatType) return null;

    if (selectedCatType === 'Hardware' || selectedCatType === 'Software') {
      return (
        <Alert
          title={<Text strong style={{ color: '#991b1b', fontSize: '15px' }}>⏱️ เงื่อนไข SLA: ฮาร์ดแวร์ / ซอฟต์แวร์</Text>}
          description={
            <ul style={{ margin: 0, paddingLeft: '20px', color: '#7f1d1d', marginTop: '8px' }}>
              <li>ช่างต้องเข้าดำเนินการแก้ไข ภายใน <b>2 ชั่วโมง</b></li>
              <li>ซ่อมแซมหรือหาอุปกรณ์ทดแทนให้แล้วเสร็จ ภายใน <b>6 ชั่วโมง</b></li>
            </ul>
          }
          type="error"
          showIcon
          icon={<ThunderboltOutlined style={{ fontSize: '24px' }}/>}
          style={{ backgroundColor: '#fef2f2', borderColor: '#fecaca', borderRadius: '12px', marginBottom: '20px' }}
        />
      );
    }

    if (selectedCatType === 'Application') {
      return (
        <Alert
          title={<Text strong style={{ color: '#854d0e', fontSize: '15px' }}>⏱️ เงื่อนไข SLA: ระบบสารสนเทศ</Text>}
          description={
            <ul style={{ margin: 0, paddingLeft: '20px', color: '#713f12', marginTop: '8px' }}>
              <li>ช่างต้องเข้าดำเนินการตรวจสอบทันทีที่ได้รับแจ้ง</li>
              <li>แก้ไขให้ระบบสามารถใช้งานได้ ภายใน <b>12 ชั่วโมง</b></li>
            </ul>
          }
          type="warning"
          showIcon
          icon={<ClockCircleOutlined className="spinning-clock" style={{ fontSize: '24px' }}/>} 
          style={{ backgroundColor: '#fefce8', borderColor: '#fef08a', borderRadius: '12px', marginBottom: '20px' }}
        />
      );
    }
    return null;
  };

  const modules = {
    toolbar: [
      [{ 'header': [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      ['link'],
      ['clean']
    ],
  };

  return (
    <div style={{ maxWidth: 1000, margin: '20px auto' }}>
      <style>{`
        .ticket-type-card {
          border: 2px solid #e2e8f0; border-radius: 16px; padding: 20px;
          cursor: pointer; transition: all 0.3s ease; text-align: center; background: #ffffff;
        }
        .ticket-type-card:hover { border-color: #93c5fd; background: #f0f9ff; transform: translateY(-2px); }
        .ticket-type-card.active-general { border-color: #3b82f6; background: #eff6ff; box-shadow: 0 4px 15px rgba(59, 130, 246, 0.15); }
        .ticket-type-card.active-cm { border-color: #ef4444; background: #fef2f2; box-shadow: 0 4px 15px rgba(239, 68, 68, 0.15); }
        
        @keyframes spin-slow { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .spinning-clock { animation: spin-slow 4s linear infinite; }
        
        .quill-custom .ql-container { border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; font-family: inherit; font-size: 15px; min-height: 150px; }
        .quill-custom .ql-toolbar { border-top-left-radius: 8px; border-top-right-radius: 8px; background-color: #f8fafc; }
      `}</style>

      <Row gutter={[24, 24]}>
        {/* คอลัมน์ซ้าย: ฟอร์มกรอกข้อมูล */}
        <Col xs={24} md={16}>
          <Card style={{ borderRadius: '16px', boxShadow: '0 4px 20px rgba(0,0,0,0.04)', border: 'none' }}>
            <Title level={4} style={{ color: '#1e293b', marginBottom: '24px' }}>
              <ToolOutlined style={{ color: '#ef8157', marginRight: '8px' }} />
              สร้างใบงาน (แจ้งปัญหาการใช้งาน)
            </Title>

            <Form form={form} layout="vertical" onFinish={onFinish}>
              
              <Form.Item label={<Text strong style={{ fontSize: '15px' }}>1. เลือกประเภทใบงาน</Text>} required>
                <Row gutter={16}>
                  <Col span={12}>
                    <div 
                      className={`ticket-type-card ${ticketType === 'general' ? 'active-general' : ''}`}
                      onClick={() => { 
                        setTicketType('general'); setSubType(null); 
                        form.setFieldsValue({ subType: undefined, category_id: undefined, custom_category: undefined }); 
                      }}
                    >
                      <InfoCircleOutlined style={{ fontSize: '28px', color: ticketType === 'general' ? '#3b82f6' : '#94a3b8', marginBottom: '8px' }} />
                      <div style={{ fontWeight: 'bold', color: '#1e293b', fontSize: '15px' }}>แจ้งปัญหาทั่วไป</div>
                      <div style={{ fontSize: '12px', color: '#64748b' }}>(ไม่นับเวลา SLA)</div>
                    </div>
                  </Col>
                  <Col span={12}>
                    <div 
                      className={`ticket-type-card ${ticketType === 'cm' ? 'active-cm' : ''}`}
                      onClick={() => { 
                        setTicketType('cm'); setSubType(null); 
                        form.setFieldsValue({ subType: undefined, category_id: undefined, custom_category: undefined }); 
                      }}
                    >
                      <ClockCircleOutlined className={ticketType === 'cm' ? 'spinning-clock' : ''} style={{ fontSize: '28px', color: ticketType === 'cm' ? '#ef4444' : '#94a3b8', marginBottom: '8px' }} />
                      <div style={{ fontWeight: 'bold', color: '#1e293b', fontSize: '15px' }}>แจ้งซ่อมเร่งด่วน (CM)</div>
                      <div style={{ fontSize: '12px', color: '#64748b' }}>(นับเวลา SLA ตามสัญญา)</div>
                    </div>
                  </Col>
                </Row>
              </Form.Item>

              <Divider dashed />

              {/* ✅ 2. Radio Group เลือกลักษณะปัญหา (ขึ้นอยู่กับประเภทใบงานด้านบน) */}
              <Form.Item name="subType" label={<Text strong>2. ลักษณะปัญหา/กลุ่มงาน <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณาเลือกลักษณะปัญหา!' }]}>
                <Radio.Group 
                  onChange={(e) => { 
                    setSubType(e.target.value); 
                    form.setFieldsValue({ category_id: undefined, custom_category: undefined }); 
                  }}
                  style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}
                >
                  {ticketType === 'general' ? (
                    <>
                      <Radio value="app_update">ปรับปรุงระบบสารสนเทศ (Application)</Radio>
                      <Radio value="service">งานบริการ (ด้านข้อมูล / Report / Database)</Radio>
                      <Radio value="other_general">อื่นๆ</Radio>
                    </>
                  ) : (
                    <>
                      <Radio value="hardware">คอมพิวเตอร์แม่ข่ายและอุปกรณ์ (Hardware)</Radio>
                      <Radio value="software">ซอฟต์แวร์สำหรับระบบคอมพิวเตอร์แม่ข่าย (Software)</Radio>
                      <Radio value="app_cm">ระบบสารสนเทศ (Application)</Radio>
                      <Radio value="other_cm">อื่นๆ</Radio>
                    </>
                  )}
                </Radio.Group>
              </Form.Item>

              {/* ✅ 3. แสดง Dropdown หรือ Input ตามกลุ่มงานที่เลือก */}
              {subType && (
                <div style={{ backgroundColor: '#f8fafc', padding: '15px', borderRadius: '12px', marginBottom: '24px', border: '1px solid #e2e8f0' }}>
                  
                  {/* ซ่อน Dropdown ถ้าเลือก "อื่นๆ" */}
                  {(subType !== 'other_general' && subType !== 'other_cm') && (
                    <Form.Item name="category_id" label={<Text strong>หมวดหมู่ระบบ / อุปกรณ์ <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณาเลือกระบบ!' }]}>
                      <Select placeholder="-- กรุณาเลือกระบบ --" size="large" showSearch optionFilterProp="children">
                        {getFilteredCategories().map(cat => (
                          <Option key={cat.category_id} value={cat.category_id}>
                            {cat.category_name}
                          </Option>
                        ))}
                      </Select>
                    </Form.Item>
                  )}

                  {/* แสดง Input โปรดระบุ หากเลือก แจ้งซ่อมเร่งด่วน -> อื่นๆ */}
                  {subType === 'other_cm' && (
                    <Form.Item name="custom_category" label={<Text strong>โปรดระบุระบบ/อุปกรณ์ <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณาระบุข้อมูล!' }]}>
                      <Input placeholder="ระบุระบบหรืออุปกรณ์ที่พบปัญหา" size="large" />
                    </Form.Item>
                  )}

                  {renderSLADisplay()}

                  <Form.Item name="equipment_no" label={<Text strong>เลขครุภัณฑ์ / เลขเครื่อง / URL (ถ้ามี)</Text>} style={{ marginBottom: 0 }}>
                    <AutoComplete
                      options={equipmentOptions}
                      placeholder="พิมพ์เพื่อค้นหา หรือกรอกข้อมูล เช่น SGH031WCZZ"
                      size="large"
                      filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1}
                    />
                  </Form.Item>
                </div>
              )}

              <Form.Item 
                name="problem_detail" 
                label={<Text strong>3. รายละเอียดปัญหา <span style={{color:'red'}}>*</span></Text>} 
                rules={[{ required: true, message: 'กรุณาระบุรายละเอียดปัญหา!' }]}
                valuePropName="value"
                getValueFromEvent={(content) => content}
              >
                <ReactQuill 
                  theme="snow" 
                  modules={modules}
                  placeholder="อธิบายอาการที่พบอย่างละเอียด หรือขั้นตอนการเกิดปัญหา..."
                  className="quill-custom"
                />
              </Form.Item>

              <Form.Item label={<Text strong>4. แนบไฟล์รูปภาพ / เอกสาร (ถ้ามี)</Text>}>
                 <Upload 
                   beforeUpload={() => false}
                   fileList={fileList}
                   onChange={handleUploadChange}
                   accept="image/*,.pdf"
                 >
                   <Button icon={<UploadOutlined />} style={{ borderRadius: '8px' }}>คลิกเพื่อเลือกไฟล์รูปภาพ</Button>
                 </Upload>
              </Form.Item>

              <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
                <Button type="primary" htmlType="submit" size="large" loading={loading} style={{ backgroundColor: '#ef8157', borderColor: '#ef8157', width: '100%', borderRadius: '8px', fontWeight: 'bold', fontSize: '16px', height: '45px' }}>
                  {loading ? 'กำลังส่งข้อมูล...' : 'ส่งใบแจ้งซ่อม'}
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </Col>

        {/* คอลัมน์ขวา: คำแนะนำ */}
        <Col xs={24} md={8}>
          <Space direction="vertical" size="middle" style={{ width: '100%' }}>
            <Card style={{ borderRadius: '16px', backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', boxShadow: '0 4px 10px rgba(0,0,0,0.02)' }}>
              <Title level={5} style={{ color: '#334155', marginTop: 0 }}><InfoCircleOutlined /> คำแนะนำการแจ้งซ่อม</Title>
              <Text style={{ color: '#475569', fontSize: '13px' }}>
                หากปัญหาส่งผลกระทบต่อระบบงานหลัก ทำให้ผู้ใช้ไม่สามารถทำงานได้ หรือระบบล่ม (System Down) 
                แนะนำให้เลือกประเภทใบงานเป็น <Tag color="error">แจ้งซ่อมเร่งด่วน (CM)</Tag> 
                เพื่อให้ทีมวิศวกรเข้าแก้ไขตามระยะเวลาที่กำหนด (SLA)
              </Text>
            </Card>

            <Card style={{ borderRadius: '16px', border: '1px solid #e2e8f0', boxShadow: '0 4px 10px rgba(0,0,0,0.02)' }}>
               <Title level={5} style={{ color: '#334155', marginTop: 0 }}>การแบ่งหมวดหมู่ (Category)</Title>
               <ul style={{ paddingLeft: '15px', color: '#475569', fontSize: '13px', margin: 0, lineHeight: '2' }}>
                 <li><b><DesktopOutlined /> ฮาร์ดแวร์ (Hardware):</b> เครื่องเซิร์ฟเวอร์, Storage, อุปกรณ์ Network</li>
                 <li><b><AppstoreOutlined /> ซอฟต์แวร์ (Software):</b> OS, Database, ระบบพื้นฐาน</li>
                 <li><b><GlobalOutlined /> แอปพลิเคชัน (Application):</b> Web Portal, ระบบลงทะเบียน, แดชบอร์ด</li>
               </ul>
            </Card>
          </Space>
        </Col>

      </Row>
    </div>
  );
}