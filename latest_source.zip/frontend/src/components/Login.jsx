import React, { useState } from 'react';
import { Form, Input, Button, Typography, Card } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import axiosInstance from '../services/api/axiosInstance';
import Swal from 'sweetalert2'; 
import { alertError } from '../utils/alert'; 

const { Title, Text } = Typography;

export default function Login({ onLoginSuccess }) {
  const [loading, setLoading] = useState(false);

  const onFinish = async (values) => {
    setLoading(true);
    try {
      // ✅ ใช้ axiosInstance แทน axios ปกติ
      const res = await axiosInstance.post('/users/login', values);
      
      if (res.data.success) {
        const fullName = `${res.data.user.first_name} ${res.data.user.last_name}`;

        Swal.fire({
          icon: 'success',
          title: 'เข้าสู่ระบบสำเร็จ',
          text: `ยินดีต้อนรับคุณ ${fullName}`,
          showConfirmButton: false, 
          timer: 1500, 
          timerProgressBar: true, 
        });

        setTimeout(() => {
          onLoginSuccess(res.data.user); 
        }, 800);
      }
    } catch (err) {
      if (err.response && err.response.status === 401) {
        alertError('เข้าสู่ระบบไม่สำเร็จ!', 'ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง');
      } else {
        alertError('ข้อผิดพลาด!', 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center', 
      backgroundColor: 'var(--bg-app)' 
    }}>
      <Card style={{ width: 400, boxShadow: 'var(--card-shadow)', borderRadius: 12, backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
        <div style={{ textAlign: 'center', marginBottom: 30 }}>
          <Title level={3} style={{ color: 'var(--text-main)', margin: 0 }}>⚙️ LMIS Big Data</Title>
          <Text type="secondary" style={{ color: 'var(--text-sub)' }}>ระบบบริหารจัดการแจ้งซ่อมโครงการ</Text>
        </div>

        <Form name="login_form" layout="vertical" onFinish={onFinish}>
          <Form.Item name="username" rules={[{ required: true, message: 'กรุณากรอกชื่อผู้ใช้งาน!' }]}>
            <Input prefix={<UserOutlined style={{ color: '#ef8157' }} />} placeholder="ชื่อผู้ใช้งาน (Username)" size="large" />
          </Form.Item>

          <Form.Item name="password" rules={[{ required: true, message: 'กรุณากรอกรหัสผ่าน!' }]}>
            <Input.Password prefix={<LockOutlined style={{ color: '#ef8157' }} />} placeholder="รหัสผ่าน (Password)" size="large" />
          </Form.Item>

          <Form.Item style={{ marginTop: 30, marginBottom: 0 }}>
            <Button type="primary" htmlType="submit" size="large" block loading={loading} style={{ borderRadius: 8 }}>
              เข้าสู่ระบบ
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
}
