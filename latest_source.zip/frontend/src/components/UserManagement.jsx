import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Space, Typography, Tag, Modal, Form, Input, Select, Popconfirm, Row, Col, Divider, Tabs, Avatar } from 'antd';
import { TeamOutlined, PlusOutlined, EditOutlined, DeleteOutlined, KeyOutlined, UserOutlined } from '@ant-design/icons';
import axios from 'axios';
import { alertSuccess, alertError } from '../utils/alert';

const { Title } = Typography;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000';

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null); 
  const [form] = Form.useForm();

  const fetchData = async () => {
    setLoading(true);
    try {
      const [userRes, projRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/users`),
        axios.get(`${BACKEND_URL}/api/projects`)
      ]);
      setUsers(userRes.data);
      setProjects(projRes.data);
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูลผู้ใช้งานได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleAddUser = () => {
    setEditingUser(null);
    form.resetFields();
    setIsModalVisible(true);
  };

  const handleEditUser = (record) => {
    setEditingUser(record);
    form.setFieldsValue({
      username: record.username,
      first_name: record.first_name,
      last_name: record.last_name,
      role: record.role,
      agency: record.agency,
      project_id: record.project_id,
      new_password: '' 
    });
    setIsModalVisible(true);
  };

  const handleDeleteUser = async (id) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/users/${id}`);
      alertSuccess('ลบสำเร็จ', 'ผู้ใช้งานถูกลบออกจากระบบแล้ว');
      fetchData();
    } catch (error) {
      alertError('ลบไม่สำเร็จ', error.response?.data?.error || 'เกิดข้อผิดพลาด');
    }
  };

  const handleSubmit = async (values) => {
    try {
      if (editingUser) {
        await axios.put(`${BACKEND_URL}/api/users/${editingUser.user_id}`, values);
        alertSuccess('อัปเดตสำเร็จ', 'แก้ไขข้อมูลผู้ใช้งานเรียบร้อยแล้ว');
      } else {
        await axios.post(`${BACKEND_URL}/api/register`, { ...values, password: values.new_password });
        alertSuccess('เพิ่มผู้ใช้สำเร็จ', 'สร้างบัญชีผู้ใช้งานใหม่เรียบร้อยแล้ว');
      }
      setIsModalVisible(false);
      fetchData(); 
    } catch (error) {
      alertError('บันทึกไม่สำเร็จ', error.response?.data?.error || 'เกิดข้อผิดพลาด');
    }
  };

  // ✅ ตั้งค่าคอลัมน์ให้มีรูปภาพด้วย
  const columns = [
    { 
      title: 'รูปภาพ', 
      key: 'avatar', 
      width: 80,
      align: 'center',
      render: (_, record) => (
        <Avatar 
          src={record.user_photo && record.user_photo !== 'noimg.jpg' ? `${BACKEND_URL}/uploads/avatars/${record.user_photo}` : null}
          icon={(!record.user_photo || record.user_photo === 'noimg.jpg') && <UserOutlined />}
          size="large"
          style={{ backgroundColor: '#1890ff' }}
        />
      )
    },
    { title: 'ชื่อเข้าใช้ (Username)', dataIndex: 'username', key: 'username' },
    { title: 'ชื่อ - นามสกุล', key: 'fullname', render: (_, record) => `${record.first_name} ${record.last_name}` },
    { title: 'หน่วยงาน', dataIndex: 'agency', key: 'agency', render: (text) => text || '-' },
    { title: 'โปรเจกต์', dataIndex: 'project_name', key: 'project_name', render: (text) => text || '-' },
    { 
      title: 'ระดับสิทธิ์', 
      key: 'role', 
      render: (_, record) => {
        if (record.role === 'admin') return <Tag color="red">ผู้ดูแลระบบ</Tag>;
        if (record.role === 'head_technician') return <Tag color="purple">หัวหน้าช่าง</Tag>;
        if (record.role === 'technician') return <Tag color="cyan">ช่างเทคนิค</Tag>;
        return <Tag color="blue">เจ้าหน้าที่ / ผู้ใช้งาน</Tag>;
      }
    },
    {
      title: 'จัดการ',
      key: 'action',
      align: 'center',
      render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleEditUser(record)}>แก้ไข</Button>
          <Popconfirm title="คุณแน่ใจหรือไม่ที่จะลบผู้ใช้นี้?" onConfirm={() => handleDeleteUser(record.user_id)} okText="ลบ" cancelText="ยกเลิก">
            <Button type="primary" danger size="small" icon={<DeleteOutlined />}>ลบ</Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  // ✅ 1. กรองข้อมูลแบ่งกลุ่มตามสิทธิ์ (Role)
  const adminUsers = users.filter(u => u.role === 'admin');
  const normalUsers = users.filter(u => u.role === 'user');
  const techUsers = users.filter(u => ['technician', 'head_technician'].includes(u.role));

  // ✅ 2. สร้างโครงสร้าง Tabs
  const tabItems = [
    {
      key: '1',
      label: `ช่างซ่อม MA (${techUsers.length})`,
      children: <Table columns={columns} dataSource={techUsers} rowKey="user_id" pagination={{ pageSize: 10 }} />
    },
    {
      key: '2',
      label: `เจ้าหน้าที่ / ผู้ใช้งาน (${normalUsers.length})`,
      children: <Table columns={columns} dataSource={normalUsers} rowKey="user_id" pagination={{ pageSize: 10 }} />
    },
    {
      key: '3',
      label: `ผู้ดูแลระบบ (${adminUsers.length})`,
      children: <Table columns={columns} dataSource={adminUsers} rowKey="user_id" pagination={{ pageSize: 10 }} />
    }
  ];

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <Title level={2} style={{ color: '#2a1a4a', margin: 0 }}><TeamOutlined /> จัดการผู้ใช้งานระบบ</Title>
        <Button type="primary" icon={<PlusOutlined />} size="large" style={{ backgroundColor: '#28a745' }} onClick={handleAddUser}>
          เพิ่มผู้ใช้งานใหม่
        </Button>
      </div>

      {/* ✅ 3. แสดงผลด้วย Antd Tabs */}
      <Card styles={{ body: { padding: '20px' } }} style={{ borderRadius: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
        <Tabs defaultActiveKey="1" items={tabItems} size="large" />
      </Card>

      <Modal 
        title={editingUser ? "✏️ แก้ไขข้อมูลผู้ใช้งาน" : "➕ เพิ่มผู้ใช้งานใหม่"} 
        open={isModalVisible} 
        onCancel={() => setIsModalVisible(false)}
        footer={null}
        destroyOnHidden
      >
        <Form form={form} layout="vertical" onFinish={handleSubmit}>
          <Form.Item name="username" label="ชื่อเข้าใช้งาน (Username)" rules={[{ required: true, message: 'กรุณากรอก Username' }]}>
            <Input disabled={!!editingUser} placeholder="เช่น admin01" />
          </Form.Item>
          
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="first_name" label="ชื่อจริง" rules={[{ required: true, message: 'กรุณากรอกชื่อจริง' }]}>
                <Input placeholder="กรอกชื่อจริง" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="last_name" label="นามสกุล" rules={[{ required: true, message: 'กรุณากรอกนามสกุล' }]}>
                <Input placeholder="กรอกนามสกุล" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="role" label="ระดับสิทธิ์ (Role)" rules={[{ required: true, message: 'กรุณาเลือกสิทธิ์' }]}>
                <Select placeholder="เลือกสิทธิ์">
                  <Option value="admin">ผู้ดูแลระบบ (Admin)</Option>
                  <Option value="head_technician">หัวหน้าช่าง</Option>
                  <Option value="technician">ช่างเทคนิค</Option>
                  <Option value="user">ผู้ใช้งานทั่วไป</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="project_id" label="โปรเจกต์รับผิดชอบ (เฉพาะช่าง)">
                <Select placeholder="เลือกโปรเจกต์" allowClear>
                  {projects.map(p => ( <Option key={p.project_id} value={p.project_id}>{p.project_name}</Option> ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Form.Item name="agency" label="หน่วยงาน / สังกัด">
            <Input placeholder="เช่น ศูนย์ข้อมูลแรงงานแห่งชาติ" />
          </Form.Item>

          <Divider orientation="left"><KeyOutlined /> ตั้งค่ารหัสผ่าน</Divider>
          
          <Form.Item 
            name="new_password" 
            label={editingUser ? "รีเซ็ตรหัสผ่านใหม่ (ปล่อยว่างไว้หากไม่ต้องการเปลี่ยน)" : "ตั้งรหัสผ่าน"} 
            rules={[{ required: !editingUser, message: 'กรุณาตั้งรหัสผ่าน!' }]}
          >
            <Input.Password placeholder={editingUser ? "พิมพ์รหัสผ่านใหม่เพื่อรีเซ็ต" : "ตั้งรหัสผ่านสำหรับคนนี้"} />
          </Form.Item>

          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: 10 }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#1890ff' }}>บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}