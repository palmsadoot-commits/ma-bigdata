import React from 'react';
import { Card, Row, Col, Typography, Divider } from 'antd';
import { 
  UserOutlined, 
  SettingOutlined, 
  TeamOutlined, 
  NotificationOutlined, 
  BarChartOutlined,
  TagsOutlined,
  AppstoreOutlined,
  LinkOutlined,
  DatabaseOutlined,
  FireOutlined,
  CloudServerOutlined
} from '@ant-design/icons';
import { useNavigate } from 'react-router-dom'; 

const { Title, Text } = Typography;

export default function Settings() {
  const navigate = useNavigate(); 
  
  // ✅ ดึงข้อมูล User ปัจจุบันจาก localStorage เพื่อตรวจสอบสิทธิ์
  const currentUser = JSON.parse(localStorage.getItem('lims_user')) || {};
  const isAdmin = currentUser.role === 'admin'; // ตรวจสอบว่าเป็น admin หรือไม่

  // สไตล์สำหรับ Card เมนูให้ดูคล้ายปุ่มกด
  const menuCardStyle = { 
    textAlign: 'center', 
    cursor: 'pointer', 
    borderRadius: '12px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
    transition: 'transform 0.2s'
  };

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      <Title level={2} style={{ color: '#2a1a4a', marginBottom: 30 }}>
        <SettingOutlined /> ตั้งค่าระบบ
      </Title>

      {/* 🟢 กลุ่มที่ 1: ข้อมูลส่วนตัว (มองเห็นได้ทุกคน) */}
      <Divider titlePlacement="left" style={{ borderColor: '#d9d9d9' }}>ข้อมูลส่วนตัว</Divider>
      <Row gutter={[16, 16]} style={{ marginBottom: 30 }}>
        <Col xs={12} sm={8} md={6} lg={4}>
          <Card 
            hoverable 
            style={{ ...menuCardStyle, backgroundColor: '#1890ff' }} 
            styles={{ body: { padding: '20px 10px' } }}
            onClick={() => navigate('/profile')} 
          >
            <UserOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
            <Text strong style={{ display: 'block', color: '#fff' }}>ข้อมูลส่วนตัว</Text>
          </Card>
        </Col>
      </Row>

      {/* 🟢 กลุ่มที่ 2: เกี่ยวกับระบบ (ดักสิทธิ์การมองเห็น) */}
      <Divider titlePlacement="left" style={{ borderColor: '#d9d9d9' }}>เกี่ยวกับระบบ</Divider>
      <Row gutter={[16, 16]} style={{ marginBottom: 30 }}>
        
        {/* 🔒 ซ่อนเมนูเหล่านี้ ให้เฉพาะ Admin เห็นเท่านั้น */}
        {isAdmin && (
          <>
            <Col xs={12} sm={8} md={6} lg={4}>
              <Card hoverable style={{ ...menuCardStyle, backgroundColor: '#0050b3' }} styles={{ body: { padding: '20px 10px' } }}>
                <SettingOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
                <Text strong style={{ display: 'block', color: '#fff' }}>ตั้งค่าระบบ</Text>
              </Card>
            </Col>
            <Col xs={12} sm={8} md={6} lg={4}>
              <Card 
                hoverable 
                style={{ ...menuCardStyle, backgroundColor: '#0050b3' }} 
                styles={{ body: { padding: '20px 10px' } }}
                onClick={() => navigate('/users')}
              >
              <TeamOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
                <Text strong style={{ display: 'block', color: '#fff' }}>ผู้ใช้งานระบบ</Text>
              </Card>
            </Col>
            <Col xs={12} sm={8} md={6} lg={4}>
              <Card hoverable style={{ ...menuCardStyle, backgroundColor: '#0050b3' }} styles={{ body: { padding: '20px 10px' } }}>
                <NotificationOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
                <Text strong style={{ display: 'block', color: '#fff' }}>ประชาสัมพันธ์</Text>
              </Card>
            </Col>
          </>
        )}

        {/* 🟢 มองเห็นได้ทุกคน (รายงาน) */}
        <Col xs={12} sm={8} md={6} lg={4}>
          <Card hoverable style={{ ...menuCardStyle, backgroundColor: '#0050b3' }} styles={{ body: { padding: '20px 10px' } }}>
            <BarChartOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
            <Text strong style={{ display: 'block', color: '#fff' }}>รายงาน</Text>
          </Card>
        </Col>
      </Row>

      {/* 🔒 กลุ่มที่ 3: ผู้ดูแลระบบ (เฉพาะ Admin เท่านั้น) */}
      {isAdmin && (
        <>
          <Divider titlePlacement="left" style={{ borderColor: '#d9d9d9' }}>ผู้ดูแลระบบ (Admin)</Divider>
          <Row gutter={[16, 16]}>
            <Col xs={12} sm={8} md={6} lg={4}>
              <Card 
                hoverable 
                style={{ ...menuCardStyle, backgroundColor: '#8b5cf6' }} // สีม่วง
                styles={{ body: { padding: '20px 10px' } }}
                onClick={() => navigate('/statuses')} 
              >
                <TagsOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
                <Text strong style={{ display: 'block', color: '#fff' }}>ป้ายสถานะ</Text>
              </Card>
            </Col>
            <Col xs={12} sm={8} md={6} lg={4}>
              <Card hoverable style={{ ...menuCardStyle, backgroundColor: '#cf1322' }} styles={{ body: { padding: '20px 10px' } }}>
                <TeamOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
                <Text strong style={{ display: 'block', color: '#fff' }}>สิทธิ์การเข้าถึง</Text>
              </Card>
            </Col>
            <Col xs={12} sm={8} md={6} lg={4}>
              <Card hoverable style={{ ...menuCardStyle, backgroundColor: '#cf1322' }} styles={{ body: { padding: '20px 10px' } }}>
                <LinkOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
                <Text strong style={{ display: 'block', color: '#fff' }}>ระบบลิงก์ / เมนู</Text>
              </Card>
            </Col>
            <Col xs={12} sm={8} md={6} lg={4}>
              <Card 
                  hoverable style={{ ...menuCardStyle, backgroundColor: '#cf1322' }} 
                  styles={{ body: { padding: '20px 10px' } }}
                  onClick={() => navigate('/categories')}
                >
                <AppstoreOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
                <Text strong style={{ display: 'block', color: '#fff' }}>หมวดหมู่ / ระบบ</Text>
              </Card>
            </Col>
            <Col xs={12} sm={8} md={6} lg={4}>
              <Card hoverable style={{ ...menuCardStyle, backgroundColor: '#0ea5e9' }} styles={{ body: { padding: '20px 10px' } }} onClick={() => navigate('/backup')}>
                <CloudServerOutlined style={{ fontSize: '40px', color: '#fff', marginBottom: '10px' }} />
                <Text strong style={{ display: 'block', color: '#fff' }}>Backup & Restore</Text>
              </Card>
            </Col>
          </Row>
        </>
      )}

    </div>
  );
}