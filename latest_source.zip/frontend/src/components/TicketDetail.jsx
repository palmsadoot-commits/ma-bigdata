import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Typography, Tag, Button, Spin, Result, Form, Select, Input, Row, Col, Divider, Space, Steps, Upload, Timeline, Card, message, Avatar } from 'antd'; 
import { ArrowLeftOutlined, ClockCircleOutlined, OrderedListOutlined, PrinterOutlined, FileImageOutlined, UserOutlined, UploadOutlined, DesktopOutlined } from '@ant-design/icons';
import axios from 'axios';
import { alertSuccess, alertError, alertConfirm } from '../utils/alert';
import { formatThaiDate } from '../utils/dateUtils';

const { Title, Text } = Typography;
const { TextArea } = Input;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000';

export default function TicketDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [ticket, setTicket] = useState(null);
  const [logs, setLogs] = useState([]); 
  const [loading, setLoading] = useState(true);
  const [technicians, setTechnicians] = useState([]);
  
  const [fileList, setFileList] = useState([]);
  const [assignForm] = Form.useForm();
  const [updateForm] = Form.useForm();

  const [isRejecting, setIsRejecting] = useState(false);
  const [rejectFileList, setRejectFileList] = useState([]);
  const [rejectForm] = Form.useForm();

  const [elapsedTime, setElapsedTime] = useState('กำลังคำนวณ...');
  const currentUser = JSON.parse(localStorage.getItem('lims_user'));

  const fetchData = async () => {
    try {
      const [ticketRes, logsRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/tickets/${id}`),
        axios.get(`${BACKEND_URL}/api/tickets/${id}/logs`).catch(() => ({ data: [] }))
      ]);
      setTicket(ticketRes.data);
      setLogs(logsRes.data);
      updateForm.setFieldsValue({ root_cause_and_solution: ticketRes.data.root_cause_and_solution || '' });
      assignForm.setFieldsValue({ assigned_to: ticketRes.data.assigned_to });
      
      if (currentUser?.role !== 'user' && currentUser?.project_id) {
        fetchTechnicians(currentUser.project_id);
      }
    } catch (err) {
      alertError('ข้อผิดพลาด', 'ไม่สามารถโหลดข้อมูลรายละเอียดใบงานได้');
    } finally {
      setLoading(false);
    }
  };

  const fetchTechnicians = async (projectId) => {
    try {
      const res = await axios.get(`${BACKEND_URL}/api/technicians?project_id=${projectId}`);
      setTechnicians(res.data);
    } catch (err) { console.error(err); }
  };

  useEffect(() => { fetchData(); }, [id]);

  useEffect(() => {
    if (!ticket) return;

    const calculateTime = () => {
      const startTime = new Date(ticket.created_at).getTime();
      let endTime = new Date().getTime(); 

      if (ticket.status === 'Closed') {
        const closeLog = logs.find(l => l.action === 'ปิดเคสสมบูรณ์');
        if (closeLog) endTime = new Date(closeLog.created_at).getTime();
        else endTime = new Date(ticket.updated_at || new Date()).getTime();
      }

      const diff = endTime - startTime;
      if (diff < 0) return;

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setElapsedTime(`${hours} ชม. ${minutes} นาที ${seconds} วินาที`);
    };

    calculateTime(); 
    
    if (ticket.status !== 'Closed') {
      const timer = setInterval(calculateTime, 1000);
      return () => clearInterval(timer);
    }
  }, [ticket, logs]);

  const handleUploadChange = ({ fileList: newFileList, file }) => {
    setFileList(newFileList);
    if (file.status !== 'removed' && file.name) message.success(`เลือกไฟล์ ${file.name} สำเร็จ!`);
  };

  const handleRejectUploadChange = ({ fileList: newFileList, file }) => {
    setRejectFileList(newFileList);
    if (file.status !== 'removed' && file.name) message.success(`เลือกไฟล์ ${file.name} สำหรับตีกลับแล้ว!`);
  };

  const addLog = async (actionName, detailMsg) => {
    const actor_name = `${currentUser?.first_name} ${currentUser?.last_name}`;
    try {
      await axios.post(`${BACKEND_URL}/api/tickets/${id}/logs`, { action: actionName, actor_name, detail: detailMsg });
    } catch (err) { console.error('Failed to save log'); }
  };

  const renderLogDetailWithFiles = (detailText) => {
    if (!detailText) return null;
    const fileRegex = /\[แนบไฟล์(?:เพิ่มเติม)?:\s*(.*?)\]/;
    const match = detailText.match(fileRegex);
    
    let textWithoutFiles = detailText;
    let files = [];

    if (match) {
        textWithoutFiles = detailText.replace(fileRegex, '').trim();
        files = match[1].split(',').map(f => f.trim());
    }

    return (
      <div style={{ padding: '5px 0' }}>
        <div style={{ marginBottom: '15px' }}>
          {textWithoutFiles.split('\n').map((line, index) => (
            <div key={index} style={{ 
                borderBottom: '1px dashed #c0c0c0', 
                minHeight: '28px', 
                lineHeight: '28px',
                color: '#333',
                fontSize: '14px' 
            }}>
                {line || '\u00A0'} 
            </div>
          ))}
        </div>

        {files.length > 0 && (
          <Space wrap style={{ marginTop: 10 }}>
            {files.map((file, idx) => (
              <Button key={idx} size="small" type="dashed" icon={<FileImageOutlined style={{ color: '#1890ff' }} />} onClick={() => window.open(`${BACKEND_URL}/uploads/${file}`)}>
                {file}
              </Button>
            ))}
          </Space>
        )}
      </div>
    );
  };

  const handleAssign = async (values) => {
    try {
      await axios.put(`${BACKEND_URL}/api/tickets/${id}/assign`, { assigned_to: values.assigned_to });
      const techName = technicians.find(t => t.user_id === values.assigned_to)?.full_name || 'ช่าง';
      await addLog('มอบหมายงาน', `จ่ายงานให้: ${techName}`);
      await alertSuccess('สำเร็จ!', 'มอบหมายงานเรียบร้อยแล้ว');
      fetchData(); 
    } catch (error) { alertError('เกิดข้อผิดพลาด!'); }
  };

  const handleSelfAssign = async () => {
    try {
      await axios.put(`${BACKEND_URL}/api/tickets/${id}/assign`, { assigned_to: currentUser.user_id });
      await addLog('รับงาน', 'ช่างกดรับผิดชอบงานนี้เข้าตัวเอง');
      await alertSuccess('รับงานสำเร็จ!', 'ระบบเริ่มจับเวลาการแก้ไขของคุณแล้ว');
      fetchData(); 
    } catch (error) { alertError('เกิดข้อผิดพลาด!'); }
  };

  const handleReturnTicket = async () => {
    const result = await alertConfirm('ยืนยันการตีกลับงาน?', 'คุณต้องการคืนงานนี้ให้หัวหน้าใช่หรือไม่?');
    if (result.isConfirmed) {
      try {
        await axios.put(`${BACKEND_URL}/api/tickets/${id}/return`);
        await addLog('ตีกลับงาน (ช่าง)', 'ช่างยกเลิกการรับงานและส่งคืนหัวหน้า');
        await alertSuccess('ตีกลับสำเร็จ!', 'ส่งงานคืนให้หัวหน้าช่างเรียบร้อยแล้ว');
        fetchData();
      } catch (error) { alertError('เกิดข้อผิดพลาด!'); }
    }
  };

  const handleSubmitFix = async (values) => {
    try {
      const formData = new FormData();
      formData.append('status', 'Resolved');
      formData.append('root_cause_and_solution', values.root_cause_and_solution);
      formData.append('technician_id', currentUser?.user_id);
      fileList.forEach(file => formData.append('attachments', file.originFileObj));

      const res = await axios.put(`${BACKEND_URL}/api/tickets/${id}/update-status`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      const savedFiles = res.data.files || [];
      const attachMsg = savedFiles.length > 0 ? `\n[แนบไฟล์: ${savedFiles.join(',')}]` : '';
      
      await addLog('ส่งตรวจสอบ', `วิธีแก้ไข: ${values.root_cause_and_solution}${attachMsg}`);
      await alertSuccess('ส่งตรวจสอบสำเร็จ!', 'รอผู้แจ้งยืนยันการปิดงาน');
      setFileList([]); fetchData(); 
    } catch (error) { alertError('เกิดข้อผิดพลาด!'); }
  };

  const handleApproveTicket = async () => {
    try {
      await axios.put(`${BACKEND_URL}/api/tickets/${id}/update-status`, { status: 'Closed', technician_id: ticket.technician_id });
      await addLog('ปิดเคสสมบูรณ์', 'ผู้แจ้งตรวจสอบและยืนยันการปิดงาน');
      await alertSuccess('ปิดงานสำเร็จ!');
      fetchData();
    } catch (error) { alertError('เกิดข้อผิดพลาด!'); }
  };

  const handleRejectSubmit = async (values) => {
    try {
      const formData = new FormData();
      formData.append('status', 'In Progress');
      formData.append('technician_id', ticket.technician_id);
      rejectFileList.forEach(file => formData.append('attachments', file.originFileObj));

      const res = await axios.put(`${BACKEND_URL}/api/tickets/${id}/update-status`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      const savedFiles = res.data.files || [];
      const attachMsg = savedFiles.length > 0 ? `\n[แนบไฟล์เพิ่มเติม: ${savedFiles.join(',')}]` : '';
      
      await addLog('ตีกลับให้แก้ไขใหม่', `เหตุผลที่ตีกลับ: ${values.reject_reason}${attachMsg}`);
      await alertSuccess('ส่งกลับให้ช่างแก้ไขใหม่แล้ว (สถานะ: แก้ไข)');
      setIsRejecting(false); rejectForm.resetFields(); setRejectFileList([]); fetchData();
    } catch (error) { alertError('เกิดข้อผิดพลาด!'); }
  };

  if (loading) return <div style={{ textAlign: 'center', marginTop: 100 }}><Spin size="large" /></div>;
  if (!ticket) return <Result status="404" title="ไม่พบข้อมูล" />;

  // ==========================================
  // 🔥 ลอจิก 5 ขั้นตอน + เช็คเงื่อนไขตีกลับแดง
  // ==========================================
  const getStepCurrent = () => {
    if (ticket.status === 'Pending') return 1;       // รับงาน/มอบหมาย
    if (ticket.status === 'In Progress') return 2;   // กำลังดำเนินการ
    if (ticket.status === 'Resolved') return 3;      // ตรวจสอบ
    if (ticket.status === 'Closed') return 4;        // ปิดเคส
    return 0;
  };

  const isRejected = ticket.resolved_at && ticket.status === 'In Progress';

  const stepItems = [
    { title: 'แจ้งเคส', description: 'ส่งเข้าระบบ' },
    { title: 'รับงาน/มอบหมาย', description: 'รอช่างเข้ารับงาน' },
    { title: isRejected ? 'แก้ไขใหม่ ↩️' : 'กำลังดำเนินการ', description: 'ช่างสามารถตีกลับ ↩️' },
    { title: 'ตรวจสอบ', description: 'ส่งแก้ ↩️ / ปิดงาน ⏭️' },
    { title: 'ปิดเคส', description: 'งานเสร็จสมบูรณ์' }
  ];

  // แปลงสถานะให้เป็นป้ายภาษาไทย
  const getStatusTag = (status) => {
    if (status === 'Pending') return <Tag color="red" style={{ fontSize: 16, padding: '4px 16px', borderRadius: 20 }}>รอดำเนินการ (Pending)</Tag>;
    if (status === 'In Progress') return <Tag color="orange" style={{ fontSize: 16, padding: '4px 16px', borderRadius: 20 }}>{isRejected ? 'แก้ไขใหม่ (Rejected)' : 'กำลังดำเนินการ (In Progress)'}</Tag>;
    if (status === 'Resolved') return <Tag color="cyan" style={{ fontSize: 16, padding: '4px 16px', borderRadius: 20 }}>รอตรวจสอบ (Resolved)</Tag>;
    if (status === 'Closed') return <Tag color="green" style={{ fontSize: 16, padding: '4px 16px', borderRadius: 20 }}>ปิดเคสสมบูรณ์ (Closed)</Tag>;
    return <Tag color="default">{status}</Tag>;
  };

  const modernCardStyle = { borderRadius: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.04)', border: 'none', marginBottom: 20 };

  return (
    <div style={{ width: '100%', padding: '10px 20px', margin: '0 auto', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      
      <div style={{ marginBottom: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Button icon={<ArrowLeftOutlined />} onClick={() => navigate(-1)} style={{ borderRadius: 8 }}>ย้อนกลับ</Button>
        <Link to={`/print/${ticket.ticket_id}`} target="_blank">
          <Button type="primary" icon={<PrinterOutlined />} style={{ backgroundColor: '#28a745', borderColor: '#28a745', borderRadius: 8 }}>พิมพ์ใบงาน</Button>
        </Link>
      </div>

      <Card style={modernCardStyle} bodyStyle={{ padding: '24px 40px' }}>
        <Steps 
          current={getStepCurrent()} 
          size="small" 
          items={stepItems} 
          status={isRejected ? 'error' : 'process'} // 🔥 ถ้ามีการตีกลับ จะโชว์จุดสีแดง
        />
      </Card>

      <Row gutter={[24, 24]}>
        <Col xs={24} lg={15}>
          
          <Card style={modernCardStyle} bodyStyle={{ padding: '30px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, paddingBottom: 20, borderBottom: '2px solid #f0f0f0' }}>
              <Title level={3} style={{ margin: 0, color: '#2a1a4a' }}>รหัสใบงาน {ticket.ticket_number}</Title>
              <Title level={5} style={{ margin: 0, color: '#2a1a4a' }}>วันเวลาที่แจ้ง <Text>{formatThaiDate(ticket.created_at)}</Text></Title>
              {getStatusTag(ticket.status)}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 20 }}>
              <Avatar size={55} icon={<UserOutlined />} style={{ backgroundColor: '#ef8157', marginRight: 15 }} />
              <div>
                <Title level={5} style={{ display: 'flex', alignItems: 'left', marginBottom: -2 }}>ผู้แจ้ง </Title>
                <Text type="secondary">ชื่อ: {ticket.reporter_name} | หน่วยงาน: {ticket.reporter_department || 'ไม่ระบุหน่วยงาน'}  </Text>
              </div>
            </div>

            <Space size="large" style={{ marginBottom: 15, display: 'flex', flexWrap: 'wrap' }}>
              <div>
                <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>หมวดหมู่ระบบ</Text>
                <Tag color="blue" icon={<DesktopOutlined />} style={{ padding: '4px 10px', fontSize: 14, borderRadius: 6 }}>{ticket.category_name}</Tag>
              </div>
              <div>
                <Text type="secondary" style={{ display: 'block', fontSize: 12 }}>เลขครุภัณฑ์ / อุปกรณ์</Text>
                <Text strong>{ticket.equipment_no || '-'}</Text>
              </div>
            </Space>

            <div style={{ marginBottom: 25, marginTop: 15 }}>
              <Divider orientation="center" style={{ borderColor: '#f0f0f0' }}><><DesktopOutlined /> รายละเอียดปัญหาเบื้องต้น</></Divider>
              
              <div style={{ backgroundColor: '#fcfcfc', padding: '15px 20px', borderRadius: '8px', border: '1px solid #f0f0f0' }}>
                {ticket.problem_detail ? (
                  <div 
                    style={{ color: '#333', fontSize: '15px', lineHeight: '1.6' }} 
                    dangerouslySetInnerHTML={{ __html: ticket.problem_detail }} 
                  />
                ) : <Text type="secondary">-</Text>}
              </div>
            </div>

            <div style={{ marginTop: 20 }}>
              <Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 5 }}><FileImageOutlined /> ไฟล์แนบ (ตอนเปิดใบงาน)</Text>
              {ticket.attachment ? (
                <Button type="dashed" style={{ borderRadius: 6 }} onClick={() => window.open(`${BACKEND_URL}/uploads/${ticket.attachment}`)}>
                  {ticket.attachment}
                </Button>
              ) : <Text type="secondary">ไม่มีไฟล์แนบ</Text>}
            </div>
          </Card>

          {logs.filter(log => ['ส่งตรวจสอบ', 'ตีกลับให้แก้ไขใหม่'].includes(log.action)).length > 0 && (
            <Card title={<><OrderedListOutlined style={{ fontSize: '30px', color: '#eb2f96' }} />  ประวัติกการแก้ไข</>} style={modernCardStyle} headStyle={{ borderBottom: '1px solid #f0f0f0', backgroundColor: '#fafafa' }}>
              {logs.filter(log => ['ส่งตรวจสอบ', 'ตีกลับให้แก้ไขใหม่'].includes(log.action)).map(log => {
                const isTech = log.action === 'ส่งตรวจสอบ';
                const avatarColor = isTech ? '#1890ff' : '#ef8157'; 
                
                return (
                  <div key={log.log_id} style={{ display: 'flex', marginBottom: 20, flexDirection: isTech ? 'row-reverse' : 'row' }}>
                     <Avatar size={45} icon={<UserOutlined />} style={{ backgroundColor: avatarColor, margin: isTech ? '0 0 0 15px' : '0 15px 0 0' }} />
                     <div style={{ width: '45%', minWidth: '300px', backgroundColor: isTech ? '#e6f7ff' : '#fff1f0', border: `1px solid ${isTech ? '#91d5ff' : '#ffa39e'}`, padding: '15px 20px', borderRadius: 12 }}>
                       <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12, alignItems: 'center' }}>
                         <Text strong style={{ color: isTech ? '#0050b3' : '#a8071a', fontSize: '15px' }}>
                           {log.actor_name} {isTech ? '(ช่าง)' : '(ผู้แจ้ง)'}
                         </Text>
                         <Text type="secondary" style={{ fontSize: 12 }}>{formatThaiDate(log.created_at)}</Text>
                       </div>
                       {renderLogDetailWithFiles(log.detail)}
                     </div>
                  </div>
                );
              })}
            </Card>
          )}
        </Col>

        <Col xs={24} lg={9}>
          
          <Card title="⚡ การดำเนินการ" style={modernCardStyle} headStyle={{ borderBottom: '1px solid #f0f0f0' }}>
            
            <div style={{ marginBottom: 20 }}>
              <Text type="secondary" style={{ display: 'block', fontSize: 12, marginBottom: 5 }}>ผู้รับผิดชอบปัจจุบัน</Text>
              {ticket.assigned_to_name ? (
                <div style={{ display: 'flex', alignItems: 'center', backgroundColor: '#f0f5ff', padding: '10px 15px', borderRadius: 8, border: '1px solid #adc6ff' }}>
                  <Avatar icon={<UserOutlined />} style={{ backgroundColor: '#1890ff', marginRight: 15 }} size="large" />
                  <Text strong style={{ color: '#1d39c4', fontSize: 16 }}>{ticket.assigned_to_name}</Text>
                </div>
              ) : (
                <Tag color="default" style={{ borderRadius: 6, padding: '4px 10px' }}>ยังไม่มีผู้รับผิดชอบ</Tag>
              )}
            </div>

            {currentUser?.role !== 'user' && (
              <>
                {ticket.status === 'Pending' && (
                  <div style={{ marginTop: 20 }}>
                    {(currentUser?.role === 'admin' || currentUser?.role === 'head_technician') ? (
                      <Form form={assignForm} layout="vertical" onFinish={handleAssign}>
                        <Form.Item name="assigned_to" rules={[{ required: true, message: 'กรุณาเลือกช่าง' }]}>
                          <Select placeholder="-- เลือกช่างเพื่อจ่ายงาน --" size="large">
                            {technicians.map(t => (<Option key={t.user_id} value={t.user_id}>{t.full_name}</Option>))}
                          </Select>
                        </Form.Item>
                        <Button type="primary" htmlType="submit" size="large" block style={{ borderRadius: 8 }}>บันทึกการจ่ายงาน</Button>
                      </Form>
                    ) : (
                      <Button type="primary" onClick={handleSelfAssign} style={{ backgroundColor: '#2a1a4a', borderRadius: 8 }} size="large" block>🙋‍♂️ กดรับผิดชอบงานนี้</Button>
                    )}
                  </div>
                )}

                {ticket.status === 'In Progress' && (
                  <div style={{ marginTop: 20 }}>
                    {ticket.assigned_to === currentUser?.user_id || currentUser?.role === 'head_technician' || currentUser?.role === 'admin' ? (
                      <Form form={updateForm} layout="vertical" onFinish={handleSubmitFix}>
                        <Form.Item name="root_cause_and_solution" label="บันทึกวิธีแก้ไขปัญหา" rules={[{ required: true, message: 'กรุณาระบุวิธีแก้ไข!' }]}>
                          <TextArea rows={4} placeholder="ระบุสิ่งที่ได้ดำเนินการแก้ไข..." style={{ borderRadius: 8 }} />
                        </Form.Item>
                        <Form.Item label="อัปโหลดไฟล์/รูปภาพ (ถ้ามี)">
                          <Upload multiple beforeUpload={() => false} fileList={fileList} onChange={handleUploadChange}>
                            <Button icon={<UploadOutlined />} style={{ borderRadius: 8 }}>เลือกไฟล์แนบเพิ่ม</Button>
                          </Upload>
                        </Form.Item>
                        <Button type="primary" htmlType="submit" size="large" block style={{ backgroundColor: '#ef8157', borderColor: '#ef8157', borderRadius: 8 }}>
                          ส่งผลงานให้ตรวจ
                        </Button>
                        {ticket.assigned_to === currentUser?.user_id && (
                          <Button type="text" danger onClick={handleReturnTicket} block style={{ marginTop: 10 }}>ยกเลิกการรับงาน (คืนหัวหน้า)</Button>
                        )}
                      </Form>
                    ) : <Text type="secondary">รอช่างผู้รับผิดชอบดำเนินการ...</Text>}
                  </div>
                )}
              </>
            )}

            {(currentUser?.role === 'user' || currentUser?.role === 'admin') && ticket.status === 'Resolved' && (
               <div style={{ marginTop: 20 }}>
                 <Text strong style={{ color: '#389e0d' }}>ช่างดำเนินการแก้ไขแล้ว</Text>
                 <Text type="secondary" style={{ display: 'block', marginBottom: 15 }}>กรุณาตรวจสอบการใช้งานและยืนยันการปิดเคส</Text>
                 {!isRejecting ? (
                   <Space direction="vertical" style={{ width: '100%' }}>
                     <Button type="primary" size="large" block style={{ backgroundColor: '#52c41a', borderRadius: 8 }} onClick={handleApproveTicket}>✅ ใช้งานได้ปกติ (ปิดเคส)</Button>
                     <Button danger size="large" block style={{ borderRadius: 8 }} onClick={() => setIsRejecting(true)}>❌ ยังใช้งานไม่ได้ (ตีกลับ)</Button>
                   </Space>
                 ) : (
                   <Form form={rejectForm} layout="vertical" onFinish={handleRejectSubmit} style={{ marginTop: 15, padding: 15, backgroundColor: '#fff1f0', borderRadius: 8, border: '1px solid #ffa39e' }}>
                     <Form.Item name="reject_reason" label="เหตุผลที่ตีกลับ" rules={[{ required: true, message: 'กรุณาระบุเหตุผล!' }]}>
                       <TextArea rows={3} placeholder="อธิบายให้ช่างทราบ..." style={{ borderRadius: 8 }} />
                     </Form.Item>
                     <Form.Item label="แนบไฟล์เพิ่มเติม (ถ้ามี)">
                       <Upload multiple beforeUpload={() => false} fileList={rejectFileList} onChange={handleRejectUploadChange}>
                         <Button icon={<UploadOutlined />} style={{ borderRadius: 8 }}>เลือกไฟล์แนบ</Button>
                       </Upload>
                     </Form.Item>
                     <Space style={{ display: 'flex', justifyContent: 'flex-end' }}>
                       <Button onClick={() => setIsRejecting(false)}>ยกเลิก</Button>
                       <Button type="primary" danger htmlType="submit">ยืนยันตีกลับ</Button>
                     </Space>
                   </Form>
                 )}
               </div>
            )}

            {ticket.status === 'Closed' && (
              <Result status="success" title="งานนี้ปิดสมบูรณ์แล้ว" style={{ padding: 10 }} />
            )}
          </Card>

          <Card title={<><ClockCircleOutlined spin style={{ fontSize: '30px', color: '#ef8157' }} /> Timeline & SLA</>} style={modernCardStyle} headStyle={{ borderBottom: '1px solid #f0f0f0' }}>
            
            <div style={{ 
              backgroundColor: Number(ticket.is_cm) === 1 ? (ticket.is_sla_breached === 1 ? '#fff1f0' : '#f0fdf4') : '#f8fafc', 
              padding: 15, 
              borderRadius: 8, 
              marginBottom: 20, 
              textAlign: 'center', 
              border: `1px solid ${Number(ticket.is_cm) === 1 ? (ticket.is_sla_breached === 1 ? '#ffa39e' : '#bbf7d0') : '#e2e8f0'}` 
            }}>
              {/* ส่วนแสดงเวลา (ใช้ elapsedTime ที่มีอยู่แล้ว) */}
              <Text type="secondary">{ticket.status === 'Closed' ? 'เวลาที่ใช้ไปทั้งสิ้น' : 'เวลาที่ใช้ไปแล้ว (ขณะนี้)'}</Text><br/>
              <Title level={3} style={{ margin: '5px 0', color: Number(ticket.is_cm) === 1 && ticket.is_sla_breached === 1 ? '#ef4444' : '#2a1a4a' }}>
                {elapsedTime}
              </Title>
              
              <div style={{ textAlign: 'left', marginTop: 15, fontSize: 13, backgroundColor: '#fff', padding: 10, borderRadius: 6, border: '1px solid #e2e8f0' }}>
                
                {/* ข้อมูลพื้นฐาน: แจ้งเมื่อไร */}
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, borderBottom: '1px dashed #e2e8f0', paddingBottom: 8 }}>
                  <Text><b>แจ้งเมื่อ:</b></Text>
                  <Text>{formatThaiDate(ticket.created_at)}</Text>
                </div>

                {/* แยกการแสดงผลระหว่างงาน CM และ งานทั่วไป */}
                {Number(ticket.is_cm) === 1 ? (
                  <>
                    {['Hardware', 'Software'].includes(ticket.category_type) && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, borderBottom: '1px dashed #e2e8f0', paddingBottom: 8 }}>
                        <Text><b>เข้าดำเนินการ (2 ชม.):</b></Text>
                        {ticket.acknowledged_at ? (
                          <Tag color="blue" style={{ margin: 0 }}>รับงานแล้ว {new Date(ticket.acknowledged_at).toLocaleTimeString('th-TH')}</Tag>
                        ) : (
                          ticket.status === 'Pending' ? <Tag color="warning" style={{ margin: 0 }}>รอช่างกดรับงาน</Tag> : <Tag color="default" style={{ margin: 0 }}>-</Tag>
                        )}
                      </div>
                    )}
                    
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Text><b>สถานะ SLA:</b></Text>
                      {ticket.is_sla_breached === 1 ? (
                        <Tag color="red" style={{ margin: 0 }}>เกินเวลา (ปรับ {parseFloat(ticket.penalty_amount || 0).toLocaleString()} ฿)</Tag>
                      ) : (
                        ['Resolved', 'Closed'].includes(ticket.status) ? 
                          <Tag color="green" style={{ margin: 0 }}>ซ่อมเสร็จทันเวลา</Tag> : 
                          <Tag color="processing" style={{ margin: 0 }}>อยู่ในเกณฑ์เวลา</Tag>
                      )}
                    </div>
                  </>
                ) : (
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Text><b>ประเภท:</b></Text>
                    <Tag color="default" style={{ margin: 0 }}>ใบงานทั่วไป (ไม่นำมาคิด SLA)</Tag>
                  </div>
                )}

                {ticket.sla_deadline && Number(ticket.is_cm) === 1 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
                    <Text type="secondary">กำหนดเสร็จ:</Text>
                    <Text type="secondary">{new Date(ticket.sla_deadline).toLocaleString('th-TH').slice(0, -3)} น.</Text>
                  </div>
                )}
              </div>
            </div>

            {/* Timeline การดำเนินการด้านล่างยังคงเดิม */}
            <Timeline style={{ paddingLeft: 10 }}>
              <Timeline.Item color="green">
                <Text strong>แจ้งเคส</Text><br/>
                <Text type="secondary" style={{ fontSize: 12 }}><Text>{formatThaiDate(ticket.created_at)}</Text></Text>
              </Timeline.Item>
              
              {logs.map(log => {
                let color = 'blue';
                if (log.action.includes('ตีกลับ')) color = 'red';
                if (log.action.includes('ส่งตรวจสอบ')) color = 'orange';
                if (log.action.includes('ปิดเคส')) color = 'green';

                return (
                  <Timeline.Item key={log.log_id} color={color}>
                    <Text strong>{log.action}</Text><br/>
                    <Text type="secondary" style={{ fontSize: 12 }}>{formatThaiDate(log.created_at)} • {log.actor_name}</Text>
                  </Timeline.Item>
                );
              })}
            </Timeline>
          </Card>

        </Col>
      </Row>
    </div>
  );
}