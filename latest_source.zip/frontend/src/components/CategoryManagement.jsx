import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Space, Typography, Tag, Modal, Form, Input, Select, Popconfirm, Row, Col, Tabs } from 'antd';
import { 
  AppstoreOutlined, PlusOutlined, EditOutlined, DeleteOutlined, 
  ArrowLeftOutlined, GlobalOutlined, ApartmentOutlined, SettingOutlined,
  DesktopOutlined, ApiOutlined, DatabaseOutlined, TagsOutlined, ProfileOutlined
} from '@ant-design/icons';
import axios from 'axios';
import { alertSuccess, alertError } from '../utils/alert';

const { Title, Text } = Typography;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000';

export default function CategoryManagement() {
  const [categories, setCategories] = useState([]);
  const [projects, setProjects] = useState([]);
  const [categoryTypes, setCategoryTypes] = useState([]); // ✅ State เก็บประเภท (Type)
  const [loading, setLoading] = useState(false);
  
  // States สำหรับ Category
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null); 
  const [catForm] = Form.useForm();

  // States สำหรับ Project
  const [isProjModalVisible, setIsProjModalVisible] = useState(false);
  const [editingProject, setEditingProject] = useState(null); 
  const [projForm] = Form.useForm();
  const [isProjManageModalVisible, setIsProjManageModalVisible] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);

  // States สำหรับจัดการประเภท (Type)
  const [isTypeManageModalVisible, setIsTypeManageModalVisible] = useState(false);
  const [isTypeModalVisible, setIsTypeModalVisible] = useState(false);
  const [editingType, setEditingType] = useState(null);
  const [typeForm] = Form.useForm();

  const fetchData = async () => {
    setLoading(true);
    try {
      const [catRes, projRes, typeRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/categories`),
        axios.get(`${BACKEND_URL}/api/projects`),
        axios.get(`${BACKEND_URL}/api/category-types`) // ดึง Types จาก DB
      ]);
      
      const sortedCats = catRes.data.sort((a, b) => a.category_id - b.category_id);
      const sortedProjs = projRes.data.sort((a, b) => a.project_id - b.project_id);
      
      setCategories(sortedCats);
      setProjects(sortedProjs);
      setCategoryTypes(typeRes.data || []);
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูลได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  // ==========================================
  // 🗂️ จัดการประเภทและหัวตาราง (Types)
  // ==========================================
  const handleTypeManage = () => setIsTypeManageModalVisible(true);

  const handleTypeAdd = () => {
    setEditingType(null);
    typeForm.resetFields();
    setIsTypeModalVisible(true);
  };

  const handleTypeEdit = (record) => {
    setEditingType(record);
    typeForm.setFieldsValue(record);
    setIsTypeModalVisible(true);
  };

  const handleTypeDelete = async (id) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/category-types/${id}`);
      alertSuccess('ลบสำเร็จ', 'ประเภทถูกลบออกแล้ว');
      fetchData(); 
    } catch (error) {
      alertError('ลบไม่สำเร็จ', 'ไม่สามารถลบได้');
    }
  };

  const handleTypeSubmit = async (values) => {
    try {
      if (editingType) {
        await axios.put(`${BACKEND_URL}/api/category-types/${editingType.type_id}`, values);
        alertSuccess('อัปเดตสำเร็จ', 'แก้ไขประเภทเรียบร้อย');
      } else {
        await axios.post(`${BACKEND_URL}/api/category-types`, values);
        alertSuccess('เพิ่มสำเร็จ', 'เพิ่มประเภทใหม่เรียบร้อย');
      }
      setIsTypeModalVisible(false);
      fetchData(); 
    } catch (error) {
      alertError('บันทึกไม่สำเร็จ', 'รหัส Type อาจซ้ำกัน');
    }
  };

  const typeColumns = [
    { title: 'ชื่อประเภท (อังกฤษ/รหัส)', dataIndex: 'type_code', key: 'type_code' },
    { title: 'ชื่อที่แสดงบนหัวตาราง', dataIndex: 'type_name', key: 'type_name' },
    {
      title: 'จัดการ', key: 'action', align: 'right', width: 120,
      render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleTypeEdit(record)} />
          <Popconfirm title="ยืนยันการลบ?" onConfirm={() => handleTypeDelete(record.type_id)} okText="ลบ" cancelText="ยกเลิก">
            <Button type="primary" danger size="small" icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  // ==========================================
  // จัดการโครงการ (Projects) 
  // ==========================================
  const handleProjectManage = () => setIsProjManageModalVisible(true);
  const handleProjectAdd = () => { setEditingProject(null); projForm.resetFields(); setIsProjModalVisible(true); };
  const handleProjectEdit = (record) => { setEditingProject(record); projForm.setFieldsValue(record); setIsProjModalVisible(true); };
  const handleProjectDelete = async (id) => {
    try { await axios.delete(`${BACKEND_URL}/api/projects/${id}`); alertSuccess('ลบสำเร็จ', 'ลบโครงการแล้ว'); fetchData(); } 
    catch (error) { alertError('ลบไม่สำเร็จ', error.response?.data?.error || 'เกิดข้อผิดพลาด'); }
  };
  const handleProjectSubmit = async (values) => {
    try {
      if (editingProject) await axios.put(`${BACKEND_URL}/api/projects/${editingProject.project_id}`, values);
      else await axios.post(`${BACKEND_URL}/api/projects`, values);
      setIsProjModalVisible(false); fetchData(); alertSuccess('สำเร็จ', 'บันทึกข้อมูลเรียบร้อย');
    } catch (error) { alertError('บันทึกไม่สำเร็จ', 'เกิดข้อผิดพลาด'); }
  };

  const projManageColumns = [
    { title: 'รหัสโครงการ', dataIndex: 'project_id', key: 'project_id', align: 'center', width: 100 },
    { title: 'ชื่อโครงการ', dataIndex: 'project_name', key: 'project_name' },
    { title: 'รายละเอียด', dataIndex: 'description', key: 'description', render: (text) => text || '-' },
    { title: 'เลขที่สัญญา', dataIndex: 'project_contract', key: 'project_contract', render: (text) => text || '-' },
    { title: 'จัดการ', key: 'action', align: 'right', width: 120, render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleProjectEdit(record)} />
          <Popconfirm title="ยืนยันการลบ?" onConfirm={() => handleProjectDelete(record.project_id)} okText="ลบ" cancelText="ยกเลิก"><Button type="primary" danger size="small" icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    },
  ];

  // ==========================================
  // จัดการหมวดหมู่ (Categories)
  // ==========================================
  const handleCatAdd = () => {
    setEditingCategory(null); catForm.resetFields();
    catForm.setFieldsValue({ project_id: selectedProject ? selectedProject.project_id : undefined });
    setIsModalVisible(true);
  };
  const handleCatEdit = (record) => { setEditingCategory(record); catForm.setFieldsValue(record); setIsModalVisible(true); };
  const handleCatDelete = async (id) => {
    try { await axios.delete(`${BACKEND_URL}/api/categories/${id}`); alertSuccess('ลบสำเร็จ', 'ลบหมวดหมู่แล้ว'); fetchData(); } 
    catch (error) { alertError('ลบไม่สำเร็จ', 'เกิดข้อผิดพลาด'); }
  };
  const handleCatSubmit = async (values) => {
    try {
      if (editingCategory) await axios.put(`${BACKEND_URL}/api/categories/${editingCategory.category_id}`, values);
      else await axios.post(`${BACKEND_URL}/api/categories`, values);
      setIsModalVisible(false); fetchData(); alertSuccess('สำเร็จ', 'บันทึกหมวดหมู่เรียบร้อย');
    } catch (error) { alertError('บันทึกไม่สำเร็จ', 'เกิดข้อผิดพลาด'); }
  };

  const getCatColumns = (headerName) => [
    { title: 'ลำดับ', key: 'index', width: 80, align: 'center', render: (text, record, index) => index + 1 },
    { title: headerName || 'ชื่อหมวดหมู่', dataIndex: 'category_name', key: 'category_name', render: text => <Text strong>{text}</Text> },
    { title: 'จัดการ', key: 'action', align: 'right', width: 150, render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleCatEdit(record)}>แก้ไข</Button>
          <Popconfirm title="ยืนยันการลบหมวดหมู่นี้?" onConfirm={() => handleCatDelete(record.category_id)} okText="ลบ" cancelText="ยกเลิก"><Button type="primary" danger size="small" icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    },
  ];

  const getTabIcon = (typeCode) => {
    const code = String(typeCode).toLowerCase();
    if (code.includes('hard')) return <DesktopOutlined />;
    if (code.includes('soft')) return <AppstoreOutlined />;
    if (code.includes('app')) return <GlobalOutlined />;
    if (code.includes('serv')) return <ApiOutlined />;
    return <TagsOutlined />;
  };

  const renderProjectCards = () => {
    const allProjectsList = [...projects];

    // ✅ ใช้โทนสีพาสเทลแบบเดิม ตัวหนังสือเข้มตามในรูปตัวอย่าง
    const cardThemes = [
      { bg: 'linear-gradient(135deg, #ffe4e6 0%, #fecdd3 100%)', color: '#e11d48', tagBg: '#fda4af', border: '#fecdd3' }, // Pink
      { bg: 'linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%)', color: '#9333ea', tagBg: '#d8b4fe', border: '#e9d5ff' }, // Purple
      { bg: 'linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%)', color: '#16a34a', tagBg: '#86efac', border: '#bbf7d0' }, // Green
      { bg: 'linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%)', color: '#0284c7', tagBg: '#7dd3fc', border: '#bae6fd' }, // Blue
      { bg: 'linear-gradient(135deg, #ffedd5 0%, #fed7aa 100%)', color: '#ea580c', tagBg: '#fdba74', border: '#fed7aa' }, // Orange
    ];

    return (
      <Row gutter={[24, 24]} align="stretch">
        {allProjectsList.map((proj, index) => {
          const count = categories.filter(c => c.project_id === proj.project_id).length;
          const theme = cardThemes[index % cardThemes.length];
          
          return (
            <Col xs={24} sm={12} md={8} lg={6} key={proj.project_id}>
              <div 
                onClick={() => setSelectedProject(proj)}
                style={{
                  background: theme.bg,
                  borderRadius: '24px', 
                  padding: '24px',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  boxShadow: '0 8px 30px rgba(0,0,0,0.06)', 
                  transition: 'all 0.3s ease',
                  height: '100%',
                  border: `2px solid ${theme.border}` 
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-6px)';
                  e.currentTarget.style.boxShadow = '0 15px 35px rgba(0,0,0,0.12)'; 
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0px)';
                  e.currentTarget.style.boxShadow = '0 8px 30px rgba(0,0,0,0.06)';
                }}
              >
                <div>
                  <div style={{ color: theme.color, fontSize: '15px', fontWeight: '900', marginBottom: '8px' }}>
                    {proj.project_name}
                  </div>
                  {/* ✅ เปลี่ยนสีตัวเลขกลับเป็นสีเข้ม (#1e293b) */}
                  <div style={{ fontSize: '42px', fontWeight: '900', color: '#1e293b', lineHeight: '1' }}>
                    {count}
                  </div>
                  <div style={{ marginTop: '12px' }}>
                    {/* ✅ เปลี่ยนสีพื้นหลัง Tag กลับเป็นสีทึบพาสเทล สีอักษรสีขาว */}
                    <span style={{ background: theme.tagBg, color: '#ffffff', padding: '4px 12px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold' }}>
                      รายการ
                    </span>
                  </div>
                </div>

                <div style={{
                  width: '60px', height: '60px', borderRadius: '16px', 
                  backgroundColor: 'rgba(255, 255, 255, 0.7)', backdropFilter: 'blur(4px)',
                  display: 'flex', justifyContent: 'center', alignItems: 'center',
                  boxShadow: '0 4px 10px rgba(0,0,0,0.02)'
                }}>
                  {/* ✅ เปลี่ยนสีไอคอนให้เข้ากับ Theme */}
                  <ApartmentOutlined style={{ fontSize: '30px', color: theme.color }} />
                </div>
              </div>
            </Col>
          );
        })}
      </Row>
    );
  };

  const renderCategoryTabs = () => {
    const projectCategories = categories.filter(c => c.project_id === selectedProject.project_id);
    
    const tabItems = categoryTypes.map((type, index) => {
      const catsOfType = projectCategories.filter(c => c.category_type === type.type_code);
      return {
        key: String(index + 1),
        label: (
          <span>
            {getTabIcon(type.type_code)} {type.type_code}
            <Tag style={{ color: catsOfType.length > 0 ? '#ffffff' : '#64748b', backgroundColor: catsOfType.length > 0 ? '#3b82f6' : '#e2e8f0', borderRadius: '12px', marginLeft: 8, border: 'none', fontWeight: 'bold' }}>
              {catsOfType.length}
            </Tag>
          </span>
        ),
        children: (
          <div style={{ padding: '10px 0' }}>
            <Table columns={getCatColumns(type.type_name)} dataSource={catsOfType} rowKey="category_id" pagination={{ pageSize: 10 }} size="middle" scroll={{ x: 'max-content' }}/>
          </div>
        )
      };
    });

    const uncategorized = projectCategories.filter(c => !categoryTypes.find(t => t.type_code === c.category_type));
    if (uncategorized.length > 0) {
      tabItems.push({
        key: 'other',
        label: <span><TagsOutlined /> Other <Tag style={{ borderRadius: '12px', marginLeft: 8 }}>{uncategorized.length}</Tag></span>,
        children: <Table columns={getCatColumns('ชื่อหมวดหมู่')} dataSource={uncategorized} rowKey="category_id" pagination={{ pageSize: 10 }} size="middle" />
      });
    }

    return (
      <Card variant="borderless" style={{ borderRadius: 16, border: '1px solid #e2e8f0', boxShadow: '0 4px 20px rgba(0,0,0,0.03)' }}>
        <Tabs className="modern-tabs" type="card" defaultActiveKey="1" items={tabItems} size="large" />
      </Card>
    );
  };

  return (
    <div style={{ padding: '24px', backgroundColor: '#f8fafc', minHeight: '100vh' }}>
      
      <style>{`
        .modern-tabs .ant-tabs-tab { 
          padding: 12px 24px; font-size: 15px; border-radius: 12px 12px 0 0 !important; 
          transition: all 0.3s; border: 1px solid #e2e8f0 !important;
          border-bottom: none !important; background-color: #f1f5f9 !important;
        }
        .modern-tabs .ant-tabs-tab-active { background-color: #0ea5e9 !important; border-color: #0ea5e9 !important; }
        .modern-tabs .ant-tabs-tab-active .ant-tabs-tab-btn,
        .modern-tabs .ant-tabs-tab-active .ant-tabs-tab-btn span { color: #ffffff !important; }
        .modern-tabs .ant-tabs-tab:hover:not(.ant-tabs-tab-active) { color: #0ea5e9; background-color: #e0f2fe !important; }
      `}</style>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 30 }}>
        <div>
          {selectedProject ? (
            <Space align="center" size="middle">
              <Button icon={<ArrowLeftOutlined />} onClick={() => setSelectedProject(null)} style={{ borderRadius: '10px', height: '40px' }}>ย้อนกลับ</Button>
              <Title level={3} style={{ color: '#1e293b', margin: 0 }}>
                <DatabaseOutlined style={{ color: '#0ea5e9', marginRight: '8px' }}/> หมวดหมู่: {selectedProject.project_name}
              </Title>
            </Space>
          ) : (
            <Title level={3} style={{ color: '#1e293b', margin: 0 }}>
              <AppstoreOutlined style={{ color: '#0ea5e9', marginRight: '10px' }}/> จัดการหมวดหมู่ / ระบบงาน
            </Title>
          )}
        </div>
        
        <Space>
          {/* ✅ ปรับลอจิกการแสดงปุ่มใหม่: เมื่อไม่ได้เลือกโปรเจกต์ (หน้าแรก) ให้แสดงแค่จัดการโครงการ */}
          {!selectedProject ? (
            <Button type="default" icon={<SettingOutlined />} size="large" style={{ borderRadius: '10px' }} onClick={handleProjectManage}>
              จัดการโครงการ
            </Button>
          ) : (
            /* ✅ เมื่อกดเข้าโปรเจกต์มาแล้ว ให้แสดงปุ่ม 2 อันนี้ */
            <>
              <Button type="dashed" icon={<ProfileOutlined />} size="large" style={{ borderRadius: '10px' }} onClick={handleTypeManage}>
                จัดการประเภท (Type)
              </Button>
              <Button type="primary" icon={<PlusOutlined />} size="large" style={{ backgroundColor: '#10b981', borderColor: '#10b981', borderRadius: '10px', boxShadow: '0 4px 10px rgba(16, 185, 129, 0.3)' }} onClick={handleCatAdd}>
                เพิ่มหมวดหมู่ใหม่
              </Button>
            </>
          )}
        </Space>
      </div>

      {selectedProject ? renderCategoryTabs() : renderProjectCards()}

      {/* ======================= Modals ======================= */}

      {/* Modal: หมวดหมู่ (Category) */}
      <Modal title={editingCategory ? "✏️ แก้ไขหมวดหมู่" : "➕ เพิ่มหมวดหมู่ใหม่"} open={isModalVisible} onCancel={() => setIsModalVisible(false)} footer={null} destroyOnHidden forceRender>
        <Form form={catForm} layout="vertical" onFinish={handleCatSubmit}>
          <Form.Item name="category_name" label={<Text strong>ชื่อหมวดหมู่ <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณากรอกชื่อหมวดหมู่' }]}>
            <Input placeholder="เช่น เครื่องแม่ข่ายสำหรับระบบงานฐานข้อมูล" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          
          <Form.Item name="category_type" label={<Text strong>ประเภท (Type) - ดึงจากฐานข้อมูลอัตโนมัติ</Text>}>
            <Select placeholder="เลือกประเภท (ถ้ามี)" size="large" allowClear showSearch getPopupContainer={(trigger) => trigger.parentNode}>
              {categoryTypes.map(type => (
                <Option key={type.type_code} value={type.type_code}>{type.type_code}</Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item name="project_id" label={<Text strong>ผูกกับโครงการ <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณาเลือกโครงการ' }]}>
            <Select placeholder="เลือกโปรเจกต์" size="large" allowClear getPopupContainer={(trigger) => trigger.parentNode}>
              {projects.map(p => ( <Option key={p.project_id} value={p.project_id}>{p.project_name}</Option> ))}
            </Select>
          </Form.Item>

          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: 10, borderRadius: '8px' }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#1890ff', borderRadius: '8px' }}>บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>

      {/* Modal: จัดการประเภท (Type) */}
      <Modal title={<><ProfileOutlined /> จัดการประเภทและหัวตาราง</>} open={isTypeManageModalVisible} onCancel={() => setIsTypeManageModalVisible(false)} footer={null} width={800} destroyOnHidden>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 15 }}>
          <Button type="primary" icon={<PlusOutlined />} style={{ backgroundColor: '#8b5cf6', borderRadius: '8px' }} onClick={handleTypeAdd}>
            เพิ่มประเภท (Type)
          </Button>
        </div>
        <Table columns={typeColumns} dataSource={categoryTypes} rowKey="type_id" pagination={{ pageSize: 10 }} />
      </Modal>

      {/* Modal: เพิ่ม/แก้ไขประเภท (Type) */}
      <Modal title={editingType ? "✏️ แก้ไขประเภทและหัวตาราง" : "➕ เพิ่มประเภทใหม่"} open={isTypeModalVisible} onCancel={() => setIsTypeModalVisible(false)} footer={null} destroyOnHidden forceRender zIndex={1050}>
        <Form form={typeForm} layout="vertical" onFinish={handleTypeSubmit}>
          <Form.Item name="type_code" label={<Text strong>รหัสประเภท (ภาษาอังกฤษ) <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณากรอกรหัสประเภท' }]}>
            <Input placeholder="เช่น Hardware, Software, Network" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item name="type_name" label={<Text strong>ชื่อที่แสดงบนหัวตาราง <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณากรอกชื่อหัวตาราง' }]}>
            <Input placeholder="เช่น คอมพิวเตอร์แม่ข่ายและอุปกรณ์ (Hardware)" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsTypeModalVisible(false)} style={{ marginRight: 10, borderRadius: '8px' }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#8b5cf6', borderRadius: '8px' }}>บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>

      {/* Modal: รายชื่อโครงการ */}
      <Modal title={<><SettingOutlined /> จัดการรายชื่อโครงการ</>} open={isProjManageModalVisible} onCancel={() => setIsProjManageModalVisible(false)} footer={null} width={1000} destroyOnHidden>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 15 }}>
          <Button type="primary" icon={<PlusOutlined />} style={{ backgroundColor: '#10b981', borderRadius: '8px' }} onClick={handleProjectAdd}>
            เพิ่มโครงการใหม่
          </Button>
        </div>
        <Table columns={projManageColumns} dataSource={projects} rowKey="project_id" pagination={{ pageSize: 10 }} />
      </Modal>

      {/* Modal: เพิ่ม/แก้ไขโครงการ */}
      <Modal title={editingProject ? "✏️ แก้ไขข้อมูลโครงการ" : "➕ เพิ่มโครงการใหม่"} open={isProjModalVisible} onCancel={() => setIsProjModalVisible(false)} footer={null} destroyOnHidden forceRender zIndex={1050}>
        <Form form={projForm} layout="vertical" onFinish={handleProjectSubmit}>
          <Form.Item name="project_name" label="ชื่อโครงการ" rules={[{ required: true, message: 'กรุณากรอกชื่อโครงการ' }]}>
            <Input placeholder="เช่น LIMS ศูนย์เทคโนโลยีสารสนเทศ" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item name="description" label="รายละเอียดโครงการ">
            <Input.TextArea placeholder="เช่น ระบบหลัก, ระบบย่อย..." rows={3} style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item 
            name="project_contract" label="เลขที่สัญญา" normalize={(value) => (value || '').replace(/[^0-9/]/g, '')}
            rules={[{ pattern: /^[0-9]+\/[0-9]{4}$/, message: 'รูปแบบผิด! ต้องเป็น "ตัวเลข/พ.ศ. 4 หลัก" (เช่น 9/2566)' }]}
          >
            <Input placeholder="เช่น 9/2566" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsProjModalVisible(false)} style={{ marginRight: 10, borderRadius: '8px' }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#1890ff', borderRadius: '8px' }}>บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>

    </div>
  );
}