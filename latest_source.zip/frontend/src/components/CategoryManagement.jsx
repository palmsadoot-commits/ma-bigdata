import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Space, Typography, Tag, Modal, Form, Input, Select, Popconfirm, Row, Col, Tabs, InputNumber, Switch, message } from 'antd';
import { 
  AppstoreOutlined, PlusOutlined, EditOutlined, DeleteOutlined, 
  ArrowLeftOutlined, GlobalOutlined, ApartmentOutlined, SettingOutlined,
  DesktopOutlined, ApiOutlined, DatabaseOutlined, TagsOutlined, ProfileOutlined
} from '@ant-design/icons';
import axios from 'axios';
import { alertSuccess, alertError } from '../utils/alert';

const { Title, Text } = Typography;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000';

export default function CategoryManagement() {
  const [categories, setCategories] = useState([]);
  const [projects, setProjects] = useState([]);
  const [categoryTypes, setCategoryTypes] = useState([]);
  const [loading, setLoading] = useState(false);
  
  // States สำหรับ Category
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null); 
  const [catForm] = Form.useForm();

  // States สำหรับ Project
  const [isProjModalVisible, setIsProjModalVisible] = useState(false);
  const [editingProject, setEditingProject] = useState(null); 
  const [projForm] = Form.useForm();
  const [isProjManageModalVisible, setIsProjManageModalVisible] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);

  // States สำหรับจัดการประเภท (Type)
  const [isTypeManageModalVisible, setIsTypeManageModalVisible] = useState(false);
  const [isTypeModalVisible, setIsTypeModalVisible] = useState(false);
  const [editingType, setEditingType] = useState(null);
  const [typeForm] = Form.useForm();

  // 🌟 States สำหรับจัดการอุปกรณ์ (Equipments)
  const [equipments, setEquipments] = useState([]);
  const [isEqListModalVisible, setIsEqListModalVisible] = useState(false);
  const [isEqFormModalVisible, setIsEqFormModalVisible] = useState(false);
  const [selectedCategoryForEq, setSelectedCategoryForEq] = useState(null);
  const [editingEq, setEditingEq] = useState(null);
  const [eqForm] = Form.useForm();

  const fetchData = async () => {
    setLoading(true);
    try {
      const [catRes, projRes, typeRes, eqRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/categories`),
        axios.get(`${BACKEND_URL}/api/projects`),
        axios.get(`${BACKEND_URL}/api/category-types`),
        axios.get(`${BACKEND_URL}/api/equipments`).catch(() => ({ data: [] }))
      ]);
      
      // ✅ ล็อคการเรียงลำดับให้เป๊ะ 100% ด้วย Number() เพื่อป้องกันบั๊กการเรียงตัวเลข
      const sortedCats = catRes.data.sort((a, b) => Number(a.category_id) - Number(b.category_id));
      const sortedProjs = projRes.data.sort((a, b) => Number(a.project_id) - Number(b.project_id));
      const sortedTypes = (typeRes.data || []).sort((a, b) => Number(a.type_id) - Number(b.type_id));
      const sortedEqs = (eqRes.data || []).sort((a, b) => Number(a.equipment_id) - Number(b.equipment_id));
      
      setCategories(sortedCats);
      setProjects(sortedProjs);
      setCategoryTypes(sortedTypes);
      setEquipments(sortedEqs); 
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูลได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  // ==========================================
  // 🗂️ จัดการประเภทและหัวตาราง (Types)
  // ==========================================
  const handleTypeManage = () => setIsTypeManageModalVisible(true);

  const handleTypeAdd = () => {
    setEditingType(null);
    typeForm.resetFields();
    setIsTypeModalVisible(true);
  };

  const handleTypeEdit = (record) => {
    setEditingType(record);
    typeForm.setFieldsValue(record);
    setIsTypeModalVisible(true);
  };

  const handleTypeDelete = async (id) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/category-types/${id}`);
      alertSuccess('ลบสำเร็จ', 'ประเภทถูกลบออกแล้ว');
      fetchData(); 
    } catch (error) {
      alertError('ลบไม่สำเร็จ', 'ไม่สามารถลบได้');
    }
  };

  const handleTypeSubmit = async (values) => {
    try {
      if (editingType) {
        await axios.put(`${BACKEND_URL}/api/category-types/${editingType.type_id}`, values);
        alertSuccess('อัปเดตสำเร็จ', 'แก้ไขประเภทเรียบร้อย');
      } else {
        await axios.post(`${BACKEND_URL}/api/category-types`, values);
        alertSuccess('เพิ่มสำเร็จ', 'เพิ่มประเภทใหม่เรียบร้อย');
      }
      setIsTypeModalVisible(false);
      fetchData(); 
    } catch (error) {
      alertError('บันทึกไม่สำเร็จ', 'รหัส Type อาจซ้ำกัน');
    }
  };

  const typeColumns = [
    { title: 'ชื่อประเภท (อังกฤษ/รหัส)', dataIndex: 'type_code', key: 'type_code' },
    { title: 'ชื่อที่แสดงบนหัวตาราง', dataIndex: 'type_name', key: 'type_name' },
    {
      title: 'จัดการ', key: 'action', align: 'right', width: 120,
      render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleTypeEdit(record)} />
          <Popconfirm title="ยืนยันการลบ?" onConfirm={() => handleTypeDelete(record.type_id)} okText="ลบ" cancelText="ยกเลิก">
            <Button type="primary" danger size="small" icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  // ==========================================
  // จัดการโครงการ (Projects) 
  // ==========================================
  const handleProjectManage = () => setIsProjManageModalVisible(true);
  const handleProjectAdd = () => { setEditingProject(null); projForm.resetFields(); setIsProjModalVisible(true); };
  const handleProjectEdit = (record) => { setEditingProject(record); projForm.setFieldsValue(record); setIsProjModalVisible(true); };
  const handleProjectDelete = async (id) => {
    try { await axios.delete(`${BACKEND_URL}/api/projects/${id}`); alertSuccess('ลบสำเร็จ', 'ลบโครงการแล้ว'); fetchData(); } 
    catch (error) { alertError('ลบไม่สำเร็จ', error.response?.data?.error || 'เกิดข้อผิดพลาด'); }
  };
  const handleProjectSubmit = async (values) => {
    try {
      if (editingProject) await axios.put(`${BACKEND_URL}/api/projects/${editingProject.project_id}`, values);
      else await axios.post(`${BACKEND_URL}/api/projects`, values);
      setIsProjModalVisible(false); fetchData(); alertSuccess('สำเร็จ', 'บันทึกข้อมูลเรียบร้อย');
    } catch (error) { alertError('บันทึกไม่สำเร็จ', 'เกิดข้อผิดพลาด'); }
  };

  const projManageColumns = [
    { title: 'รหัสโครงการ', dataIndex: 'project_id', key: 'project_id', align: 'center', width: 100 },
    { title: 'ชื่อโครงการ', dataIndex: 'project_name', key: 'project_name' },
    { title: 'รายละเอียด', dataIndex: 'description', key: 'description', render: (text) => text || '-' },
    { title: 'เลขที่สัญญา', dataIndex: 'project_contract', key: 'project_contract', render: (text) => text || '-' },
    { title: 'จัดการ', key: 'action', align: 'right', width: 120, render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleProjectEdit(record)} />
          <Popconfirm title="ยืนยันการลบ?" onConfirm={() => handleProjectDelete(record.project_id)} okText="ลบ" cancelText="ยกเลิก"><Button type="primary" danger size="small" icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    },
  ];

  // ==========================================
  // จัดการหมวดหมู่ (Categories)
  // ==========================================
  const handleCatAdd = () => {
    setEditingCategory(null); 
    catForm.resetFields();
    catForm.setFieldsValue({ 
      project_id: selectedProject ? selectedProject.project_id : undefined,
      weighting_factor: 1.0 
    });
    setIsModalVisible(true);
  };
  
  const handleCatEdit = (record) => { 
    setEditingCategory(record); 
    catForm.setFieldsValue(record); 
    setIsModalVisible(true); 
  };
  
  const handleCatDelete = async (id) => {
    try { await axios.delete(`${BACKEND_URL}/api/categories/${id}`); alertSuccess('ลบสำเร็จ', 'ลบหมวดหมู่แล้ว'); fetchData(); } 
    catch (error) { alertError('ลบไม่สำเร็จ', 'เกิดข้อผิดพลาด'); }
  };
  
  const handleCatSubmit = async (values) => {
    try {
      if (editingCategory) await axios.put(`${BACKEND_URL}/api/categories/${editingCategory.category_id}`, values);
      else await axios.post(`${BACKEND_URL}/api/categories`, values);
      setIsModalVisible(false); fetchData(); alertSuccess('สำเร็จ', 'บันทึกหมวดหมู่เรียบร้อย');
    } catch (error) { alertError('บันทึกไม่สำเร็จ', 'เกิดข้อผิดพลาด'); }
  };

  // ==========================================
  // 🌟 จัดการอุปกรณ์ (Equipments)
  // ==========================================
  const handleEqSubmit = async (values) => {
    try {
      if (editingEq) {
        await axios.put(`${BACKEND_URL}/api/equipments/${editingEq.equipment_id}`, values);
        message.success('อัปเดตข้อมูลสำเร็จ');
      } else {
        await axios.post(`${BACKEND_URL}/api/equipments`, values);
        message.success('เพิ่มอุปกรณ์สำเร็จ');
      }
      setIsEqFormModalVisible(false); 
      fetchData(); 
    } catch(e) { alertError('เกิดข้อผิดพลาดในการบันทึกข้อมูลอุปกรณ์'); }
  };

  const handleEqDelete = async (id) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/equipments/${id}`);
      message.success('ลบอุปกรณ์สำเร็จ');
      fetchData();
    } catch(e) { alertError('ไม่สามารถลบอุปกรณ์ได้'); }
  }

  const handleEqStatusChange = async (equipmentId, checked) => {
    const newStatus = checked ? 'Active' : 'Inactive';
    try {
      await axios.put(`${BACKEND_URL}/api/equipments/${equipmentId}/status`, { status: newStatus });
      message.success(`เปลี่ยนสถานะเป็น ${newStatus} สำเร็จ`);
      fetchData(); 
    } catch (error) {
      alertError('เกิดข้อผิดพลาด', 'ไม่สามารถอัปเดตสถานะอุปกรณ์ได้');
    }
  };

  const getCatColumns = (headerName) => [
    { title: 'ลำดับ', key: 'index', width: 60, align: 'center', render: (text, record, index) => index + 1 },
    { title: headerName || 'ชื่อหมวดหมู่ / ระบบ', dataIndex: 'category_name', key: 'category_name', render: text => <Text strong>{text}</Text> },
    { 
      title: 'ค่าตัวถ่วง', 
      dataIndex: 'weighting_factor', 
      align: 'center', 
      width: 100, 
      render: (val) => <Tag color="orange" style={{ borderRadius: '8px' }}>{val}</Tag> 
    },
    { 
      title: 'อุปกรณ์ย่อย', 
      key: 'equipment_manage', 
      align: 'center', 
      width: 130, 
      render: (_, record) => {
        const eqCount = equipments.filter(e => e.category_id === record.category_id).length;
        return (
          <Button 
            type="dashed" 
            size="small" 
            style={{ borderRadius: '8px' }}
            onClick={() => { 
              setSelectedCategoryForEq(record); 
              setIsEqListModalVisible(true); 
            }}
          >
            <DesktopOutlined /> จัดการ <Tag color={eqCount > 0 ? 'blue' : 'default'} style={{ marginLeft: 5, borderRadius: '10px' }}>{eqCount}</Tag>
          </Button>
        );
      } 
    },
    { title: 'แก้ไข/ลบ', key: 'action', align: 'right', width: 120, render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleCatEdit(record)} />
          <Popconfirm title="ยืนยันการลบหมวดหมู่นี้?" onConfirm={() => handleCatDelete(record.category_id)} okText="ลบ" cancelText="ยกเลิก"><Button type="primary" danger size="small" icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    },
  ];

  const getTabIcon = (typeCode) => {
    const code = String(typeCode).toLowerCase();
    if (code.includes('hard')) return <DesktopOutlined />;
    if (code.includes('soft')) return <AppstoreOutlined />;
    if (code.includes('app')) return <GlobalOutlined />;
    if (code.includes('serv')) return <ApiOutlined />;
    return <TagsOutlined />;
  };

  const renderProjectCards = () => {
    const allProjectsList = [...projects];
    const cardThemes = [
      { bg: 'linear-gradient(135deg, #ffe4e6 0%, #fecdd3 100%)', color: '#e11d48', tagBg: '#fda4af', border: '#fecdd3' }, 
      { bg: 'linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%)', color: '#9333ea', tagBg: '#d8b4fe', border: '#e9d5ff' }, 
      { bg: 'linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%)', color: '#16a34a', tagBg: '#86efac', border: '#bbf7d0' }, 
      { bg: 'linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%)', color: '#0284c7', tagBg: '#7dd3fc', border: '#bae6fd' }, 
      { bg: 'linear-gradient(135deg, #ffedd5 0%, #fed7aa 100%)', color: '#ea580c', tagBg: '#fdba74', border: '#fed7aa' }, 
    ];

    return (
      <Row gutter={[24, 24]} align="stretch">
        {allProjectsList.map((proj, index) => {
          const count = categories.filter(c => c.project_id === proj.project_id).length;
          const theme = cardThemes[index % cardThemes.length];
          
          return (
            <Col xs={24} sm={12} md={8} lg={6} key={proj.project_id}>
              <div 
                onClick={() => setSelectedProject(proj)}
                style={{
                  background: theme.bg,
                  borderRadius: '24px', 
                  padding: '24px',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  boxShadow: '0 8px 30px rgba(0,0,0,0.06)', 
                  transition: 'all 0.3s ease',
                  height: '100%',
                  border: `2px solid ${theme.border}` 
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-6px)';
                  e.currentTarget.style.boxShadow = '0 15px 35px rgba(0,0,0,0.12)'; 
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0px)';
                  e.currentTarget.style.boxShadow = '0 8px 30px rgba(0,0,0,0.06)';
                }}
              >
                <div>
                  <div style={{ color: theme.color, fontSize: '15px', fontWeight: '900', marginBottom: '8px' }}>
                    {proj.project_name}
                  </div>
                  <div style={{ fontSize: '42px', fontWeight: '900', color: '#1e293b', lineHeight: '1' }}>
                    {count}
                  </div>
                  <div style={{ marginTop: '12px' }}>
                    <span style={{ background: theme.tagBg, color: '#ffffff', padding: '4px 12px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold' }}>
                      รายการ
                    </span>
                  </div>
                </div>

                <div style={{
                  width: '60px', height: '60px', borderRadius: '16px', 
                  backgroundColor: 'rgba(255, 255, 255, 0.7)', backdropFilter: 'blur(4px)',
                  display: 'flex', justifyContent: 'center', alignItems: 'center',
                  boxShadow: '0 4px 10px rgba(0,0,0,0.02)'
                }}>
                  <ApartmentOutlined style={{ fontSize: '30px', color: theme.color }} />
                </div>
              </div>
            </Col>
          );
        })}
      </Row>
    );
  };

  const renderCategoryTabs = () => {
    const projectCategories = categories.filter(c => c.project_id === selectedProject.project_id);
    
    const tabItems = categoryTypes.map((type, index) => {
      const catsOfType = projectCategories.filter(c => c.category_type === type.type_code);
      return {
        key: String(index + 1),
        label: (
          <span>
            {getTabIcon(type.type_code)} {type.type_code}
            <Tag style={{ color: catsOfType.length > 0 ? '#ffffff' : '#64748b', backgroundColor: catsOfType.length > 0 ? '#3b82f6' : '#e2e8f0', borderRadius: '12px', marginLeft: 8, border: 'none', fontWeight: 'bold' }}>
              {catsOfType.length}
            </Tag>
          </span>
        ),
        children: (
          <div style={{ padding: '10px 0' }}>
            <Table columns={getCatColumns(type.type_name)} dataSource={catsOfType} rowKey="category_id" pagination={{ pageSize: 15 }} size="middle" scroll={{ x: 'max-content' }}/>
          </div>
        )
      };
    });

    const uncategorized = projectCategories.filter(c => !categoryTypes.find(t => t.type_code === c.category_type));
    if (uncategorized.length > 0) {
      tabItems.push({
        key: 'other',
        label: <span><TagsOutlined /> Other <Tag style={{ borderRadius: '12px', marginLeft: 8 }}>{uncategorized.length}</Tag></span>,
        children: <Table columns={getCatColumns('ชื่อหมวดหมู่')} dataSource={uncategorized} rowKey="category_id" pagination={{ pageSize: 15 }} size="middle" />
      });
    }

    return (
      <Card variant="borderless" style={{ borderRadius: 16, border: '1px solid #e2e8f0', boxShadow: '0 4px 20px rgba(0,0,0,0.03)' }}>
        <Tabs className="modern-tabs" type="card" defaultActiveKey="1" items={tabItems} size="large" />
      </Card>
    );
  };

  return (
    <div style={{ padding: '24px', backgroundColor: '#f8fafc', minHeight: '100vh' }}>
      
      <style>{`
        .modern-tabs .ant-tabs-tab { 
          padding: 12px 24px; font-size: 15px; border-radius: 12px 12px 0 0 !important; 
          transition: all 0.3s; border: 1px solid #e2e8f0 !important;
          border-bottom: none !important; background-color: #f1f5f9 !important;
        }
        .modern-tabs .ant-tabs-tab-active { background-color: #0ea5e9 !important; border-color: #0ea5e9 !important; }
        .modern-tabs .ant-tabs-tab-active .ant-tabs-tab-btn,
        .modern-tabs .ant-tabs-tab-active .ant-tabs-tab-btn span { color: #ffffff !important; }
        .modern-tabs .ant-tabs-tab:hover:not(.ant-tabs-tab-active) { color: #0ea5e9; background-color: #e0f2fe !important; }
      `}</style>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 30 }}>
        <div>
          {selectedProject ? (
            <Space align="center" size="middle">
              <Button icon={<ArrowLeftOutlined />} onClick={() => setSelectedProject(null)} style={{ borderRadius: '10px', height: '40px' }}>ย้อนกลับ</Button>
              <Title level={3} style={{ color: '#1e293b', margin: 0 }}>
                <DatabaseOutlined style={{ color: '#0ea5e9', marginRight: '8px' }}/> หมวดหมู่: {selectedProject.project_name}
              </Title>
            </Space>
          ) : (
            <Title level={3} style={{ color: '#1e293b', margin: 0 }}>
              <AppstoreOutlined style={{ color: '#0ea5e9', marginRight: '10px' }}/> จัดการหมวดหมู่ / ระบบงาน
            </Title>
          )}
        </div>
        
        <Space>
          {!selectedProject ? (
            <Button type="default" icon={<SettingOutlined />} size="large" style={{ borderRadius: '10px' }} onClick={handleProjectManage}>
              จัดการโครงการ
            </Button>
          ) : (
            <>
              <Button type="dashed" icon={<ProfileOutlined />} size="large" style={{ borderRadius: '10px' }} onClick={handleTypeManage}>
                จัดการประเภท (Type)
              </Button>
              <Button type="primary" icon={<PlusOutlined />} size="large" style={{ backgroundColor: '#10b981', borderColor: '#10b981', borderRadius: '10px', boxShadow: '0 4px 10px rgba(16, 185, 129, 0.3)' }} onClick={handleCatAdd}>
                เพิ่มหมวดหมู่ใหม่
              </Button>
            </>
          )}
        </Space>
      </div>

      {selectedProject ? renderCategoryTabs() : renderProjectCards()}

      {/* ======================= Modals ======================= */}

      {/* Modal: หมวดหมู่ (Category) */}
      <Modal title={editingCategory ? "✏️ แก้ไขหมวดหมู่" : "➕ เพิ่มหมวดหมู่ใหม่"} open={isModalVisible} onCancel={() => setIsModalVisible(false)} footer={null} destroyOnHidden forceRender>
        <Form form={catForm} layout="vertical" onFinish={handleCatSubmit}>
          <Form.Item name="category_name" label={<Text strong>ชื่อหมวดหมู่ <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณากรอกชื่อหมวดหมู่' }]}>
            <Input placeholder="เช่น เครื่องแม่ข่ายสำหรับระบบงานฐานข้อมูล" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          
          <Form.Item name="category_type" label={<Text strong>ประเภท (Type)</Text>}>
            <Select placeholder="เลือกประเภท (ถ้ามี)" size="large" allowClear showSearch getPopupContainer={(trigger) => trigger.parentNode}>
              {categoryTypes.map(type => (
                <Option key={type.type_code} value={type.type_code}>{type.type_code}</Option>
              ))}
            </Select>
          </Form.Item>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="project_id" label={<Text strong>ผูกกับโครงการ <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณาเลือกโครงการ' }]}>
                <Select placeholder="เลือกโปรเจกต์" size="large" allowClear getPopupContainer={(trigger) => trigger.parentNode}>
                  {projects.map(p => ( <Option key={p.project_id} value={p.project_id}>{p.project_name}</Option> ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="weighting_factor" label={<Text strong>ค่าตัวถ่วงนำหนัก (Weight) <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณาระบุค่าตัวถ่วง' }]}>
                <InputNumber min={0.01} step={0.1} size="large" style={{ width: '100%', borderRadius: '8px' }} placeholder="เช่น 1.0 หรือ 0.5" />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item style={{ textAlign: 'right', marginTop: 15, marginBottom: 0 }}>
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: 10, borderRadius: '8px' }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#1890ff', borderRadius: '8px' }}>บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>

      {/* Modal: จัดการประเภท (Type) */}
      <Modal title={<><ProfileOutlined /> จัดการประเภทและหัวตาราง</>} open={isTypeManageModalVisible} onCancel={() => setIsTypeManageModalVisible(false)} footer={null} width={800} destroyOnHidden>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 15 }}>
          <Button type="primary" icon={<PlusOutlined />} style={{ backgroundColor: '#8b5cf6', borderRadius: '8px' }} onClick={handleTypeAdd}>
            เพิ่มประเภท (Type)
          </Button>
        </div>
        <Table columns={typeColumns} dataSource={categoryTypes} rowKey="type_id" pagination={{ pageSize: 10 }} />
      </Modal>

      {/* Modal: เพิ่ม/แก้ไขประเภท (Type) */}
      <Modal title={editingType ? "✏️ แก้ไขประเภทและหัวตาราง" : "➕ เพิ่มประเภทใหม่"} open={isTypeModalVisible} onCancel={() => setIsTypeModalVisible(false)} footer={null} destroyOnHidden forceRender zIndex={1050}>
        <Form form={typeForm} layout="vertical" onFinish={handleTypeSubmit}>
          <Form.Item name="type_code" label={<Text strong>รหัสประเภท (ภาษาอังกฤษ) <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณากรอกรหัสประเภท' }]}>
            <Input placeholder="เช่น Hardware, Software, Network" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item name="type_name" label={<Text strong>ชื่อที่แสดงบนหัวตาราง <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณากรอกชื่อหัวตาราง' }]}>
            <Input placeholder="เช่น คอมพิวเตอร์แม่ข่ายและอุปกรณ์ (Hardware)" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsTypeModalVisible(false)} style={{ marginRight: 10, borderRadius: '8px' }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#8b5cf6', borderRadius: '8px' }}>บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>

      {/* Modal: รายชื่อโครงการ */}
      <Modal title={<><SettingOutlined /> จัดการรายชื่อโครงการ</>} open={isProjManageModalVisible} onCancel={() => setIsProjManageModalVisible(false)} footer={null} width={1000} destroyOnHidden>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 15 }}>
          <Button type="primary" icon={<PlusOutlined />} style={{ backgroundColor: '#10b981', borderRadius: '8px' }} onClick={handleProjectAdd}>
            เพิ่มโครงการใหม่
          </Button>
        </div>
        <Table columns={projManageColumns} dataSource={projects} rowKey="project_id" pagination={{ pageSize: 10 }} />
      </Modal>

      {/* Modal: เพิ่ม/แก้ไขโครงการ */}
      <Modal title={editingProject ? "✏️ แก้ไขข้อมูลโครงการ" : "➕ เพิ่มโครงการใหม่"} open={isProjModalVisible} onCancel={() => setIsProjModalVisible(false)} footer={null} destroyOnHidden forceRender zIndex={1050}>
        <Form form={projForm} layout="vertical" onFinish={handleProjectSubmit}>
          <Form.Item name="project_name" label="ชื่อโครงการ" rules={[{ required: true, message: 'กรุณากรอกชื่อโครงการ' }]}>
            <Input placeholder="เช่น LIMS ศูนย์เทคโนโลยีสารสนเทศ" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item name="description" label="รายละเอียดโครงการ">
            <Input.TextArea placeholder="เช่น ระบบหลัก, ระบบย่อย..." rows={3} style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item 
            name="project_contract" label="เลขที่สัญญา" normalize={(value) => (value || '').replace(/[^0-9/]/g, '')}
            rules={[{ pattern: /^[0-9]+\/[0-9]{4}$/, message: 'รูปแบบผิด! ต้องเป็น "ตัวเลข/พ.ศ. 4 หลัก" (เช่น 9/2566)' }]}
          >
            <Input placeholder="เช่น 9/2566" size="large" style={{ borderRadius: '8px' }}/>
          </Form.Item>
          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsProjModalVisible(false)} style={{ marginRight: 10, borderRadius: '8px' }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#1890ff', borderRadius: '8px' }}>บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>

      {/* ================================================================= */}
      {/* 🌟 Modal 1: แสดงรายการอุปกรณ์ย่อยภายในหมวดหมู่ (SLA Equipments) */}
      {/* ================================================================= */}
      <Modal 
        title={<><DesktopOutlined /> จัดการอุปกรณ์ในหมวดหมู่: <Text type="danger">{selectedCategoryForEq?.category_name}</Text></>} 
        open={isEqListModalVisible} 
        onCancel={() => setIsEqListModalVisible(false)} 
        footer={null} 
        width={800} 
        destroyOnHidden
      >
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 15 }}>
          <Button 
            type="primary" 
            icon={<PlusOutlined />} 
            style={{ borderRadius: '8px', backgroundColor: '#f59e0b', borderColor: '#f59e0b' }}
            onClick={() => { 
              setEditingEq(null); 
              eqForm.resetFields(); 
              eqForm.setFieldsValue({ category_id: selectedCategoryForEq.category_id, status: 'Active' }); 
              setIsEqFormModalVisible(true); 
            }}
          >
            เพิ่มอุปกรณ์ใหม่
          </Button>
        </div>
        <Table 
          columns={[
            { title: 'ชื่ออุปกรณ์ / ระบบย่อย', dataIndex: 'equipment_name', key: 'equipment_name' },
            { title: 'S/N', dataIndex: 'serial_number', key: 'serial_number', render: (val) => val || '-' },
            { 
              title: 'สถานะ', 
              align: 'center', 
              width: 100, 
              render: (_, record) => (
                <Switch 
                  checked={record.status === 'Active'} 
                  onChange={(checked) => handleEqStatusChange(record.equipment_id, checked)} 
                  checkedChildren="เปิด" 
                  unCheckedChildren="ปิด"
                  style={{ backgroundColor: record.status === 'Active' ? '#10b981' : '#cbd5e1' }}
                />
              ) 
            },
            { title: 'จัดการ', align: 'center', width: 120, render: (_, record) => (
              <Space>
                <Button type="text" icon={<EditOutlined />} style={{ color: '#1890ff' }} onClick={() => { setEditingEq(record); eqForm.setFieldsValue(record); setIsEqFormModalVisible(true); }} />
                <Popconfirm title="ลบอุปกรณ์นี้?" onConfirm={() => handleEqDelete(record.equipment_id)}>
                  <Button type="text" danger icon={<DeleteOutlined />} />
                </Popconfirm>
              </Space>
            )}
          ]} 
          dataSource={equipments.filter(e => e.category_id === selectedCategoryForEq?.category_id)} 
          rowKey="equipment_id" 
          pagination={{ pageSize: 5 }} 
        />
      </Modal>

      {/* ================================================================= */}
      {/* 🌟 Modal 2: ฟอร์มสำหรับ เพิ่ม/แก้ไข ข้อมูลอุปกรณ์ */}
      {/* ================================================================= */}
      <Modal 
        title={editingEq ? "✏️ แก้ไขอุปกรณ์" : "➕ เพิ่มอุปกรณ์ใหม่"} 
        open={isEqFormModalVisible} 
        onCancel={() => setIsEqFormModalVisible(false)} 
        footer={null} 
        zIndex={1050} 
        forceRender
      >
        <Form form={eqForm} layout="vertical" onFinish={handleEqSubmit}>
          <Form.Item name="category_id" hidden><Input /></Form.Item> 
          
          <Form.Item name="equipment_name" label={<Text strong>ชื่ออุปกรณ์ / ระบบย่อย <span style={{color:'red'}}>*</span></Text>} rules={[{ required: true, message: 'กรุณากรอกชื่ออุปกรณ์' }]}>
            <Input placeholder="เช่น Switch Core, Database Server" size="large" style={{ borderRadius: '8px' }} />
          </Form.Item>
          
          <Form.Item name="serial_number" label={<Text strong>Serial Number / รหัสอ้างอิง (ถ้ามี)</Text>}>
            <Input placeholder="เช่น S/N: 123456" size="large" style={{ borderRadius: '8px' }} />
          </Form.Item>
          
          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsEqFormModalVisible(false)} style={{ marginRight: 10, borderRadius: '8px' }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#f59e0b', borderColor: '#f59e0b', borderRadius: '8px' }}>บันทึกข้อมูลอุปกรณ์</Button>
          </Form.Item>
        </Form>
      </Modal>

    </div>
  );
}