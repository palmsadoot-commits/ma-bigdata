import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Space, Typography, Tag, Modal, Form, Input, Select, Popconfirm, Row, Col, Tabs } from 'antd';
import { AppstoreOutlined, PlusOutlined, EditOutlined, DeleteOutlined, ArrowLeftOutlined, GlobalOutlined, ApartmentOutlined, SettingOutlined } from '@ant-design/icons';
import axios from 'axios';
import { alertSuccess, alertError } from '../utils/alert';

const { Title, Text } = Typography;
const { Option } = Select;
const BACKEND_URL = 'http://localhost:3000';

export default function CategoryManagement() {
  const [categories, setCategories] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null); 
  const [catForm] = Form.useForm();

  const [isProjModalVisible, setIsProjModalVisible] = useState(false);
  const [editingProject, setEditingProject] = useState(null); 
  const [projForm] = Form.useForm();
  
  const [isProjManageModalVisible, setIsProjManageModalVisible] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [catRes, projRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/categories`),
        axios.get(`${BACKEND_URL}/api/projects`)
      ]);
      setCategories(catRes.data);
      setProjects(projRes.data);
    } catch (error) {
      alertError('ผิดพลาด', 'ไม่สามารถโหลดข้อมูลได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  // ==========================================
  // จัดการโครงการ (Projects) 
  // ==========================================
  const handleProjectManage = () => {
    setIsProjManageModalVisible(true);
  };

  const handleProjectAdd = () => {
    setEditingProject(null);
    projForm.resetFields();
    setIsProjModalVisible(true);
  };

  const handleProjectEdit = (record) => {
    setEditingProject(record);
    projForm.setFieldsValue(record);
    setIsProjModalVisible(true);
  };

  const handleProjectDelete = async (id) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/projects/${id}`);
      alertSuccess('ลบสำเร็จ', 'โครงการถูกลบออกจากระบบแล้ว');
      fetchData(); 
    } catch (error) {
      alertError('ลบไม่สำเร็จ', error.response?.data?.error || 'เกิดข้อผิดพลาด');
    }
  };

  const handleProjectSubmit = async (values) => {
    try {
      if (editingProject) {
        await axios.put(`${BACKEND_URL}/api/projects/${editingProject.project_id}`, values);
        alertSuccess('อัปเดตสำเร็จ', 'แก้ไขโครงการเรียบร้อยแล้ว');
      } else {
        await axios.post(`${BACKEND_URL}/api/projects`, values);
        alertSuccess('เพิ่มสำเร็จ', 'เพิ่มโครงการใหม่เรียบร้อยแล้ว');
      }
      setIsProjModalVisible(false);
      fetchData(); 
    } catch (error) {
      alertError('บันทึกไม่สำเร็จ', 'เกิดข้อผิดพลาดในการบันทึกข้อมูล');
    }
  };

  const projManageColumns = [
    { title: 'รหัสโครงการ', dataIndex: 'project_id', key: 'project_id', align: 'center', width: 100 },
    { title: 'ชื่อโครงการ', dataIndex: 'project_name', key: 'project_name' },
    // ✅ เพิ่มคอลัมน์แสดง Description 
    { title: 'รายละเอียด', dataIndex: 'description', key: 'description', render: (text) => text || '-' },
    { title: 'เลขที่สัญญา', dataIndex: 'project_contract', key: 'project_contract', render: (text) => text || '-' },
    {
      title: 'จัดการ',
      key: 'action',
      align: 'right',
      width: 150,
      render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleProjectEdit(record)}>แก้ไข</Button>
          <Popconfirm title="ยืนยันการลบ?" onConfirm={() => handleProjectDelete(record.project_id)} okText="ลบ" cancelText="ยกเลิก">
            <Button type="primary" danger size="small" icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  // ==========================================
  // จัดการหมวดหมู่ (Categories)
  // ==========================================
  const handleCatAdd = () => {
    setEditingCategory(null);
    catForm.resetFields();
    catForm.setFieldsValue({
      project_id: selectedProject ? selectedProject.project_id : undefined
    });
    setIsModalVisible(true);
  };

  const handleCatEdit = (record) => {
    setEditingCategory(record);
    catForm.setFieldsValue(record);
    setIsModalVisible(true);
  };

  const handleCatDelete = async (id) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/categories/${id}`);
      alertSuccess('ลบสำเร็จ', 'หมวดหมู่ถูกลบออกจากระบบแล้ว');
      fetchData();
    } catch (error) {
      alertError('ลบไม่สำเร็จ', error.response?.data?.error || 'เกิดข้อผิดพลาด');
    }
  };

  const handleCatSubmit = async (values) => {
    try {
      if (editingCategory) {
        await axios.put(`${BACKEND_URL}/api/categories/${editingCategory.category_id}`, values);
        alertSuccess('อัปเดตสำเร็จ', 'แก้ไขหมวดหมู่เรียบร้อยแล้ว');
      } else {
        await axios.post(`${BACKEND_URL}/api/categories`, values);
        alertSuccess('เพิ่มสำเร็จ', 'เพิ่มหมวดหมู่ใหม่เรียบร้อยแล้ว');
      }
      setIsModalVisible(false);
      fetchData(); 
    } catch (error) {
      alertError('บันทึกไม่สำเร็จ', 'เกิดข้อผิดพลาดในการบันทึกข้อมูล');
    }
  };

  const catColumns = [
    { title: 'รหัส', dataIndex: 'category_id', key: 'category_id', width: 80, align: 'center' },
    { title: 'ชื่อหมวดหมู่ / ระบบ', dataIndex: 'category_name', key: 'category_name' },
    {
      title: 'จัดการ',
      key: 'action',
      align: 'right',
      width: 150,
      render: (_, record) => (
        <Space size="small">
          <Button type="primary" size="small" icon={<EditOutlined />} onClick={() => handleCatEdit(record)}>แก้ไข</Button>
          <Popconfirm title="ยืนยันการลบหมวดหมู่นี้?" onConfirm={() => handleCatDelete(record.category_id)} okText="ลบ" cancelText="ยกเลิก">
            <Button type="primary" danger size="small" icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  const renderProjectCards = () => {
    const allProjectsList = [{ project_id: null, project_name: 'ส่วนกลาง (ทั่วไป)' }, ...projects];

    const cardThemes = [
      { bg: 'linear-gradient(135deg, #e0f2fe 0%, #d0e8fc 100%)', color: '#0284c7', tagBg: '#bae6fd', border: '#7dd3fc' }, 
      { bg: 'linear-gradient(135deg, #dcfce7 0%, #c3f9d5 100%)', color: '#16a34a', tagBg: '#bbf7d0', border: '#86efac' }, 
      { bg: 'linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%)', color: '#9333ea', tagBg: '#e9d5ff', border: '#d8b4fe' }, 
      { bg: 'linear-gradient(135deg, #cffafe 0%, #a5f3fc 100%)', color: '#0891b2', tagBg: '#a5f3fc', border: '#67e8f9' }, 
      { bg: 'linear-gradient(135deg, #ffedd5 0%, #fed7aa 100%)', color: '#ea580c', tagBg: '#fed7aa', border: '#fdba74' }, 
    ];

    return (
      <Row gutter={[24, 24]} align="stretch">
        {allProjectsList.map((proj, index) => {
          const count = categories.filter(c => c.project_id === proj.project_id).length;
          const theme = cardThemes[index % cardThemes.length];
          
          return (
            <Col xs={24} sm={12} md={8} lg={6} key={proj.project_id || 'central'}>
              <div 
                onClick={() => setSelectedProject(proj)}
                style={{
                  background: theme.bg,
                  borderRadius: '24px', 
                  padding: '24px',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  boxShadow: '0 8px 30px rgba(0,0,0,0.08)', 
                  transition: 'all 0.3s ease',
                  height: '100%',
                  border: `2px solid ${theme.border}` 
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-8px)';
                  e.currentTarget.style.boxShadow = '0 20px 40px rgba(0,0,0,0.12)'; 
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0px)';
                  e.currentTarget.style.boxShadow = '0 8px 30px rgba(0,0,0,0.08)';
                }}
              >
                <div>
                  <div style={{ color: theme.color, fontSize: '14px', fontWeight: 'bold', marginBottom: '8px' }}>
                    {proj.project_name}
                  </div>
                  <div style={{ fontSize: '38px', fontWeight: '900', color: '#1e293b', lineHeight: '1' }}>
                    {count}
                  </div>
                  <div style={{ marginTop: '12px' }}>
                    <span style={{ 
                      background: theme.tagBg, 
                      color: theme.color, 
                      padding: '4px 12px', 
                      borderRadius: '12px', 
                      fontSize: '12px',
                      fontWeight: 'bold'
                    }}>
                      รายการ
                    </span>
                  </div>
                </div>

                <div style={{
                  width: '56px',
                  height: '56px',
                  borderRadius: '16px', 
                  backgroundColor: 'rgba(255, 255, 255, 0.7)',
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  boxShadow: '0 4px 10px rgba(0,0,0,0.02)'
                }}>
                  {proj.project_id === null ? (
                    <GlobalOutlined style={{ fontSize: '28px', color: theme.color }} />
                  ) : (
                    <ApartmentOutlined style={{ fontSize: '28px', color: theme.color }} />
                  )}
                </div>
              </div>
            </Col>
          );
        })}
      </Row>
    );
  };

  const renderCategoryTabs = () => {
    const projectCategories = categories.filter(c => c.project_id === selectedProject.project_id);

    const hwCats = projectCategories.filter(c => c.category_type === 'Hardware');
    const swCats = projectCategories.filter(c => c.category_type === 'Software');
    const appCats = projectCategories.filter(c => c.category_type === 'Application'); 
    const otherCats = projectCategories.filter(c => c.category_type === 'Other' || !c.category_type);

    const tabItems = [
      { key: '1', label: `Hardware (${hwCats.length})`, children: <Table columns={catColumns} dataSource={hwCats} rowKey="category_id" pagination={{ pageSize: 10 }} /> },
      { key: '2', label: `Software (${swCats.length})`, children: <Table columns={catColumns} dataSource={swCats} rowKey="category_id" pagination={{ pageSize: 10 }} /> },
      { key: '3', label: `Application (${appCats.length})`, children: <Table columns={catColumns} dataSource={appCats} rowKey="category_id" pagination={{ pageSize: 10 }} /> },
      { key: '4', label: `Other (${otherCats.length})`, children: <Table columns={catColumns} dataSource={otherCats} rowKey="category_id" pagination={{ pageSize: 10 }} /> }
    ];

    return (
      <Card styles={{ body: { padding: '20px' } }} style={{ borderRadius: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
        <Tabs defaultActiveKey="1" items={tabItems} size="large" />
      </Card>
    );
  };

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          {selectedProject ? (
            <Space align="center">
              <Button icon={<ArrowLeftOutlined />} onClick={() => setSelectedProject(null)} style={{ borderRadius: '8px' }}>ย้อนกลับ</Button>
              <Title level={2} style={{ color: '#2a1a4a', margin: 0, marginLeft: 10 }}>
                หมวดหมู่: {selectedProject.project_name}
              </Title>
            </Space>
          ) : (
            <Title level={2} style={{ color: '#2a1a4a', margin: 0 }}><AppstoreOutlined /> จัดการหมวดหมู่ / ระบบ</Title>
          )}
        </div>
        
        <Space>
          {!selectedProject && (
            <Button type="default" icon={<SettingOutlined />} size="large" style={{ borderRadius: '8px' }} onClick={handleProjectManage}>
              จัดการโครงการ
            </Button>
          )}
          
          <Button type="primary" icon={<PlusOutlined />} size="large" style={{ backgroundColor: '#28a745', borderRadius: '8px' }} onClick={handleCatAdd}>
            เพิ่มหมวดหมู่ใหม่
          </Button>
        </Space>
      </div>

      {selectedProject ? renderCategoryTabs() : renderProjectCards()}

      {/* Modal: หมวดหมู่ (Category) */}
      <Modal 
        title={editingCategory ? "✏️ แก้ไขหมวดหมู่" : "➕ เพิ่มหมวดหมู่ใหม่"} 
        open={isModalVisible} 
        onCancel={() => setIsModalVisible(false)}
        footer={null}
        destroyOnHidden
        forceRender 
      >
        <Form form={catForm} layout="vertical" onFinish={handleCatSubmit}>
          <Form.Item name="category_name" label="ชื่อหมวดหมู่ / ระบบ" rules={[{ required: true, message: 'กรุณากรอกชื่อหมวดหมู่' }]}>
            <Input placeholder="เช่น คอมพิวเตอร์ตั้งโต๊ะ, ระบบบัญชี" />
          </Form.Item>
          
          <Form.Item name="category_type" label="ประเภท (Type)">
            <Select placeholder="เลือกประเภท (ถ้ามี)" allowClear getPopupContainer={(trigger) => trigger.parentNode}>
              <Option value="Hardware">Hardware (ฮาร์ดแวร์)</Option>
              <Option value="Software">Software (ซอฟต์แวร์)</Option>
              <Option value="Application">Application (แอปพลิเคชัน)</Option>
              <Option value="Other">Other (อื่นๆ)</Option>
            </Select>
          </Form.Item>

          <Form.Item name="project_id" label="ผูกกับโปรเจกต์ (ปล่อยว่างหากเป็นส่วนกลาง)">
            <Select placeholder="เลือกโปรเจกต์" allowClear getPopupContainer={(trigger) => trigger.parentNode}>
              {projects.map(p => ( <Option key={p.project_id} value={p.project_id}>{p.project_name}</Option> ))}
            </Select>
          </Form.Item>

          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: 10 }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#1890ff' }}>บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>

      {/* Modal: รายชื่อโครงการ */}
      <Modal 
        title={<><SettingOutlined /> จัดการรายชื่อโครงการ</>}
        open={isProjManageModalVisible} 
        onCancel={() => setIsProjManageModalVisible(false)}
        footer={null}
        width={1000} 
        destroyOnHidden
      >
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 15 }}>
          <Button type="primary" icon={<PlusOutlined />} style={{ backgroundColor: '#28a745' }} onClick={handleProjectAdd}>
            เพิ่มโครงการใหม่
          </Button>
        </div>
        <Table columns={projManageColumns} dataSource={projects} rowKey="project_id" pagination={{ pageSize: 10 }} />
      </Modal>

      {/* Modal: เพิ่ม/แก้ไขโครงการ */}
      <Modal 
        title={editingProject ? "✏️ แก้ไขข้อมูลโครงการ" : "➕ เพิ่มโครงการใหม่"} 
        open={isProjModalVisible} 
        onCancel={() => setIsProjModalVisible(false)}
        footer={null}
        destroyOnHidden
        forceRender 
        zIndex={1050}
      >
        <Form form={projForm} layout="vertical" onFinish={handleProjectSubmit}>
          <Form.Item name="project_name" label="ชื่อโครงการ" rules={[{ required: true, message: 'กรุณากรอกชื่อโครงการ' }]}>
            <Input placeholder="เช่น LIMS ศูนย์เทคโนโลยีสารสนเทศ" />
          </Form.Item>
          
          {/* ✅ เพิ่มช่องกรอก Description (รายละเอียด) */}
          <Form.Item name="description" label="รายละเอียดโครงการ">
            <Input.TextArea placeholder="เช่น ระบบหลัก, ระบบย่อย..." rows={3} />
          </Form.Item>
          
          {/* ✅ บังคับแพทเทิร์น "ตัวเลข/พ.ศ. 4 หลัก" พร้อมข้อความแจ้งเตือนสีแดงถ้าพิมพ์ผิด */}
          <Form.Item 
            name="project_contract" 
            label="เลขที่สัญญา"
            normalize={(value) => (value || '').replace(/[^0-9/]/g, '')}
            rules={[
              {
                pattern: /^[0-9]+\/[0-9]{4}$/,
                message: 'รูปแบบผิด! ต้องเป็น "ตัวเลข/พ.ศ. 4 หลัก" (เช่น 9/2566)'
              }
            ]}
          >
            <Input placeholder="เช่น 9/2566" />
          </Form.Item>

          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsProjModalVisible(false)} style={{ marginRight: 10 }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#1890ff' }}>บันทึกข้อมูล</Button>
          </Form.Item>
        </Form>
      </Modal>

    </div>
  );
}