import React, { useState, useEffect } from 'react';
// ✅ เติม Select เข้ามาในปีกกานี้เรียบร้อยครับ
import { Card, Row, Col, Typography, Tag, Avatar, Button, Modal, Form, Input, Upload, Space, Empty, Spin, message, Select } from 'antd';
import { 
  ClockCircleOutlined, UserOutlined, FileTextOutlined, 
  UploadOutlined, CheckCircleOutlined, SyncOutlined, 
  ExclamationCircleOutlined, FireOutlined 
} from '@ant-design/icons';
import axios from 'axios';
import dayjs from 'dayjs';
import 'dayjs/locale/th';

// ตั้งค่าภาษาไทยให้วันที่
dayjs.locale('th');

const { Title, Text } = Typography;
const { TextArea } = Input;
const BACKEND_URL = 'http://localhost:3000';

export default function TicketBoard() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(false);
  
  // State สำหรับ Modal อัปเดตสถานะ
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [fileList, setFileList] = useState([]);
  const [form] = Form.useForm();

  // จำลองข้อมูลผู้ใช้ที่ล็อกอินอยู่ (ของจริงดึงจาก localStorage)
  const currentUser = JSON.parse(localStorage.getItem('user')) || { user_id: 1, first_name: 'Admin' };

  const fetchTickets = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${BACKEND_URL}/api/tickets`);
      setTickets(res.data);
    } catch (error) {
      message.error('ไม่สามารถโหลดข้อมูลใบงานได้');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchTickets(); }, []);

  // ฟังก์ชันเปิด Modal อัปเดตสถานะ
  const handleOpenUpdateModal = (ticket) => {
    setSelectedTicket(ticket);
    setFileList([]);
    form.resetFields();
    
    // ตั้งค่าเริ่มต้นให้ฟอร์ม
    form.setFieldsValue({
      status: ticket.status === 'Pending' ? 'In Progress' : 'Resolved'
    });
    
    setIsModalVisible(true);
  };

  // ฟังก์ชันบันทึกการอัปเดตสถานะ
  const handleUpdateStatus = async (values) => {
    const formData = new FormData();
    formData.append('status', values.status);
    formData.append('technician_id', currentUser.user_id);
    if (values.root_cause_and_solution) {
      formData.append('root_cause_and_solution', values.root_cause_and_solution);
    }

    // แนบไฟล์
    fileList.forEach(file => {
      formData.append('attachments', file.originFileObj);
    });

    try {
      await axios.put(`${BACKEND_URL}/api/tickets/${selectedTicket.ticket_id}/update-status`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      message.success('อัปเดตสถานะใบงานเรียบร้อยแล้ว!');
      setIsModalVisible(false);
      fetchTickets(); // โหลดกระดานใหม่
    } catch (error) {
      message.error('เกิดข้อผิดพลาดในการอัปเดตสถานะ');
    }
  };

  // Props สำหรับ Upload Component
  const uploadProps = {
    onRemove: (file) => {
      setFileList(prev => prev.filter(item => item.uid !== file.uid));
    },
    beforeUpload: (file) => {
      setFileList(prev => [...prev, file]);
      return false; // หยุดไม่ให้อัปโหลดอัตโนมัติ (เดี๋ยวเราอัปโหลดเองตอนกด Submit)
    },
    fileList,
  };

  // แยกกลุ่มใบงานตามสถานะ
  const pendingTickets = tickets.filter(t => t.status === 'Pending');
  const inProgressTickets = tickets.filter(t => t.status === 'In Progress');
  const resolvedTickets = tickets.filter(t => t.status === 'Resolved');

  // คอมโพเนนต์การ์ดใบงาน (Ticket Card)
  const TicketCard = ({ ticket, colorTheme }) => (
    <Card 
      hoverable 
      style={{ 
        marginBottom: 16, 
        borderRadius: 12, 
        borderLeft: `6px solid ${colorTheme}`,
        boxShadow: '0 4px 12px rgba(0,0,0,0.04)'
      }}
      styles={{ body: { padding: '16px' } }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <Text strong style={{ fontSize: 16, color: '#1e293b' }}>{ticket.ticket_number}</Text>
        <Tag color={colorTheme} style={{ borderRadius: 10, margin: 0 }}>
          {ticket.category_name || 'ทั่วไป'}
        </Tag>
      </div>
      
      <Text type="secondary" ellipsis={{ tooltip: ticket.problem_detail }} style={{ display: 'block', marginBottom: 12, minHeight: 44 }}>
        {ticket.problem_detail}
      </Text>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <Space size="small">
          <Avatar size="small" style={{ backgroundColor: '#e2e8f0', color: '#475569' }} icon={<UserOutlined />} />
          <Text type="secondary" style={{ fontSize: 12 }}>{ticket.reporter_name}</Text>
        </Space>
        <Space size="small" style={{ color: '#94a3b8', fontSize: 12 }}>
          <ClockCircleOutlined />
          {dayjs(ticket.created_at).format('DD MMM')}
        </Space>
      </div>

      <Button 
        type="dashed" 
        block 
        style={{ borderRadius: 8, color: colorTheme, borderColor: colorTheme }}
        onClick={() => handleOpenUpdateModal(ticket)}
      >
        {ticket.status === 'Pending' ? 'เริ่มดำเนินการ' : 'อัปเดตสถานะ'}
      </Button>
    </Card>
  );

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f6', minHeight: '100vh' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <Title level={2} style={{ color: '#2a1a4a', margin: 0 }}><FireOutlined style={{ color: '#ef4444' }}/> กระดานสถานะใบงาน (Kanban Board)</Title>
        <Button type="primary" icon={<SyncOutlined />} onClick={fetchTickets} loading={loading}>รีเฟรชข้อมูล</Button>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '50px' }}><Spin size="large" /></div>
      ) : (
        <Row gutter={[24, 24]} align="stretch">
          
          {/* คอลัมน์: รอดำเนินการ (Pending) */}
          <Col xs={24} md={8}>
            <div style={{ backgroundColor: '#fef2f2', borderRadius: 16, padding: '16px', height: '100%', border: '1px solid #fecaca' }}>
              <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
                <ExclamationCircleOutlined style={{ color: '#ef4444', fontSize: 20, marginRight: 10 }} />
                <Title level={4} style={{ color: '#991b1b', margin: 0 }}>รอดำเนินการ ({pendingTickets.length})</Title>
              </div>
              {pendingTickets.length > 0 ? (
                pendingTickets.map(t => <TicketCard key={t.ticket_id} ticket={t} colorTheme="#ef4444" />)
              ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="ไม่มีใบงานรอดำเนินการ" />
              )}
            </div>
          </Col>

          {/* คอลัมน์: กำลังดำเนินการ (In Progress) */}
          <Col xs={24} md={8}>
            <div style={{ backgroundColor: '#fffbeb', borderRadius: 16, padding: '16px', height: '100%', border: '1px solid #fde68a' }}>
              <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
                <SyncOutlined spin style={{ color: '#f59e0b', fontSize: 20, marginRight: 10 }} />
                <Title level={4} style={{ color: '#b45309', margin: 0 }}>กำลังดำเนินการ ({inProgressTickets.length})</Title>
              </div>
              {inProgressTickets.length > 0 ? (
                inProgressTickets.map(t => <TicketCard key={t.ticket_id} ticket={t} colorTheme="#f59e0b" />)
              ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="ไม่มีใบงานที่กำลังทำ" />
              )}
            </div>
          </Col>

          {/* คอลัมน์: เสร็จสิ้น / ส่งตรวจสอบ (Resolved) */}
          <Col xs={24} md={8}>
            <div style={{ backgroundColor: '#f0fdf4', borderRadius: 16, padding: '16px', height: '100%', border: '1px solid #bbf7d0' }}>
              <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
                <CheckCircleOutlined style={{ color: '#22c55e', fontSize: 20, marginRight: 10 }} />
                <Title level={4} style={{ color: '#166534', margin: 0 }}>ส่งตรวจสอบ / เสร็จสิ้น ({resolvedTickets.length})</Title>
              </div>
              {resolvedTickets.length > 0 ? (
                resolvedTickets.map(t => <TicketCard key={t.ticket_id} ticket={t} colorTheme="#22c55e" />)
              ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="ยังไม่มีใบงานที่เสร็จสิ้น" />
              )}
            </div>
          </Col>

        </Row>
      )}

      {/* Modal สำหรับอัปเดตสถานะ */}
      <Modal
        title={<span><FileTextOutlined /> อัปเดตสถานะใบงาน: <Text type="danger">{selectedTicket?.ticket_number}</Text></span>}
        open={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
        destroyOnHidden
      >
        <div style={{ backgroundColor: '#f8fafc', padding: 16, borderRadius: 8, marginBottom: 20 }}>
          <Text strong>ปัญหาที่แจ้ง:</Text> <br/>
          <Text type="secondary">{selectedTicket?.problem_detail}</Text>
        </div>

        <Form form={form} layout="vertical" onFinish={handleUpdateStatus}>
          <Form.Item name="status" label="เปลี่ยนสถานะเป็น" rules={[{ required: true }]}>
            <Select size="large">
              <Select.Option value="Pending"><Tag color="red">รอดำเนินการ</Tag></Select.Option>
              <Select.Option value="In Progress"><Tag color="orange">กำลังดำเนินการ</Tag></Select.Option>
              <Select.Option value="Resolved"><Tag color="green">ส่งตรวจสอบ / เสร็จสิ้น</Tag></Select.Option>
            </Select>
          </Form.Item>

          <Form.Item name="root_cause_and_solution" label="สาเหตุและวิธีแก้ไข (บังคับกรอกเมื่อปิดงาน)">
            <TextArea 
              rows={4} 
              placeholder="ระบุสาเหตุของปัญหา และวิธีการแก้ไขที่ได้ทำไป..." 
              style={{ borderRadius: 8 }}
            />
          </Form.Item>

          <Form.Item label="แนบไฟล์เอกสาร / รูปภาพอ้างอิง (ถ้ามี)">
            <Upload {...uploadProps}>
              <Button icon={<UploadOutlined />}>คลิกเพื่อเลือกไฟล์</Button>
            </Upload>
          </Form.Item>

          <Form.Item style={{ textAlign: 'right', marginTop: 30, marginBottom: 0 }}>
            <Button onClick={() => setIsModalVisible(false)} style={{ marginRight: 10, borderRadius: 8 }}>ยกเลิก</Button>
            <Button type="primary" htmlType="submit" style={{ backgroundColor: '#1890ff', borderRadius: 8 }}>บันทึกสถานะ</Button>
          </Form.Item>
        </Form>
      </Modal>

    </div>
  );
}