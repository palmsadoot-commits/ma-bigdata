import React, { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('lmis_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const [activeProject, setActiveProject] = useState(() => {
    const savedProject = localStorage.getItem('lmis_active_project');
    return savedProject ? JSON.parse(savedProject) : null;
  });

  const login = (userData) => {
    setUser(userData);
    localStorage.setItem('lmis_user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    setActiveProject(null);
    localStorage.removeItem('lmis_user');
    localStorage.removeItem('lmis_active_project');
  };

  const selectProject = (project) => {
    setActiveProject(project);
    localStorage.setItem('lmis_active_project', JSON.stringify(project));
  };

  const changeProject = () => {
    setActiveProject(null);
    localStorage.removeItem('lmis_active_project');
  };

  return (
    <AuthContext.Provider value={{ user, activeProject, login, logout, selectProject, changeProject, setActiveProject }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
