import axios from 'axios';

const API_BASE_URL = 'http://127.0.0.1:3000/api';

const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 600000, // ✅ รอได้นานถึง 10 นาที (สำหรับงาน Backup)
});

// ✅ แนบ Token อัตโนมัติในทุก Request
axiosInstance.interceptors.request.use(config => {
  const savedUser = localStorage.getItem('lmis_user');
  if (savedUser) {
    try {
      const parsedUser = JSON.parse(savedUser);
      if (parsedUser && parsedUser.token) {
        config.headers.Authorization = `Bearer ${parsedUser.token}`;
      }
    } catch (e) {
      console.error("Error parsing user from localStorage", e);
    }
  }
  return config;
}, error => {
  return Promise.reject(error);
});

// ดักจับถ้า Token หมดอายุ (401) ให้ Logout ทันที
axiosInstance.interceptors.response.use(response => {
  return response;
}, error => {
  if (error.response && error.response.status === 401) {
    // ป้องกันการ Loop ถ้าอยู่ที่หน้า Login อยู่แล้วไม่ต้องทำอะไร
    if (!window.location.pathname.includes('/login') && window.location.pathname !== '/') {
      localStorage.removeItem('lmis_user');
      localStorage.removeItem('lmis_active_project');
      window.location.href = '/';
    }
  }  return Promise.reject(error);
});

export default axiosInstance;
;
