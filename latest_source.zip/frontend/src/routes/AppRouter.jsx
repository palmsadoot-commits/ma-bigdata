import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import { Layout, Menu, Typography, Button, Space, Avatar, Tag, Spin, Drawer, Grid, Dropdown } from 'antd';
import {
  DashboardOutlined,
  PlusCircleOutlined,
  UnorderedListOutlined,
  SettingOutlined,
  UserOutlined,
  LogoutOutlined,
  RocketOutlined,
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  ProjectOutlined,
  AppstoreOutlined,
  AuditOutlined,
  DatabaseOutlined,
  ShopOutlined,
  ToolOutlined,
  DownOutlined
} from '@ant-design/icons';
import { useAuth } from '../context/AuthContext';
import axiosInstance from '../services/api/axiosInstance';

// นำเข้า Components
import Profile from '../components/Profile';
import UserManagement from '../components/UserManagement';
import CategoryManagement from '../components/CategoryManagement';
import TicketBoard from '../components/TicketBoard';
import StatusManagement from '../components/StatusManagement';
import BackupManagement from '../components/BackupManagement';
import Login from '../components/Login';
import ProjectSelection from '../components/ProjectSelection';
import TicketForm from '../components/TicketForm';
import TicketDashboard from '../components/TicketDashboard';
import TicketList from '../components/TicketList';
import TicketDetail from '../components/TicketDetail';
import Settings from '../components/Settings';
import SystemSettings from '../components/SystemSettings';
import AuditLog from '../components/AuditLog';
import TicketPrint from '../components/TicketPrint';
import VendorManagement from '../components/VendorManagement';

const { Header, Sider, Content } = Layout;
const { Title, Text } = Typography;
const { useBreakpoint } = Grid;

function MainLayout() {
  const { user, activeProject, logout, changeProject } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileVisible, setMobileVisible] = useState(false);
  const location = useLocation(); 
  const screens = useBreakpoint();
  const isMobile = !screens.md;

  const menuItems = [
    { key: '/dashboard', icon: <DashboardOutlined />, label: <Link to="/dashboard" onClick={() => setMobileVisible(false)}>แดชบอร์ด</Link> }
  ];

  if (user?.role === 'admin' || user?.role === 'user') {
    menuItems.push({ key: '/', icon: <PlusCircleOutlined />, label: <Link to="/" onClick={() => setMobileVisible(false)}>สร้างใบงาน</Link> });
  }

  menuItems.push({ key: '/tickets', icon: <UnorderedListOutlined />, label: <Link to="/tickets" onClick={() => setMobileVisible(false)}>รายการใบงาน</Link> });
  
  // เพิ่มเมนูสำหรับการจัดการสำหรับ Admin
  if (user?.role === 'admin') {
    menuItems.push({
      key: 'management',
      icon: <AppstoreOutlined />,
      label: 'ระบบจัดการ',
      children: [
        { key: '/users', icon: <UserOutlined />, label: <Link to="/users" onClick={() => setMobileVisible(false)}>ผู้ใช้</Link> },
        { key: '/categories', icon: <ProjectOutlined />, label: <Link to="/categories" onClick={() => setMobileVisible(false)}>หมวดหมู่</Link> },
        { key: '/statuses', icon: <ToolOutlined />, label: <Link to="/statuses" onClick={() => setMobileVisible(false)}>สถานะ</Link> },
        { key: '/vendors', icon: <ShopOutlined />, label: <Link to="/vendors" onClick={() => setMobileVisible(false)}>Vendor</Link> },
        { key: '/audit-logs', icon: <AuditOutlined />, label: <Link to="/audit-logs" onClick={() => setMobileVisible(false)}>Logs</Link> },
        { key: '/backup', icon: <DatabaseOutlined />, label: <Link to="/backup" onClick={() => setMobileVisible(false)}>Backup</Link> },
        { key: '/system-settings', icon: <SettingOutlined />, label: <Link to="/system-settings" onClick={() => setMobileVisible(false)}>ตั้งค่าระบบ</Link> },
      ]
    });
  }

  menuItems.push({ key: '/settings', icon: <SettingOutlined />, label: <Link to="/settings" onClick={() => setMobileVisible(false)}>โปรไฟล์</Link> });

  const userMenu = {
    items: [
      { key: 'profile', icon: <UserOutlined />, label: <Link to="/settings">โปรไฟล์</Link> },
      { type: 'divider' },
      { key: 'logout', icon: <LogoutOutlined />, label: 'ออกจากระบบ', danger: true, onClick: logout },
    ],
  };

  const renderNavMenu = () => (
    <Menu 
      theme="dark" 
      mode="inline" 
      selectedKeys={[location.pathname]} 
      items={menuItems}
      style={{ borderRight: 0 }}
    />
  );

  return (
    <Layout style={{ minHeight: '100vh' }}>
      {/* Desktop Sider */}
      {!isMobile && (
        <Sider trigger={null} collapsible collapsed={collapsed} width={200} style={{ 
          overflow: 'auto',
          height: '100vh',
          position: 'fixed',
          left: 0,
          top: 0,
          bottom: 0,
          zIndex: 100
        }}>
          <div className="sider-logo" style={{ 
            color: 'white', 
            textAlign: 'center', 
            padding: '20px 10px', 
            fontSize: collapsed ? '12px' : '16px', 
            fontWeight: '900',
            letterSpacing: '0.5px',
            background: 'rgba(255,255,255,0.05)',
            marginBottom: '10px',
            whiteSpace: 'nowrap',
            overflow: 'hidden'
          }}>
            {collapsed ? 'LMIS' : '⚙️ LMIS BIG DATA'}
          </div>
          {renderNavMenu()}
        </Sider>
      )}
      <Drawer
        title="⚙️ LMIS BIG DATA"
        placement="left"
        onClose={() => setMobileVisible(false)}
        open={mobileVisible}
        styles={{ 
          wrapper: { width: 260 },
          body: { padding: 0, backgroundColor: '#001529' }, 
          header: { backgroundColor: '#001529', color: 'white' },
          mask: { backdropFilter: 'blur(4px)' }
        }}
        closeIcon={<span style={{ color: 'white' }}>✕</span>}
      >
        {renderNavMenu()}
      </Drawer>


      <Layout style={{ marginLeft: isMobile ? 0 : (collapsed ? 80 : 200), transition: 'all 0.2s' }}>
        <Header style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between', 
          padding: isMobile ? '0 16px' : '0 24px', 
          boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
          position: 'sticky',
          top: 0,
          zIndex: 99,
          width: '100%',
          height: '64px'
        }}>
          <Space size={isMobile ? 8 : 16}>
            {isMobile ? (
              <Button 
                type="text" 
                icon={<MenuUnfoldOutlined />} 
                onClick={() => setMobileVisible(true)}
                style={{ fontSize: '18px' }}
              />
            ) : (
              <Button
                type="text"
                icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                onClick={() => setCollapsed(!collapsed)}
                style={{ fontSize: '18px' }}
              />
            )}
            
            <Title level={isMobile ? 5 : 4} style={{ margin: 0, color: '#1e293b', whiteSpace: 'nowrap' }}>
              {isMobile ? 'แจ้งซ่อม' : 'ระบบแจ้งซ่อมและบำรุงรักษา'}
            </Title>
            
            {!isMobile && (
              <Tag color="blue" icon={<RocketOutlined />} style={{ fontSize: '13px', padding: '2px 10px', marginLeft: 8, borderRadius: '4px' }}>
                {activeProject?.project_name}
              </Tag>
            )}
            
            {user?.role === 'admin' && !isMobile && (
              <Button type="link" size="small" onClick={changeProject} style={{ color: '#ef8157', padding: 0 }}>[สลับโปรเจกต์]</Button>
            )}
          </Space>

          <Space size={isMobile ? "small" : "large"}>
            {isMobile ? (
              <Dropdown menu={userMenu} placement="bottomRight" arrow>
                <Avatar icon={<UserOutlined />} style={{ backgroundColor: '#2a1a4a', cursor: 'pointer' }} />
              </Dropdown>
            ) : (
              <Dropdown menu={userMenu} placement="bottomRight" arrow>
                <Space style={{ cursor: 'pointer', padding: '4px 8px', borderRadius: '8px', transition: 'background 0.3s' }} className="user-dropdown-hover">
                  <Avatar icon={<UserOutlined />} style={{ backgroundColor: '#2a1a4a' }} />
                  <div style={{ display: 'flex', flexDirection: 'column', lineHeight: '1.2' }}>
                    <Text strong style={{ fontSize: '14px' }}>{user?.first_name}</Text>
                    <Text type="secondary" style={{ fontSize: '11px' }}>{user?.role}</Text>
                  </div>
                  <DownOutlined style={{ fontSize: '10px', color: '#94a3b8' }} />
                </Space>
              </Dropdown>
            )}
          </Space>
        </Header>

        {isMobile && activeProject && (
          <div style={{ background: '#f8fafc', padding: '8px 16px', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Tag color="blue" icon={<RocketOutlined />} style={{ margin: 0 }}>{activeProject?.project_name}</Tag>
            {user?.role === 'admin' && (
              <Button type="link" size="small" onClick={changeProject} style={{ color: '#ef8157', padding: 0 }}>สลับโปรเจกต์</Button>
            )}
          </div>
        )}

        <Content style={{ 
          margin: isMobile ? '12px' : '24px', 
          minHeight: 280,
          background: 'transparent'
        }}>
          <Routes>
            <Route path="/" element={(user?.role === 'admin' || user?.role === 'user') ? <TicketForm project={activeProject} /> : <Navigate to="/dashboard" replace />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/dashboard" element={<TicketDashboard project={activeProject} />} />
            <Route path="/tickets" element={<TicketList project={activeProject} />} />
            <Route path="/ticket/:id" element={<TicketDetail />} />
            <Route path="/print/:id" element={<TicketPrint />} /> 
            <Route path="/settings" element={<Settings />} />
            <Route path="/ticket-board" element={<TicketBoard />} />
            <Route path="/users" element={user?.role === 'admin' ? <UserManagement /> : <Navigate to="/dashboard" replace />} />
            <Route path="/categories" element={user?.role === 'admin' ? <CategoryManagement /> : <Navigate to="/dashboard" replace />} />
            <Route path="/statuses" element={user?.role === 'admin' ? <StatusManagement /> : <Navigate to="/dashboard" replace />} />
            <Route path="/system-settings" element={user?.role === 'admin' ? <SystemSettings /> : <Navigate to="/dashboard" replace />} />
            <Route path="/audit-logs" element={user?.role === 'admin' ? <AuditLog /> : <Navigate to="/dashboard" replace />} />
            <Route path="/backup" element={user?.role === 'admin' ? <BackupManagement /> : <Navigate to="/dashboard" replace />} />
            <Route path="/vendors" element={user?.role === 'admin' ? <VendorManagement /> : <Navigate to="/dashboard" replace />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </Content>
      </Layout>
    </Layout>
  );
}

export default function AppRouter() {
  const { user, activeProject, login, selectProject, setActiveProject } = useAuth();

  useEffect(() => {
    // ✅ เรียก API เฉพาะเมื่อมี User และมี Token เท่านั้น
    if (user && user.token && user.role !== 'admin' && !activeProject) {
        axiosInstance.get('/projects')
        .then(res => {
          const myProject = res.data.find(p => p.project_id === user.project_id);
          if (myProject) {
            selectProject(myProject);
          } else {
            setActiveProject({ project_id: null, project_name: 'ยังไม่ได้ระบุโปรเจกต์ (ติดต่อ Admin)' });
          }
        })
        .catch(err => {
            console.error("Error fetching projects:", err);
        });
    }
  }, [user, activeProject, selectProject, setActiveProject]);

  if (!user) {
    return <Login onLoginSuccess={login} />;
  }

  if (user.role === 'admin' && !activeProject) {
    return <ProjectSelection onSelect={selectProject} />;
  }

  if (!activeProject) {
    return (
      <div style={{ textAlign: 'center', marginTop: '30vh' }}>
        <Spin size="large" description="กำลังเข้าสู่โปรเจกต์ของคุณ..." />
      </div>
    );
  }

  return <MainLayout />;
}
