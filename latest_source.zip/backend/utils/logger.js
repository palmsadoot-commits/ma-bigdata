const db = require('../config/db');

/**
 * Log a user action to the audit_logs table
 * @param {number|null} userId 
 * @param {string} action 
 * @param {string} detail 
 * @param {object} req - Express request object to get IP
 */
const logAction = async (userId, action, detail, req = null) => {
    try {
        let ipAddress = 'unknown';
        if (req) {
            ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
        }
        
        await db.query(
            'INSERT INTO audit_logs (user_id, action, detail, ip_address) VALUES (?, ?, ?, ?)',
            [userId, action, detail, ipAddress]
        );
    } catch (err) {
        console.error('❌ Failed to log action:', err.message);
    }
};

module.exports = { logAction };
