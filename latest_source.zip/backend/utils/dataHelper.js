/**
 * centralize data cleaning and conversion helpers
 */

const toNull = (val) => (val === '' || val === undefined || val === 'null' || val === null) ? null : val;

const toInt = (val, defaultVal = null) => {
    if (val === '' || val === undefined || val === null) return defaultVal;
    const parsed = parseInt(val);
    return isNaN(parsed) ? defaultVal : parsed;
};

const toFloat = (val, defaultVal = null) => {
    if (val === '' || val === undefined || val === null) return defaultVal;
    const parsed = parseFloat(val);
    return isNaN(parsed) ? defaultVal : parsed;
};

// Simple XSS filter for basic prevention (should use dompurify for full protection)
const simpleSanitize = (html) => {
    if (!html) return html;
    // Remove script tags and event handlers
    return html
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/on\w+="[^"]*"/gi, '')
        .replace(/javascript:[^"]*/gi, '');
};

module.exports = {
    toNull,
    toInt,
    toFloat,
    simpleSanitize
};
