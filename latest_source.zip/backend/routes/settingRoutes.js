const express = require('express');
const router = express.Router();
const settingController = require('../controllers/settingController');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { upload } = require('../utils/upload');

// อนุญาตให้เข้าถึงการตั้งค่าพื้นฐานได้โดยไม่ต้องระบุ Token (สำหรับโหลดธีมหน้าแรก)
router.get('/', settingController.getSettings);
router.put('/', authenticateToken, requireRole(['admin']), upload.fields([
    { name: 'system_logo', maxCount: 1 },
    { name: 'system_favicon', maxCount: 1 }
]), settingController.updateSettings);
router.get('/health', authenticateToken, requireRole(['admin']), settingController.getSystemHealth);
router.post('/test-line', authenticateToken, requireRole(['admin']), settingController.testLineConnection);
router.post('/test-email', authenticateToken, requireRole(['admin']), settingController.testEmailConnection);

module.exports = router;
