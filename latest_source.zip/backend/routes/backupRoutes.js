const express = require('express');
const router = express.Router();
const backupController = require('../controllers/backupController');
const { authenticateToken, requireRole } = require('../middleware/auth');

// Database Backup
router.post('/manual', authenticateToken, requireRole(['admin']), backupController.manualBackup);
router.get('/logs', authenticateToken, requireRole(['admin']), backupController.getBackupLogs);
router.get('/settings', authenticateToken, requireRole(['admin']), backupController.getBackupSettings);
router.put('/settings', authenticateToken, requireRole(['admin']), backupController.updateBackupSettings);
router.post('/restore', authenticateToken, requireRole(['admin']), backupController.restoreBackup);
router.delete('/:fileName', authenticateToken, requireRole(['admin']), backupController.deleteBackup);

// Source Backup
router.post('/source/manual', authenticateToken, requireRole(['admin']), backupController.manualSourceBackup);
router.get('/source/logs', authenticateToken, requireRole(['admin']), backupController.getSourceBackupLogs);
router.get('/source/settings', authenticateToken, requireRole(['admin']), backupController.getSourceBackupSettings);
router.put('/source/settings', authenticateToken, requireRole(['admin']), backupController.updateSourceBackupSettings);
router.delete('/source/:fileName', authenticateToken, requireRole(['admin']), backupController.deleteSourceBackup);

// GitHub Sync
router.post('/github/manual', authenticateToken, requireRole(['admin']), backupController.manualGithubSync);
router.get('/github/logs', authenticateToken, requireRole(['admin']), backupController.getGithubLogs);
router.get('/github/settings', authenticateToken, requireRole(['admin']), backupController.getGithubSettings);
router.put('/github/settings', authenticateToken, requireRole(['admin']), backupController.updateGithubSettings);
router.delete('/github/logs/:id', authenticateToken, requireRole(['admin']), backupController.deleteGithubLog);

module.exports = router;
