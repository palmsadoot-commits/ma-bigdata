const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketController');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { upload } = require('../utils/upload');

router.get('/', authenticateToken, ticketController.getTickets);
router.post('/', authenticateToken, upload.single('attachment'), ticketController.createTicket);
router.get('/:id', authenticateToken, ticketController.getTicketById);
router.put('/:id/update-status', authenticateToken, upload.array('attachments', 10), ticketController.updateTicketStatus);
router.delete('/:id', authenticateToken, requireRole(['admin']), ticketController.deleteTicket);

// Ticket Logs
router.get('/:id/logs', authenticateToken, ticketController.getTicketLogs);
router.post('/:id/logs', authenticateToken, ticketController.createTicketLog);

module.exports = router;
