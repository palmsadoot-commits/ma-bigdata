const express = require('express');
const router = express.Router();
const statusController = require('../controllers/statusController');
const { authenticateToken, requireRole } = require('../middleware/auth');

router.get('/', authenticateToken, statusController.getStatuses);
router.post('/', authenticateToken, requireRole(['admin']), statusController.createStatus);
router.put('/:id', authenticateToken, requireRole(['admin']), statusController.updateStatus);
router.delete('/:id', authenticateToken, requireRole(['admin']), statusController.deleteStatus);

module.exports = router;
