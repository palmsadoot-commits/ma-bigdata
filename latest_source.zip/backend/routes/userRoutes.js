const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt'); // แพ็กเกจเข้ารหัสผ่านแบบปลอดภัย
const crypto = require('crypto'); // สำหรับถอดรหัส MD5 ของระบบเก่า
const db = require('../config/db'); // เรียกใช้ไฟล์เชื่อมต่อฐานข้อมูล

// ------------------------------------------------------------------
// 1. API: อัปเดตข้อมูลส่วนตัว (PUT /api/users/profile)
// ------------------------------------------------------------------
router.put('/profile', async (req, res) => {
  // รับค่ามาจากฟอร์มฝั่ง React
  const { user_key, first_name, last_name, position, department, email, telephone, mobile } = req.body;

  try {
    // 🛡️ ป้องกัน SQL Injection โดยใช้ ? (Parameterized Query) แทนการต่อ String
    // ฟิลด์ name, lastname, user_position อ้างอิงจากฐานข้อมูลเก่าที่คุณเคยให้มา
    const sql = `
      UPDATE user 
      SET name = ?, lastname = ?, user_position = ?, email = ?, telephone = ?, mobile = ? 
      WHERE user_key = ?
    `;
    const values = [first_name, last_name, position, email, telephone, mobile, user_key];
    
    const [result] = await db.execute(sql, values);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'ไม่พบข้อมูลผู้ใช้งานในระบบ' });
    }
    res.json({ message: 'อัปเดตข้อมูลส่วนตัวสำเร็จ' });
    
  } catch (error) {
    console.error('Profile Update Error:', error);
    res.status(500).json({ message: 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' });
  }
});

// ------------------------------------------------------------------
// 2. API: เปลี่ยนรหัสผ่าน (PUT /api/users/password)
// ------------------------------------------------------------------
router.put('/password', async (req, res) => {
  const { user_key, old_password, new_password } = req.body;

  try {
    // 1. ดึงรหัสผ่านปัจจุบันจากฐานข้อมูลมาตรวจสอบ
    const [users] = await db.execute('SELECT password FROM user WHERE user_key = ?', [user_key]);
    if (users.length === 0) return res.status(404).json({ message: 'ไม่พบผู้ใช้งาน' });

    const dbPassword = users[0].password;
    let isMatch = false;

    // 2. 🛡️ โลจิกสำหรับเปลี่ยนผ่านระบบ (Migration)
    if (dbPassword.length === 32) {
      // ถ้ารหัสผ่านใน DB ยาว 32 ตัวอักษร แปลว่าเป็น MD5 จากระบบเก่า (function.php ตัวเดิม)
      const oldHash = crypto.createHash('md5').update(old_password).digest('hex');
      isMatch = (oldHash === dbPassword);
    } else {
      // ถ้ารหัสผ่านเป็นฟอร์แมตใหม่ ให้ตรวจด้วย Bcrypt
      isMatch = await bcrypt.compare(old_password, dbPassword);
    }

    if (!isMatch) {
      return res.status(400).json({ message: 'รหัสผ่านเดิมไม่ถูกต้อง' });
    }

    // 3. 🛡️ เข้ารหัสผ่านใหม่ด้วย Bcrypt (แฮกไม่ได้)
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(new_password, saltRounds);

    // 4. บันทึกรหัสผ่านใหม่ที่ปลอดภัยแล้วลงฐานข้อมูล
    await db.execute('UPDATE user SET password = ? WHERE user_key = ?', [hashedPassword, user_key]);

    res.json({ message: 'เปลี่ยนรหัสผ่านสำเร็จ และอัปเกรดความปลอดภัยแล้ว!' });
    
  } catch (error) {
    console.error('Password Update Error:', error);
    res.status(500).json({ message: 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' });
  }
});

module.exports = router;