const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { uploadAvatar } = require('../utils/upload');

router.post('/login', userController.login);
router.post('/register', authenticateToken, requireRole(['admin']), userController.register);
router.get('/', authenticateToken, requireRole(['admin']), userController.getUsers);
router.put('/profile', authenticateToken, userController.updateProfile);
router.post('/upload-avatar', authenticateToken, uploadAvatar.single('avatar'), userController.uploadAvatar);
router.put('/password', authenticateToken, userController.updatePassword);
router.get('/technicians', authenticateToken, userController.getTechnicians);
router.put('/:id', authenticateToken, requireRole(['admin']), userController.updateUser);
router.delete('/:id', authenticateToken, requireRole(['admin']), userController.deleteUser);

module.exports = router;
