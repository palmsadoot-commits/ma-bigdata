const errorHandler = (err, req, res, next) => {
    // บันทึก Error ลง Console สำหรับ Programmer
    console.error("❌ System Error:", {
        message: err.message,
        stack: err.stack,
        path: req.url,
        method: req.method
    });

    const isDevelopment = process.env.NODE_ENV === 'development';

    res.status(err.status || 500).json({
        error: 'Server Error',
        message: err.message || 'เกิดข้อผิดพลาดภายในเซิร์ฟเวอร์',
        // ✅ ส่งรายละเอียดเชิงลึกเฉพาะในโหมด Development เท่านั้น
        details: isDevelopment ? (err.details || err.stack) : 'กรุณาติดต่อผู้ดูแลระบบ'
    });
};

module.exports = errorHandler;
