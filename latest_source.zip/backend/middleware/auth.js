const jwt = require('jsonwebtoken');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; 

    if (!token) {
        console.log(`[Auth] No token provided for ${req.method} ${req.url}`);
        return res.status(401).json({ error: 'Access Denied: กรุณาเข้าสู่ระบบก่อน' });
    }

    const secret = process.env.JWT_SECRET;
    if (!secret || secret === 'fallback_secret') {
        console.warn('⚠️ SECURITY WARNING: JWT_SECRET is missing or insecure! Please set a strong secret in .env');
    }

    jwt.verify(token, secret || 'fallback_secret', (err, user) => {
        if (err) {
            console.log(`[Auth] Token verification failed: ${err.message}`);
            return res.status(403).json({ error: 'Token หมดอายุหรือไม่ถูกต้อง กรุณาล็อกอินใหม่' });
        }
        req.user = user; 
        next();
    });
};

const requireRole = (roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Forbidden: คุณไม่มีสิทธิ์เข้าถึงหรือแก้ไขข้อมูลส่วนนี้!' });
        }
        next();
    };
};

module.exports = { authenticateToken, requireRole };
