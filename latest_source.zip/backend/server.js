const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const multer = require('multer'); 
const path = require('path');     

require('dotenv').config({ path: path.join(__dirname, '.env') });

const bcrypt = require('bcrypt'); 
const crypto = require('crypto'); 
const fs = require('fs');         

const cron = require('node-cron');
const { exec } = require('child_process');
const jwt = require('jsonwebtoken');

const archiver = require('archiver');
const simpleGit = require('simple-git');

const app = express();

app.use(cors());
app.use(express.json()); 
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/backups', express.static(path.join(__dirname, 'backups'))); 

// ✅ เพิ่มโฟลเดอร์ backups/database เข้าไปในระบบ
const dirs = ['uploads/', 'uploads/avatars/', 'backups/', 'backups/database/', 'backups/source/', 'backups/github_sync/'];
dirs.forEach(dir => {
    if (!fs.existsSync(path.join(__dirname, dir))) fs.mkdirSync(path.join(__dirname, dir), { recursive: true });
});

const storage = multer.diskStorage({
    destination: function (req, file, cb) { cb(null, 'uploads/') },
    filename: function (req, file, cb) { cb(null, Date.now() + path.extname(file.originalname)) }
});
const upload = multer({ storage: storage });

const avatarStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const dir = 'uploads/avatars/';
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
    },
    filename: function (req, file, cb) {
        const userId = req.body.user_id || 'unknown';
        cb(null, `avatar-${userId}-${Date.now()}${path.extname(file.originalname)}`)
    }
});
const uploadAvatar = multer({ storage: avatarStorage });

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

db.getConnection()
    .then(() => console.log('✅ Connected to MySQL Database successfully!'))
    .catch((err) => console.error('❌ Database connection failed:', err.message));

// ==========================================
// 🛡️ Middleware: ยามรักษาความปลอดภัย API
// ==========================================
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; 

    if (!token) return res.status(401).json({ error: 'Access Denied: กรุณาเข้าสู่ระบบก่อน' });

    jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret', (err, user) => {
        if (err) return res.status(403).json({ error: 'Token หมดอายุหรือไม่ถูกต้อง กรุณาล็อกอินใหม่' });
        req.user = user; 
        next();
    });
};

const requireRole = (roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Forbidden: คุณไม่มีสิทธิ์เข้าถึงหรือแก้ไขข้อมูลส่วนนี้!' });
        }
        next();
    };
};

app.get('/', (req, res) => { res.send('LIMS Ticketing System API is running...'); });

// ==========================================
// 🗂️ API: หมวดหมู่ / ระบบ (Categories)
// ==========================================
app.get('/api/categories', authenticateToken, async (req, res) => {
    try {
        const sql = `SELECT c.*, p.project_name FROM categories c LEFT JOIN projects p ON c.project_id = p.project_id ORDER BY c.category_id DESC`;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch categories' }); }
});

app.post('/api/categories', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { category_name, category_type, project_id } = req.body;
    try {
        await db.query(`INSERT INTO categories (category_name, category_type, project_id) VALUES (?, ?, ?)`, [category_name, category_type || null, project_id || null]);
        res.json({ success: true, message: 'เพิ่มหมวดหมู่เรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถเพิ่มหมวดหมู่ได้' }); }
});

app.put('/api/categories/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { category_name, category_type, project_id } = req.body;
    try {
        await db.query(`UPDATE categories SET category_name = ?, category_type = ?, project_id = ? WHERE category_id = ?`, [category_name, category_type || null, project_id || null, req.params.id]);
        res.json({ success: true, message: 'อัปเดตหมวดหมู่เรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถอัปเดตหมวดหมู่ได้' }); }
});

app.delete('/api/categories/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        await db.query('DELETE FROM categories WHERE category_id = ?', [req.params.id]);
        res.json({ success: true, message: 'ลบหมวดหมู่เรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถลบได้' }); }
});

// ==========================================
// 🗂️ API: จัดการประเภทและหัวตาราง (Category Types)
// ==========================================
app.get('/api/category-types', authenticateToken, async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM category_types ORDER BY type_id ASC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch category types' }); }
});

app.post('/api/category-types', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { type_code, type_name } = req.body;
    try {
        await db.query(`INSERT INTO category_types (type_code, type_name) VALUES (?, ?)`, [type_code, type_name]);
        res.json({ success: true, message: 'เพิ่มประเภทเรียบร้อย' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถเพิ่มได้ (ชื่อ Type อาจซ้ำ)' }); }
});

app.put('/api/category-types/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { type_code, type_name } = req.body;
    try {
        // อัปเดตข้อมูล categories เดิมที่ผูกกับ type_code เก่าให้เป็น type_code ใหม่ด้วย
        const [oldRows] = await db.query('SELECT type_code FROM category_types WHERE type_id = ?', [req.params.id]);
        if (oldRows.length > 0) {
            await db.query(`UPDATE categories SET category_type = ? WHERE category_type = ?`, [type_code, oldRows[0].type_code]);
        }
        await db.query(`UPDATE category_types SET type_code = ?, type_name = ? WHERE type_id = ?`, [type_code, type_name, req.params.id]);
        res.json({ success: true, message: 'อัปเดตประเภทเรียบร้อย' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถอัปเดตได้' }); }
});

app.delete('/api/category-types/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        await db.query('DELETE FROM category_types WHERE type_id = ?', [req.params.id]);
        res.json({ success: true, message: 'ลบประเภทเรียบร้อย' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถลบได้' }); }
});

// ==========================================
// 🗂️ API: จัดการโครงการ (Projects) 
// ==========================================
app.get('/api/projects', authenticateToken, async (req, res) => {
    try {
        const sql = `SELECT * FROM projects ORDER BY project_id DESC`;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch projects' }); }
});

app.post('/api/projects', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { project_name, project_contract, description } = req.body;
    try {
        await db.query(`INSERT INTO projects (project_name, project_contract, description) VALUES (?, ?, ?)`, [project_name, project_contract || null, description || null]);
        res.json({ success: true, message: 'เพิ่มโครงการเรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถเพิ่มโครงการได้' }); }
});

app.put('/api/projects/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    const projId = req.params.id; 
    const { project_name, project_contract, description } = req.body;
    try {
        await db.query(`UPDATE projects SET project_name = ?, project_contract = ?, description = ? WHERE project_id = ?`, [project_name, project_contract || null, description || null, projId]);
        res.json({ success: true, message: 'อัปเดตโครงการเรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถอัปเดตโครงการได้' }); }
});

app.delete('/api/projects/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    const projId = req.params.id;
    try {
        const [cats] = await db.query('SELECT COUNT(*) as count FROM categories WHERE project_id = ?', [projId]);
        if (cats[0].count > 0) return res.status(400).json({ error: 'ไม่สามารถลบได้ เนื่องจากมีหมวดหมู่ผูกอยู่' });

        await db.query('DELETE FROM projects WHERE project_id = ?', [projId]);
        res.json({ success: true, message: 'ลบโครงการเรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถลบโครงการได้' }); }
});

// ==========================================
// API: สร้างใบงาน (เปิด Ticket & คำนวณ SLA Deadline)
// ==========================================
app.post('/api/tickets', authenticateToken, upload.single('attachment'), async (req, res) => {
    try {
        const { reporter_id, category_id, equipment_no, software_no, problem_detail, is_cm, sla_hours } = req.body;
        const attachment = req.file ? req.file.filename : null;

        if (!reporter_id || !category_id || !problem_detail) {
            return res.status(400).json({ error: 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน' });
        }

        // 1. สร้างเลขใบงาน (Format: ลำดับ/พ.ศ.)
        const currentYearBE = new Date().getFullYear() + 543; 
        const [rows] = await db.query('SELECT COUNT(*) as count FROM tickets WHERE ticket_number LIKE ?', [`%/${currentYearBE}`]);
        const ticket_number = `${rows[0].count + 1}/${currentYearBE}`; 

        // 2. ดึง Project ID และค้นหาว่าบริษัทผู้รับจ้าง (Vendor) ของโครงการนี้คือใคร
        const [catRows] = await db.query('SELECT project_id FROM categories WHERE category_id = ?', [category_id]);
        const projectId = catRows[0]?.project_id;
        let vendorId = null;
        
        if (projectId) {
            const [contractRows] = await db.query('SELECT vendor_id FROM contracts WHERE project_id = ? ORDER BY contract_id DESC LIMIT 1', [projectId]);
            if (contractRows.length > 0) vendorId = contractRows[0].vendor_id;
        }

        // 3. บันทึกลง Database พร้อมกำหนด SLA Deadline (บวกชั่วโมงเข้าไปจากเวลาปัจจุบัน)
        // ถ้า is_cm = 1 จะตั้งเวลา sla_deadline เป็นเวลาปัจจุบัน + sla_hours
        await db.query(
            `INSERT INTO tickets (ticket_number, reporter_id, category_id, equipment_no, software_no, problem_detail, status, attachment, is_cm, sla_hours, sla_deadline, vendor_id, created_at) 
             VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?, IF(? = '1', DATE_ADD(NOW(), INTERVAL ? HOUR), NULL), ?, NOW())`, 
            [ticket_number, reporter_id, category_id, equipment_no, software_no, problem_detail, attachment, is_cm || 0, sla_hours || 0, is_cm || 0, sla_hours || 0, vendorId]
        );

        res.status(201).json({ message: 'บันทึกใบแจ้งซ่อมสำเร็จ!', ticket_number: ticket_number });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'เกิดข้อผิดพลาดในการบันทึกข้อมูล' }); 
    }
});

// ==========================================
// API: อัปเดตสถานะงาน และ คำนวณค่าปรับ (SLA Penalty Logic)
// ==========================================
app.put('/api/tickets/:id/update-status', authenticateToken, upload.array('attachments', 10), async (req, res) => {
    const ticket_id = req.params.id;
    const { status, technician_id, root_cause_and_solution } = req.body;

    try {
        // 1. ดึงข้อมูล Ticket ปัจจุบันขึ้นมาตรวจสอบ
        const [ticketRows] = await db.query(`
            SELECT t.*, c.project_id 
            FROM tickets t 
            LEFT JOIN categories c ON t.category_id = c.category_id 
            WHERE t.ticket_id = ?`, [ticket_id]
        );
        const ticket = ticketRows[0];

        let penaltyAmount = 0.00;
        let isBreached = 0;

        // 2. ถ้าเปลี่ยนสถานะเป็น Resolved (แก้ปัญหาเสร็จ) ให้คำนวณ SLA
        if (status === 'Resolved' && ticket.is_cm === 1 && ticket.sla_deadline) {
            
            // ดึงเวลาที่ส่งมา (เวลาปัจจุบันจาก DB) มาเทียบกับ Deadline
            const [timeCheck] = await db.query('SELECT NOW() as current_time_db');
            const resolvedAt = new Date(timeCheck[0].current_time_db);
            const deadline = new Date(ticket.sla_deadline);

            // ถ้าเวลาที่แก้เสร็จ ทะลุ Deadline -> "โดนปรับ!"
            if (resolvedAt > deadline) {
                isBreached = 1;

                // คำนวณจำนวนวันที่ล่าช้า (เศษของวันปัดขึ้นเป็น 1 วัน ตาม TOR)
                const delayMs = resolvedAt - deadline;
                const delayDays = Math.ceil(delayMs / (1000 * 60 * 60 * 24));

                // 2.1 ดึงมูลค่าสัญญา และ Rate ค่าปรับ (0.1%)
                const [contractRows] = await db.query(`SELECT contract_value, penalty_rate FROM contracts WHERE project_id = ? AND vendor_id = ? ORDER BY contract_id DESC LIMIT 1`, [ticket.project_id, ticket.vendor_id]);
                
                // 2.2 ดึงค่าตัวถ่วงของอุปกรณ์ (ถ้าไม่เจอให้ default = 1.0)
                const [eqRows] = await db.query(`SELECT weighting_factor FROM equipments WHERE serial_number = ? LIMIT 1`, [ticket.equipment_no]);
                const weight = eqRows.length > 0 ? parseFloat(eqRows[0].weighting_factor) : 1.0;

                // 2.3 ดึงผลรวมค่าตัวถ่วงทั้งหมดในโครงการ
                const [totalWeightRows] = await db.query(`SELECT SUM(weighting_factor) as total_weight FROM equipments e JOIN categories c ON e.category_id = c.category_id WHERE c.project_id = ?`, [ticket.project_id]);
                const totalWeight = totalWeightRows[0].total_weight || 1.0;

                if (contractRows.length > 0) {
                    const contractValue = parseFloat(contractRows[0].contract_value);
                    const penaltyRate = parseFloat(contractRows[0].penalty_rate); // 0.001

                    // 🧮 สูตรคำนวณตาม TOR: 
                    // มูลค่าระบบที่เสีย = มูลค่าสัญญา x (ค่าตัวถ่วง / ผลรวมค่าตัวถ่วง)
                    const systemValue = contractValue * (weight / totalWeight);
                    
                    // ค่าปรับต่อวัน = มูลค่าระบบที่เสีย x 0.1%
                    const penaltyPerDay = systemValue * penaltyRate;

                    // ค่าปรับสุทธิ = ค่าปรับต่อวัน x จำนวนวันที่ล่าช้า
                    penaltyAmount = penaltyPerDay * delayDays;
                }
            }

            // บันทึกเวลาที่แก้เสร็จและค่าปรับลง Database
            await db.query(
                `UPDATE tickets SET status = ?, resolved_at = NOW(), is_sla_breached = ?, penalty_amount = ? WHERE ticket_id = ?`, 
                [status, isBreached, penaltyAmount, ticket_id]
            );
        } else {
            // ถ้าไม่ได้อัปเดตเป็น Resolved หรือไม่ใช่ CM ก็แค่อัปเดต Status ธรรมดา
            await db.query('UPDATE tickets SET status = ? WHERE ticket_id = ?', [status, ticket_id]);
        }

        // 3. บันทึกวิธีแก้ไข (Resolution)
        if (status === 'Resolved' && root_cause_and_solution) {
            const [existing] = await db.query(`SELECT * FROM ticket_resolutions WHERE ticket_id = ?`, [ticket_id]);
            if (existing.length > 0) {
                await db.query(`UPDATE ticket_resolutions SET root_cause_and_solution = ?, technician_id = ?, resolved_at = NOW() WHERE ticket_id = ?`, [root_cause_and_solution, technician_id, ticket_id]);
            } else {
                await db.query(`INSERT INTO ticket_resolutions (ticket_id, technician_id, root_cause_and_solution, resolved_at) VALUES (?, ?, ?, NOW())`, [ticket_id, technician_id, root_cause_and_solution]);
            }
        }

        // 4. บันทึกไฟล์แนบ (ถ้ามี)
        let savedFiles = [];
        if (req.files && req.files.length > 0) {
            for (let file of req.files) {
                await db.query(`INSERT INTO ticket_attachments (ticket_id, file_name, file_path, uploaded_by) VALUES (?, ?, ?, ?)`, [ticket_id, file.originalname, file.filename, technician_id]);
                savedFiles.push(file.filename); 
            }
        }

        res.json({ 
            success: true, 
            files: savedFiles, 
            message: isBreached ? `งานสำเร็จล่าช้าเกินกำหนด! มีค่าปรับ: ${penaltyAmount.toLocaleString()} บาท` : 'อัปเดตสถานะและบันทึกข้อมูลสำเร็จ',
            is_breached: isBreached,
            penalty_amount: penaltyAmount
        });

    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'เกิดข้อผิดพลาดในการอัปเดตข้อมูล' }); 
    }
});

app.get('/api/tickets', authenticateToken, async (req, res) => {
    const project_id = req.query.project_id; 
    try {
        let sql = `SELECT t.ticket_id, t.ticket_number, t.equipment_no, t.problem_detail, t.status, t.created_at, t.attachment, c.category_name, CONCAT(u.first_name, ' ', u.last_name) AS reporter_name FROM tickets t LEFT JOIN categories c ON t.category_id = c.category_id LEFT JOIN users u ON t.reporter_id = u.user_id`;
        let params = [];
        if (project_id) { sql += ' WHERE c.project_id = ?'; params.push(project_id); }
        sql += ' ORDER BY t.created_at DESC';

        const [rows] = await db.query(sql, params);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch tickets' }); }
});

app.get('/api/tickets/:id', authenticateToken, async (req, res) => {
    const ticket_id = req.params.id;
    try {
        const sql = `SELECT t.*, c.category_name, c.category_type, CONCAT(u.first_name, ' ', u.last_name) AS reporter_name, u.agency AS reporter_department, u.phone_number AS reporter_phone, tr.root_cause_and_solution, tr.resolved_at, CONCAT(tech.first_name, ' ', tech.last_name) AS technician_name, CONCAT(a.first_name, ' ', a.last_name) AS assigned_to_name FROM tickets t LEFT JOIN categories c ON t.category_id = c.category_id LEFT JOIN users u ON t.reporter_id = u.user_id LEFT JOIN ticket_resolutions tr ON t.ticket_id = tr.ticket_id LEFT JOIN users tech ON tr.technician_id = tech.user_id LEFT JOIN users a ON t.assigned_to = a.user_id WHERE t.ticket_id = ?`;
        const [rows] = await db.query(sql, [ticket_id]);
        if (rows.length === 0) return res.status(404).json({ error: 'ไม่พบข้อมูลใบแจ้งซ่อม' });
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch ticket details' }); }
});

// ==========================================
// API: ระบบเข้าสู่ระบบ และ ผู้ใช้งาน
// ==========================================
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const [rows] = await db.query(`SELECT * FROM users WHERE username = ?`, [username]);
        if (rows.length === 0) return res.status(401).json({ error: 'ชื่อผู้ใช้งานไม่ถูกต้อง!' });

        const user = rows[0];
        let isMatch = false;

        if (user.password_hash.length === 32) {
            isMatch = (crypto.createHash('md5').update(password).digest('hex') === user.password_hash);
        } else {
            isMatch = await bcrypt.compare(password, user.password_hash);
        }

        if (!isMatch) return res.status(401).json({ error: 'รหัสผ่านไม่ถูกต้อง!' });
        
        const token = jwt.sign(
            { user_id: user.user_id, username: user.username, role: user.role }, 
            process.env.JWT_SECRET || 'fallback_secret', 
            { expiresIn: '12h' }
        );

        delete user.password_hash; 
        user.token = token; 

        res.json({ success: true, user: user });
    } catch (err) { res.status(500).json({ error: 'เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล' }); }
});

app.post('/api/register', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { username, password, first_name, last_name, role, project_id, agency } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        await db.query(`INSERT INTO users (username, password_hash, first_name, last_name, role, project_id, agency) VALUES (?, ?, ?, ?, ?, ?, ?)`, [username, hashedPassword, first_name, last_name, role, project_id || null, agency || null]);
        res.json({ success: true, message: 'User registered successfully' });
    } catch (err) { res.status(500).json({ error: 'Registration failed' }); }
});

app.get('/api/users', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const sql = `SELECT u.user_id, u.username, u.first_name, u.last_name, u.role, u.agency, u.project_id, u.user_photo, p.project_name FROM users u LEFT JOIN projects p ON u.project_id = p.project_id ORDER BY u.created_at DESC`;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch users' }); }
});

app.put('/api/users/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    const userId = req.params.id;
    const { first_name, last_name, agency, role, project_id, new_password } = req.body;
    try {
        let sql = `UPDATE users SET first_name = ?, last_name = ?, agency = ?, role = ?, project_id = ?`;
        let params = [first_name, last_name, agency, role, project_id || null];

        if (new_password && new_password.trim() !== '') {
            sql += `, password_hash = ?`;
            params.push(await bcrypt.hash(new_password, 10));
        }
        sql += ` WHERE user_id = ?`;
        params.push(userId);

        await db.query(sql, params);
        res.json({ success: true, message: 'อัปเดตข้อมูลสำเร็จ!' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถอัปเดตข้อมูลได้' }); }
});

app.delete('/api/users/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        await db.query('DELETE FROM users WHERE user_id = ?', [req.params.id]);
        res.json({ success: true, message: 'ลบผู้ใช้งานออกจากระบบเรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'เกิดข้อผิดพลาด ไม่สามารถลบผู้ใช้งานได้' }); }
});

app.put('/api/users/profile', authenticateToken, async (req, res) => {
    const { user_id, first_name, last_name, position, department, email, telephone, mobile } = req.body;
    try {
        const sql = `UPDATE users SET first_name = ?, last_name = ?, agency = ?, position = ?, email = ?, telephone = ?, mobile = ? WHERE user_id = ?`;
        const [result] = await db.query(sql, [first_name, last_name, department, position, email, telephone, mobile, user_id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'ไม่พบผู้ใช้งาน' });
        res.json({ success: true, message: 'อัปเดตข้อมูลส่วนตัวสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถอัปเดตข้อมูลได้' }); }
});

app.post('/api/users/upload-avatar', authenticateToken, uploadAvatar.single('avatar'), async (req, res) => {
    try {
        const { user_id } = req.body;
        if (!user_id || !req.file) return res.status(400).json({ error: 'กรุณาเลือกไฟล์ภาพ' });
        await db.query(`UPDATE users SET user_photo = ? WHERE user_id = ?`, [req.file.filename, user_id]);
        res.json({ success: true, filename: req.file.filename, message: 'อัปโหลดรูปโปรไฟล์สำเร็จ' });
    } catch (err) { res.status(500).json({ error: err.message || 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' }); }
});

app.put('/api/users/password', authenticateToken, async (req, res) => {
    const { user_id, old_password, new_password } = req.body;
    try {
        const [rows] = await db.query('SELECT password_hash FROM users WHERE user_id = ?', [user_id]);
        if (rows.length === 0) return res.status(404).json({ error: 'ไม่พบผู้ใช้งาน' });

        const dbPassword = rows[0].password_hash;
        let isMatch = false;

        if (dbPassword.length === 32) {
            isMatch = (crypto.createHash('md5').update(old_password).digest('hex') === dbPassword);
        } else {
            isMatch = await bcrypt.compare(old_password, dbPassword);
        }
        if (!isMatch) return res.status(400).json({ error: 'รหัสผ่านเดิมไม่ถูกต้อง' });

        await db.query('UPDATE users SET password_hash = ? WHERE user_id = ?', [await bcrypt.hash(new_password, 10), user_id]);
        res.json({ success: true, message: 'เปลี่ยนรหัสผ่านสำเร็จ!' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถเปลี่ยนรหัสผ่านได้' }); }
});

app.get('/api/technicians', authenticateToken, async (req, res) => {
    const project_id = req.query.project_id;
    try {
        let sql = `SELECT user_id, CONCAT(first_name, ' ', last_name) AS full_name FROM users WHERE role IN ('technician', 'head_technician') AND status = 'active'`;
        let params = [];
        if (project_id) { sql += ` AND project_id = ?`; params.push(project_id); }
        const [rows] = await db.query(sql, params);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch technicians' }); }
});

// ==========================================
// API: มอบหมายงาน / ช่างกดรับงาน (แสตมป์เวลา Acknowledge)
// ==========================================
app.put('/api/tickets/:id/assign', authenticateToken, async (req, res) => {
    const ticket_id = req.params.id;
    const { assigned_to } = req.body;
    try {
        // IF(acknowledged_at IS NULL, NOW(), acknowledged_at) หมายถึง ถ้าเพิ่งรับงานครั้งแรกให้แสตมป์เวลาปัจจุบัน
        await db.query(
            `UPDATE tickets SET 
                assigned_to = ?, 
                status = IF(status = 'Pending', 'In Progress', status),
                acknowledged_at = IF(acknowledged_at IS NULL, NOW(), acknowledged_at)
             WHERE ticket_id = ?`, 
            [assigned_to, ticket_id]
        );
        res.json({ success: true, message: 'มอบหมายงานและเริ่มจับเวลาเข้าพื้นที่สำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'Failed to assign ticket' }); }
});

app.put('/api/tickets/:id/return', authenticateToken, async (req, res) => {
    const ticket_id = req.params.id;
    try {
        await db.query(`UPDATE tickets SET assigned_to = NULL, status = 'Pending' WHERE ticket_id = ?`, [ticket_id]);
        res.json({ success: true, message: 'ตีกลับงานสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'Failed to return ticket' }); }
});

app.get('/api/tickets/:id/logs', authenticateToken, async (req, res) => {
    try {
        const [rows] = await db.query(`SELECT * FROM ticket_logs WHERE ticket_id = ? ORDER BY created_at ASC`, [req.params.id]);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch logs' }); }
});

app.post('/api/tickets/:id/logs', authenticateToken, async (req, res) => {
    const ticket_id = req.params.id;
    const { action, actor_name, detail } = req.body;
    try {
        await db.query(`INSERT INTO ticket_logs (ticket_id, action, actor_name, detail) VALUES (?, ?, ?, ?)`, [ticket_id, action, actor_name, detail]);
        res.json({ success: true, message: 'Log added successfully' });
    } catch (err) { res.status(500).json({ error: 'Failed to add log' }); }
});

// ==========================================
// 🏷️ API: จัดการป้ายสถานะ (Dynamic Ticket Statuses)
// ==========================================
app.get('/api/statuses', authenticateToken, async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM ticket_statuses ORDER BY sort_order ASC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch statuses' }); }
});

app.post('/api/statuses', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { status_name, status_color, sort_order } = req.body;
    try {
        await db.query(`INSERT INTO ticket_statuses (status_name, status_color, sort_order) VALUES (?, ?, ?)`, [status_name, status_color || 'blue', sort_order || 0]);
        res.json({ success: true, message: 'เพิ่มสถานะเรียบร้อย' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถเพิ่มสถานะได้' }); }
});

app.put('/api/statuses/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    const statusId = req.params.id;
    const { status_name, status_color, sort_order } = req.body;
    try {
        const [oldRows] = await db.query('SELECT status_name FROM ticket_statuses WHERE status_id = ?', [statusId]);
        if (oldRows.length === 0) return res.status(404).json({ error: 'ไม่พบสถานะนี้' });
        const oldStatusName = oldRows[0].status_name;

        await db.query(`UPDATE ticket_statuses SET status_name = ?, status_color = ?, sort_order = ? WHERE status_id = ?`, [status_name, status_color, sort_order, statusId]);

        if (oldStatusName !== status_name) {
            await db.query(`UPDATE tickets SET status = ? WHERE status = ?`, [status_name, oldStatusName]);
        }
        res.json({ success: true, message: 'อัปเดตสถานะเรียบร้อย' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถอัปเดตสถานะได้' }); }
});

app.delete('/api/statuses/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        await db.query('DELETE FROM ticket_statuses WHERE status_id = ?', [req.params.id]);
        res.json({ success: true, message: 'ลบสถานะเรียบร้อย' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถลบสถานะได้' }); }
});

// ==========================================
// 🛡️ API: ระบบสำรองข้อมูล (Database)
// ==========================================
const performBackup = async (triggerBy = 'System') => {
    return new Promise((resolve, reject) => {
        const thaiTime = new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Bangkok"}));
        const dd = String(thaiTime.getDate()).padStart(2, '0');
        const mm = String(thaiTime.getMonth() + 1).padStart(2, '0');
        const yyyy = thaiTime.getFullYear();
        const hh = String(thaiTime.getHours()).padStart(2, '0');
        const min = String(thaiTime.getMinutes()).padStart(2, '0');
        const ss = String(thaiTime.getSeconds()).padStart(2, '0');
        
        const fileName = `backup_${dd}-${mm}-${yyyy}_${hh}-${min}-${ss}.sql`;
        
        // ✅ เปลี่ยน Path ให้ไปบันทึกที่โฟลเดอร์ database
        const filePath = path.join(__dirname, 'backups', 'database', fileName);

        const dbUser = process.env.DB_USER;
        const dbPass = process.env.DB_PASSWORD ? `-p"${process.env.DB_PASSWORD}"` : '';
        const dbName = process.env.DB_NAME;
        const dbHost = process.env.DB_HOST;
        
        const dumpPath = process.env.MYSQL_DUMP_PATH || 'mysqldump';
        
        const dumpCmd = `"${dumpPath}" -h ${dbHost} -u ${dbUser} ${dbPass} ${dbName} --ignore-table=${dbName}.github_settings > "${filePath}"`;

        exec(dumpCmd, async (error, stdout, stderr) => {
            if (error) {
                if (fs.existsSync(filePath)) fs.unlinkSync(filePath); 
                await db.query(`INSERT INTO backup_logs (file_name, status, created_by) VALUES (?, 'Failed', ?)`, [fileName, triggerBy]);
                return reject(error);
            }
            const stats = fs.statSync(filePath);
            if (stats.size === 0) {
                fs.unlinkSync(filePath); 
                await db.query(`INSERT INTO backup_logs (file_name, status, created_by) VALUES (?, 'Failed (0 Byte)', ?)`, [fileName, triggerBy]);
                return reject(new Error('Backup file is 0 bytes'));
            }
            const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2) + ' MB';
            await db.query(`INSERT INTO backup_logs (file_name, file_size, status, created_by) VALUES (?, ?, 'Success', ?)`, [fileName, fileSizeMB, triggerBy]);
            resolve(fileName);
        });
    });
};

app.post('/api/backup/manual', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const fileName = await performBackup('Admin (Manual)');
        res.json({ success: true, message: 'สำรองข้อมูลสำเร็จ', file_name: fileName });
    } catch (error) { res.status(500).json({ error: 'การสำรองข้อมูลล้มเหลว', details: error.message }); }
});

app.get('/api/backup/logs', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM backup_logs ORDER BY created_at DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'ดึงข้อมูลไม่สำเร็จ' }); }
});

app.get('/api/backup/settings', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM backup_settings LIMIT 1');
        res.json(rows[0] || null);
    } catch (err) { res.status(500).json({ error: 'ดึงการตั้งค่าไม่สำเร็จ' }); }
});

app.put('/api/backup/settings', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { schedule_type, schedule_days, schedule_time, is_active } = req.body;
    try {
        await db.query(`UPDATE backup_settings SET schedule_type=?, schedule_days=?, schedule_time=?, is_active=? WHERE id=1`, 
            [schedule_type, schedule_days, schedule_time, is_active]);
        setupCronJob();
        res.json({ success: true, message: 'บันทึกการตั้งค่าสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'บันทึกไม่สำเร็จ' }); }
});

app.delete('/api/backup/:fileName', authenticateToken, requireRole(['admin']), async (req, res) => {
    const fileName = req.params.fileName;
    // ✅ เปลี่ยน Path การลบไฟล์
    const filePath = path.join(__dirname, 'backups', 'database', fileName);
    try {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath); 
        await db.query('DELETE FROM backup_logs WHERE file_name = ?', [fileName]); 
        res.json({ success: true, message: 'ลบไฟล์สำรองข้อมูลเรียบร้อยแล้ว' });
    } catch (error) { res.status(500).json({ error: 'ไม่สามารถลบไฟล์ได้', details: error.message }); }
});

app.post('/api/backup/restore', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { file_name } = req.body;
    // ✅ เปลี่ยน Path การดึงไฟล์มากู้คืน
    const filePath = path.join(__dirname, 'backups', 'database', file_name);

    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'ไม่พบไฟล์แบ็คอัพนี้' });

    const dbUser = process.env.DB_USER;
    const dbPass = process.env.DB_PASSWORD ? `-p"${process.env.DB_PASSWORD}"` : '';
    const dbName = process.env.DB_NAME;
    const dbHost = process.env.DB_HOST;

    const mysqlPath = process.env.MYSQL_PATH || 'mysql';
    const restoreCmd = `"${mysqlPath}" -h ${dbHost} -u ${dbUser} ${dbPass} ${dbName} < "${filePath}"`;

    exec(restoreCmd, async (error, stdout, stderr) => {
        if (error) return res.status(500).json({ error: 'การกู้คืนล้มเหลว ตรวจสอบ Path ใน .env', details: error.message });
        await db.query(`INSERT INTO backup_logs (file_name, file_size, status, created_by) VALUES (?, 'Restore', 'Success', 'Admin (Restore)')`, [file_name]);
        res.json({ success: true, message: 'กู้คืนฐานข้อมูลเรียบร้อยแล้ว' });
    });
});

// ==========================================
// 📦 API: ระบบสำรองข้อมูล (Source Code - ZIP)
// ==========================================
const performSourceBackup = async (triggerBy = 'System', targetFolders = ['frontend', 'backend']) => {
    return new Promise((resolve, reject) => {
        const thaiTime = new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Bangkok"}));
        const dd = String(thaiTime.getDate()).padStart(2, '0');
        const mm = String(thaiTime.getMonth() + 1).padStart(2, '0');
        const yyyy = thaiTime.getFullYear();
        const hh = String(thaiTime.getHours()).padStart(2, '0');
        const min = String(thaiTime.getMinutes()).padStart(2, '0');
        const ss = String(thaiTime.getSeconds()).padStart(2, '0');
        
        const fileName = `src_${dd}-${mm}-${yyyy}_${hh}-${min}-${ss}.zip`;
        const filePath = path.join(__dirname, 'backups', 'source', fileName);

        const output = fs.createWriteStream(filePath);
        const archive = archiver('zip', { zlib: { level: 9 } });

        output.on('close', async () => {
            const stats = fs.statSync(filePath);
            const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2) + ' MB';
            const foldersStr = targetFolders.join(',');
            await db.query(`INSERT INTO source_backup_logs (file_name, target_folders, file_size, status, created_by) VALUES (?, ?, ?, 'Success', ?)`, [fileName, foldersStr, fileSizeMB, triggerBy]);
            resolve(fileName);
        });

        archive.on('error', async (err) => {
            if (fs.existsSync(filePath)) fs.unlinkSync(filePath); 
            await db.query(`INSERT INTO source_backup_logs (file_name, status, created_by) VALUES (?, 'Failed', ?)`, [fileName, triggerBy]);
            reject(err);
        });

        archive.pipe(output);

        const includeNodeModules = targetFolders.includes('node_modules');
        const ignorePattern = includeNodeModules ? [] : ['**/node_modules/**'];

        const backendPath = __dirname;
        const frontendPath = path.join(__dirname, '../frontend'); 

        if (targetFolders.includes('backend')) {
            archive.glob('**/*', { cwd: backendPath, ignore: [...ignorePattern, 'backups/**', 'uploads/**'] }, { prefix: 'backend' });
        }

        if (targetFolders.includes('frontend') && fs.existsSync(frontendPath)) {
            archive.glob('**/*', { cwd: frontendPath, ignore: ignorePattern }, { prefix: 'frontend' });
        }

        archive.finalize();
    });
};

app.post('/api/backup/source/manual', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const { target_folders } = req.body;
        const foldersToBackup = (target_folders && target_folders.length > 0) ? target_folders : ['frontend', 'backend'];
        const fileName = await performSourceBackup('Admin (Manual)', foldersToBackup);
        res.json({ success: true, message: 'บีบอัด Source Code สำเร็จ', file_name: fileName });
    } catch (error) { 
        res.status(500).json({ error: 'การสำรองข้อมูลล้มเหลว', details: error.message }); 
    }
});

app.get('/api/backup/source/logs', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM source_backup_logs ORDER BY created_at DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'ดึงข้อมูลไม่สำเร็จ' }); }
});

app.get('/api/backup/source/settings', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM source_backup_settings LIMIT 1');
        res.json(rows[0] || null);
    } catch (err) { res.status(500).json({ error: 'ดึงการตั้งค่าไม่สำเร็จ' }); }
});

app.put('/api/backup/source/settings', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { target_folders, schedule_type, schedule_days, schedule_time, is_active } = req.body;
    try {
        await db.query(`UPDATE source_backup_settings SET target_folders=?, schedule_type=?, schedule_days=?, schedule_time=?, is_active=? WHERE id=1`, 
            [target_folders, schedule_type, schedule_days, schedule_time, is_active]);
        setupSourceCronJob();
        res.json({ success: true, message: 'บันทึกการตั้งค่าสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'บันทึกไม่สำเร็จ' }); }
});

app.delete('/api/backup/source/:fileName', authenticateToken, requireRole(['admin']), async (req, res) => {
    const fileName = req.params.fileName;
    const filePath = path.join(__dirname, 'backups', 'source', fileName);
    try {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath); 
        }
        await db.query('DELETE FROM source_backup_logs WHERE file_name = ?', [fileName]); 
        res.json({ success: true, message: 'ลบไฟล์ Zip เรียบร้อยแล้ว' });
    } catch (error) { 
        res.status(500).json({ error: 'ไม่สามารถลบไฟล์ได้', details: error.message }); 
    }
});


// ==========================================
// 🐙 API: GitHub Sync (แท็บ 3)
// ==========================================
const performGithubSync = async (triggerBy = 'System', syncTargets = ['database', 'source']) => {
    return new Promise(async (resolve, reject) => {
        try {
            const [rows] = await db.query('SELECT * FROM github_settings WHERE id = 1');
            if (rows.length === 0 || !rows[0].github_token || !rows[0].repo_url) {
                throw new Error('กรุณาตั้งค่า GitHub Token และ Repository URL ให้ครบถ้วนก่อน');
            }
            const settings = rows[0];
            
            let cleanUrl = settings.repo_url.trim();
            if (cleanUrl.endsWith('/')) cleanUrl = cleanUrl.slice(0, -1);
            if (!cleanUrl.endsWith('.git')) cleanUrl += '.git';

            const repoUrlWithAuth = cleanUrl.replace('https://', `https://${settings.github_token}@`);
            const branchName = settings.branch_name || 'main';
            
            const syncDir = path.join(__dirname, 'backups', 'github_sync');
            if (!fs.existsSync(syncDir)) fs.mkdirSync(syncDir, { recursive: true });

            const git = simpleGit(syncDir);
            
            const isRepo = await git.checkIsRepo();
            if (!isRepo) {
                await git.init();
            }

            const remotes = await git.getRemotes();
            if (remotes.some(r => r.name === 'origin')) {
                await git.remote(['set-url', 'origin', repoUrlWithAuth]);
            } else {
                await git.addRemote('origin', repoUrlWithAuth);
            }

            await git.addConfig('user.name', 'LIMS Auto Backup Bot');
            await git.addConfig('user.email', 'backup@lims.local');

            let filesCopied = false;

            // ✅ เปลี่ยนแปลง: เข้าไปดึงไฟล์ SQL จากโฟลเดอร์ backups/database/ แทน
            if (syncTargets.includes('database')) {
                const dbBackupDir = path.join(__dirname, 'backups', 'database');
                const files = fs.readdirSync(dbBackupDir).filter(f => f.endsWith('.sql'));
                if (files.length > 0) {
                    files.sort((a, b) => fs.statSync(path.join(dbBackupDir, b)).mtimeMs - fs.statSync(path.join(dbBackupDir, a)).mtimeMs);
                    fs.copyFileSync(path.join(dbBackupDir, files[0]), path.join(syncDir, 'latest_database.sql'));
                    filesCopied = true;
                }
            }
            
            if (syncTargets.includes('source')) {
                const files = fs.readdirSync(path.join(__dirname, 'backups', 'source')).filter(f => f.endsWith('.zip'));
                if (files.length > 0) {
                    files.sort((a, b) => fs.statSync(path.join(__dirname, 'backups', 'source', b)).mtimeMs - fs.statSync(path.join(__dirname, 'backups', 'source', a)).mtimeMs);
                    fs.copyFileSync(path.join(__dirname, 'backups', 'source', files[0]), path.join(syncDir, 'latest_source.zip'));
                    filesCopied = true;
                }
            }

            const timeStr = new Date().toLocaleString("en-US", {timeZone: "Asia/Bangkok"});
            fs.writeFileSync(path.join(syncDir, 'sync_info.txt'), `Last Sync: ${timeStr}\nTriggered by: ${triggerBy}`);

            await git.add('-A');
            const status = await git.status();
            
            if (status.isClean()) {
                await db.query(`INSERT INTO github_sync_logs (sync_targets, status, created_by) VALUES (?, 'สำเร็จ (ไม่มีไฟล์เปลี่ยนแปลง)', ?)`, [syncTargets.join(','), triggerBy]);
                return resolve('ไม่มีไฟล์เปลี่ยนแปลง');
            }
            
            await git.commit(`Auto Backup Sync: ${timeStr}`);
            await git.branch(['-M', branchName]);
            await git.push('origin', branchName, { '--force': null }); 

            await db.query(`INSERT INTO github_sync_logs (sync_targets, status, created_by) VALUES (?, 'สำเร็จ', ?)`, [syncTargets.join(','), triggerBy]);
            resolve('Sync สำเร็จ');
            
        } catch (error) {
            const errMsg = error.message.substring(0, 150);
            await db.query(`INSERT INTO github_sync_logs (sync_targets, status, created_by) VALUES (?, ?, ?)`, [syncTargets.join(','), `ล้มเหลว: ${errMsg}`, triggerBy]);
            reject(error);
        }
    });
};

app.post('/api/github/manual', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const syncTargets = req.body.sync_targets || ['database', 'source'];
        await performGithubSync('Admin (Manual)', syncTargets);
        res.json({ success: true, message: 'Push ข้อมูลขึ้น GitHub สำเร็จ' });
    } catch (error) { 
        res.status(500).json({ error: error.message }); 
    }
});

app.get('/api/github/logs', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM github_sync_logs ORDER BY created_at DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/github/settings', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM github_settings LIMIT 1');
        res.json(rows[0] || null);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/github/settings', authenticateToken, requireRole(['admin']), async (req, res) => {
    const { github_token, repo_url, branch_name, sync_targets, schedule_type, schedule_days, schedule_time, is_active } = req.body;
    try {
        await db.query(`UPDATE github_settings SET github_token=?, repo_url=?, branch_name=?, sync_targets=?, schedule_type=?, schedule_days=?, schedule_time=?, is_active=? WHERE id=1`, 
            [github_token, repo_url, branch_name, sync_targets, schedule_type, schedule_days, schedule_time, is_active]);
        setupGithubCronJob();
        res.json({ success: true, message: 'บันทึกการตั้งค่า GitHub สำเร็จ' });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/github/logs/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
    const logId = req.params.id;
    try {
        const [result] = await db.query('DELETE FROM github_sync_logs WHERE log_id = ?', [logId]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'ไม่พบประวัตินี้ในระบบ' });
        }
        
        res.json({ success: true, message: 'ลบประวัติการ Push เรียบร้อยแล้ว' });
    } catch (error) { 
        res.status(500).json({ error: 'ไม่สามารถลบประวัติได้', details: error.message }); 
    }
});

// ==========================================
// ⏰ ระบบ Cron Job สำหรับรัน Auto Backup
// ==========================================
let activeCronJob = null; 
const setupCronJob = async () => {
    try {
        if (activeCronJob) { activeCronJob.stop(); }

        const [rows] = await db.query('SELECT * FROM backup_settings WHERE id = 1 AND is_active = 1');
        if (rows.length === 0) return;

        const setting = rows[0];
        const [hour, minute] = setting.schedule_time.split(':');
        
        let cronExp = `${minute} ${hour} * * *`;
        if (setting.schedule_type === 'weekly' && setting.schedule_days) {
            cronExp = `${minute} ${hour} * * ${setting.schedule_days}`; 
        } else if (setting.schedule_type === 'monthly' && setting.schedule_days) {
            cronExp = `${minute} ${hour} ${setting.schedule_days} * *`; 
        }

        activeCronJob = cron.schedule(cronExp, () => {
            performBackup('Auto Schedule');
        });
        console.log(`⏱️ Auto DB Backup Scheduled: ${cronExp}`);

    } catch (err) { console.error('❌ Failed to setup DB Cron Job:', err.message); }
};

let activeSourceCronJob = null; 
const setupSourceCronJob = async () => {
    try {
        if (activeSourceCronJob) { activeSourceCronJob.stop(); }

        const [rows] = await db.query('SELECT * FROM source_backup_settings WHERE id = 1 AND is_active = 1');
        if (rows.length === 0) return;

        const setting = rows[0];
        const [hour, minute] = setting.schedule_time.split(':');
        
        let cronExp = `${minute} ${hour} * * *`;
        if (setting.schedule_type === 'weekly' && setting.schedule_days) {
            cronExp = `${minute} ${hour} * * ${setting.schedule_days}`; 
        } else if (setting.schedule_type === 'monthly' && setting.schedule_days) {
            cronExp = `${minute} ${hour} ${setting.schedule_days} * *`; 
        }

        activeSourceCronJob = cron.schedule(cronExp, () => {
            const folders = setting.target_folders ? setting.target_folders.split(',') : ['frontend', 'backend'];
            performSourceBackup('Auto Schedule', folders);
        });
        console.log(`⏱️ Auto Source Backup Scheduled: ${cronExp}`);

    } catch (err) { console.error('❌ Failed to setup Source Cron Job:', err.message); }
};

let activeGithubCronJob = null; 
const setupGithubCronJob = async () => {
    try {
        if (activeGithubCronJob) { activeGithubCronJob.stop(); }
        const [rows] = await db.query('SELECT * FROM github_settings WHERE id = 1 AND is_active = 1');
        if (rows.length === 0) return;
        const setting = rows[0];
        const [hour, minute] = setting.schedule_time.split(':');
        let cronExp = `${minute} ${hour} * * *`;
        if (setting.schedule_type === 'weekly' && setting.schedule_days) cronExp = `${minute} ${hour} * * ${setting.schedule_days}`; 
        else if (setting.schedule_type === 'monthly' && setting.schedule_days) cronExp = `${minute} ${hour} ${setting.schedule_days} * *`; 
        
        activeGithubCronJob = cron.schedule(cronExp, () => {
            const targets = setting.sync_targets ? setting.sync_targets.split(',') : ['database', 'source'];
            performGithubSync('Auto Schedule', targets);
        });
        console.log(`⏱️ Auto GitHub Sync Scheduled: ${cronExp}`);
    } catch (err) { console.error('❌ Failed to setup GitHub Cron Job:', err.message); }
};

// ==========================================
// เปิดใช้งาน Server
// ==========================================
const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
    console.log(`🚀 Server is running on port ${PORT}`);
    await setupCronJob();
    await setupSourceCronJob();
    await setupGithubCronJob();
});