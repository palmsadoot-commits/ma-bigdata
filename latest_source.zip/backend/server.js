const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const errorHandler = require('./middleware/errorHandler');
const cronService = require('./services/cronService');
const { authenticateToken, requireRole } = require('./middleware/auth');

const app = express();

// --- 1. Basic Middlewares ---
app.use(express.json()); 
app.use(express.urlencoded({ extended: true }));

// --- 2. Advanced Security ---
app.use(cors({
    origin: true, 
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true
}));

app.use((req, res, next) => {
    if (req.method === 'OPTIONS') return res.sendStatus(200);
    next();
});

app.use(helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" }, 
    contentSecurityPolicy: false, 
}));

const { simpleSanitize } = require('./utils/dataHelper');
app.use((req, res, next) => {
    const sanitize = (obj) => {
        if (typeof obj !== 'object' || obj === null) return;
        for (let key in obj) {
            if (typeof obj[key] === 'string') obj[key] = simpleSanitize(obj[key]);
        }
    };
    if (req.method === 'POST' || req.method === 'PUT') {
        if (req.body) sanitize(req.body);
    }
    if (req.query) sanitize(req.query);
    next();
});

const limiter = rateLimit({
    windowMs: 5 * 60 * 1000, 
    max: 2000,
    message: { error: 'Too many requests' },
    skip: (req) => req.method === 'OPTIONS', 
});
app.use('/api/', limiter);

// --- 3. Static Files & Dirs ---
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/backups', express.static(path.join(__dirname, 'backups'))); 

const dirs = ['uploads/', 'uploads/avatars/', 'backups/', 'backups/database/', 'backups/source/', 'backups/github_sync/'];
dirs.forEach(dir => {
    if (!fs.existsSync(path.join(__dirname, dir))) fs.mkdirSync(path.join(__dirname, dir), { recursive: true });
});

// --- 4. Route Definition ---
const userRoutes = require('./routes/userRoutes');
const ticketRoutes = require('./routes/ticketRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const equipmentRoutes = require('./routes/equipmentRoutes');
const projectRoutes = require('./routes/projectRoutes');
const vendorRoutes = require('./routes/vendorRoutes');
const backupRoutes = require('./routes/backupRoutes');
const statusRoutes = require('./routes/statusRoutes');
const settingRoutes = require('./routes/settingRoutes');
const auditRoutes = require('./routes/auditRoutes');

// API Mount Points
const userController = require('./controllers/userController');
app.post('/api/login', userController.login);
app.post('/api/register', authenticateToken, requireRole(['admin']), userController.register);

app.use('/api/users', userRoutes);
app.use('/api/tickets', ticketRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/equipments', equipmentRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/vendors', vendorRoutes);
app.use('/api/statuses', statusRoutes);
app.use('/api/settings', settingRoutes);
app.use('/api/audit', auditRoutes);
app.use('/api/backup', backupRoutes);

// ✅ จัดการเส้นทาง GitHub ผ่าน backupRoutes โดยตรง (แก้ปัญหา Collision)
// หมายเหตุ: Frontend ควรเรียก /api/backup/github/... ตามโครงสร้างของ backupRoutes
// เพื่อความสะดวก เราจะทำ Redirect ชั่วคราวให้
app.use('/api/github', backupRoutes);

app.get('/', (req, res) => { res.send('LMIS API is online'); });

// --- 5. Error & Start ---
app.use(errorHandler);

// ✅ ดักจับ Error ระดับ Process (ป้องกันการตายเงียบ)
process.on('uncaughtException', (err) => {
    console.error('❌ CRITICAL: Uncaught Exception:', err.message);
    console.error(err.stack);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ CRITICAL: Unhandled Rejection at:', promise, 'reason:', reason);
});

const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, async () => {
    console.log(`🚀 Server is running on port ${PORT}`);
    try {
        await cronService.setupCronJob();
        await cronService.setupSourceCronJob();
        await cronService.setupGithubCronJob();
    } catch (e) { console.error("Cron Error:", e.message); }
});

// ✅ ขยายเวลา Timeout เป็น 10 นาที สำหรับงาน Backup หนักๆ
server.timeout = 600000; 
server.keepAliveTimeout = 65000;
server.headersTimeout = 66000;
