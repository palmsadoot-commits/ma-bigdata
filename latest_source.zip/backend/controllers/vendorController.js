const db = require('../config/db');

exports.getVendors = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM vendors ORDER BY vendor_id DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch vendors' }); }
};

exports.createVendor = async (req, res) => {
    const { vendor_name, contact_name, contact_phone, contact_email } = req.body;
    try {
        await db.query(`INSERT INTO vendors (vendor_name, contact_name, contact_phone, contact_email) VALUES (?, ?, ?, ?)`, 
            [vendor_name, contact_name || null, contact_phone || null, contact_email || null]);
        res.json({ success: true, message: 'เพิ่มผู้รับจ้างเรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถเพิ่มข้อมูลได้' }); }
};

exports.updateVendor = async (req, res) => {
    const { vendor_name, contact_name, contact_phone, contact_email } = req.body;
    try {
        await db.query(`UPDATE vendors SET vendor_name=?, contact_name=?, contact_phone=?, contact_email=? WHERE vendor_id=?`, 
            [vendor_name, contact_name || null, contact_phone || null, contact_email || null, req.params.id]);
        res.json({ success: true, message: 'อัปเดตข้อมูลสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถอัปเดตได้' }); }
};

exports.deleteVendor = async (req, res) => {
    try {
        await db.query('DELETE FROM vendors WHERE vendor_id = ?', [req.params.id]);
        res.json({ success: true, message: 'ลบข้อมูลสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถลบได้ เนื่องจากมีสัญญาหรือตั๋วผูกอยู่' }); }
};
