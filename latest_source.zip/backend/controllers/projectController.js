const db = require('../config/db');

exports.getProjects = async (req, res) => {
    try {
        const sql = `
            SELECT p.*, v.vendor_name 
            FROM projects p 
            LEFT JOIN vendors v ON p.vendor_id = v.vendor_id 
            ORDER BY p.project_id DESC`;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch projects' }); }
};

exports.createProject = async (req, res) => {
    const { project_name, project_contract, description, vendor_id, contract_value, penalty_rate } = req.body;
    try {
        await db.query(
            `INSERT INTO projects (project_name, project_contract, description, vendor_id, contract_value, penalty_rate) VALUES (?, ?, ?, ?, ?, ?)`, 
            [
                project_name, 
                project_contract || null, 
                description || null, 
                vendor_id || null, 
                contract_value || 0, 
                penalty_rate || 0
            ]
        );
        res.json({ success: true, message: 'เพิ่มโครงการและสัญญาเรียบร้อยแล้ว' });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'ไม่สามารถเพิ่มโครงการได้' }); 
    }
};

exports.updateProject = async (req, res) => {
    const projId = req.params.id; 
    const { project_name, project_contract, description, vendor_id, contract_value, penalty_rate } = req.body;
    try {
        await db.query(
            `UPDATE projects SET project_name = ?, project_contract = ?, description = ?, vendor_id = ?, contract_value = ?, penalty_rate = ? WHERE project_id = ?`, 
            [
                project_name, 
                project_contract || null, 
                description || null, 
                vendor_id || null, 
                contract_value || 0, 
                penalty_rate || 0, 
                projId
            ]
        );
        res.json({ success: true, message: 'อัปเดตโครงการและสัญญาเรียบร้อยแล้ว' });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'ไม่สามารถอัปเดตโครงการได้' }); 
    }
};

exports.deleteProject = async (req, res) => {
    const projId = req.params.id;
    try {
        const [cats] = await db.query('SELECT COUNT(*) as count FROM categories WHERE project_id = ?', [projId]);
        if (cats[0].count > 0) return res.status(400).json({ error: 'ไม่สามารถลบได้ เนื่องจากมีหมวดหมู่ผูกอยู่' });

        await db.query('DELETE FROM projects WHERE project_id = ?', [projId]);
        res.json({ success: true, message: 'ลบโครงการเรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถลบโครงการได้' }); }
};
