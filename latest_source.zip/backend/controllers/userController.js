const db = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { logAction } = require('../utils/logger');

exports.login = async (req, res) => {
    const { username, password } = req.body;
    try {
        const [rows] = await db.query(`SELECT * FROM users WHERE username = ?`, [username]);
        if (rows.length === 0) {
            await logAction(null, 'LOGIN_FAILED', `Attempted username: ${username}`, req);
            return res.status(401).json({ error: 'ชื่อผู้ใช้งานไม่ถูกต้อง!' });
        }

        const user = rows[0];
        let isMatch = false;

        if (user.password_hash.length === 32) {
            isMatch = (crypto.createHash('md5').update(password).digest('hex') === user.password_hash);
        } else {
            isMatch = await bcrypt.compare(password, user.password_hash);
        }

        if (!isMatch) {
            await logAction(user.user_id, 'LOGIN_FAILED', `Wrong password for user: ${username}`, req);
            return res.status(401).json({ error: 'รหัสผ่านไม่ถูกต้อง!' });
        }
        
        const token = jwt.sign(
            { user_id: user.user_id, username: user.username, role: user.role }, 
            process.env.JWT_SECRET || 'fallback_secret', 
            { expiresIn: '12h' }
        );

        delete user.password_hash; 
        user.token = token; 

        await logAction(user.user_id, 'LOGIN_SUCCESS', `User ${username} logged in`, req);

        res.json({ success: true, user: user });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล' }); 
    }
};

exports.register = async (req, res) => {
    const { username, password, first_name, last_name, role, project_id, agency } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        await db.query(`INSERT INTO users (username, password_hash, first_name, last_name, role, project_id, agency) VALUES (?, ?, ?, ?, ?, ?, ?)`, [username, hashedPassword, first_name, last_name, role, project_id || null, agency || null]);
        
        await logAction(req.user?.user_id, 'USER_REGISTERED', `New user registered: ${username} (${role})`, req);
        
        res.json({ success: true, message: 'User registered successfully' });
    } catch (err) { res.status(500).json({ error: 'Registration failed' }); }
};

exports.getUsers = async (req, res) => {
    try {
        const sql = `SELECT u.user_id, u.username, u.first_name, u.last_name, u.role, u.agency, u.project_id, u.user_photo, p.project_name FROM users u LEFT JOIN projects p ON u.project_id = p.project_id ORDER BY u.created_at DESC`;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch users' }); }
};

exports.updateUser = async (req, res) => {
    const userId = req.params.id;
    const { first_name, last_name, agency, role, project_id, new_password } = req.body;
    try {
        let sql = `UPDATE users SET first_name = ?, last_name = ?, agency = ?, role = ?, project_id = ?`;
        let params = [first_name, last_name, agency, role, project_id || null];

        if (new_password && new_password.trim() !== '') {
            sql += `, password_hash = ?`;
            params.push(await bcrypt.hash(new_password, 10));
        }
        sql += ` WHERE user_id = ?`;
        params.push(userId);

        await db.query(sql, params);
        
        await logAction(req.user?.user_id, 'USER_UPDATED', `Updated user ID: ${userId}`, req);
        
        res.json({ success: true, message: 'อัปเดตข้อมูลสำเร็จ!' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถอัปเดตข้อมูลได้' }); }
};

exports.deleteUser = async (req, res) => {
    try {
        await db.query('DELETE FROM users WHERE user_id = ?', [req.params.id]);
        
        await logAction(req.user?.user_id, 'USER_DELETED', `Deleted user ID: ${req.params.id}`, req);
        
        res.json({ success: true, message: 'ลบผู้ใช้งานออกจากระบบเรียบร้อยแล้ว' });
    } catch (err) { res.status(500).json({ error: 'เกิดข้อผิดพลาด ไม่สามารถลบผู้ใช้งานได้' }); }
};

exports.updateProfile = async (req, res) => {
    const { user_id, first_name, last_name, position, department, email, telephone, mobile } = req.body;
    try {
        const sql = `UPDATE users SET first_name = ?, last_name = ?, agency = ?, position = ?, email = ?, telephone = ?, mobile = ? WHERE user_id = ?`;
        const [result] = await db.query(sql, [first_name, last_name, department, position, email, telephone, mobile, user_id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'ไม่พบผู้ใช้งาน' });
        
        await logAction(user_id, 'PROFILE_UPDATED', `User updated their own profile`, req);
        
        res.json({ success: true, message: 'อัปเดตข้อมูลส่วนตัวสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถอัปเดตข้อมูลได้' }); }
};

exports.uploadAvatar = async (req, res) => {
    try {
        const { user_id } = req.body;
        if (!user_id || !req.file) return res.status(400).json({ error: 'กรุณาเลือกไฟล์ภาพ' });
        await db.query(`UPDATE users SET user_photo = ? WHERE user_id = ?`, [req.file.filename, user_id]);
        
        await logAction(user_id, 'AVATAR_UPLOADED', `User uploaded new avatar: ${req.file.filename}`, req);
        
        res.json({ success: true, filename: req.file.filename, message: 'อัปโหลดรูปโปรไฟล์สำเร็จ' });
    } catch (err) { res.status(500).json({ error: err.message || 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' }); }
};

exports.updatePassword = async (req, res) => {
    const { user_id, old_password, new_password } = req.body;
    try {
        const [rows] = await db.query('SELECT password_hash FROM users WHERE user_id = ?', [user_id]);
        if (rows.length === 0) return res.status(404).json({ error: 'ไม่พบผู้ใช้งาน' });

        const dbPassword = rows[0].password_hash;
        let isMatch = false;

        if (dbPassword.length === 32) {
            isMatch = (crypto.createHash('md5').update(old_password).digest('hex') === dbPassword);
        } else {
            isMatch = await bcrypt.compare(old_password, dbPassword);
        }
        if (!isMatch) return res.status(400).json({ error: 'รหัสผ่านเดิมไม่ถูกต้อง' });

        await db.query('UPDATE users SET password_hash = ? WHERE user_id = ?', [await bcrypt.hash(new_password, 10), user_id]);
        
        await logAction(user_id, 'PASSWORD_CHANGED', `User changed their password`, req);
        
        res.json({ success: true, message: 'เปลี่ยนรหัสผ่านสำเร็จ!' });
    } catch (err) { res.status(500).json({ error: 'ไม่สามารถเปลี่ยนรหัสผ่านได้' }); }
};

exports.getTechnicians = async (req, res) => {
    const project_id = req.query.project_id;
    try {
        let sql = `SELECT user_id, CONCAT(first_name, ' ', last_name) AS full_name FROM users WHERE role IN ('technician', 'head_technician') AND status = 'active'`;
        let params = [];
        if (project_id) { sql += ` AND project_id = ?`; params.push(project_id); }
        const [rows] = await db.query(sql, params);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch technicians' }); }
};
