const fs = require('fs');
const path = require('path');
const db = require('../config/db');
const { toNull, toInt, toFloat } = require('../utils/dataHelper');
const { logAction } = require('../utils/logger');
const { sendLineNotify, sendEmail } = require('../services/notificationService');

// ดึงข้อมูลการตั้งค่าทั้งหมด
exports.getSettings = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM system_settings WHERE id = 1');
        if (rows.length === 0) {
            await db.query(`INSERT IGNORE INTO system_settings (id, system_name) VALUES (1, 'LMIS Big Data')`);
            const [newRows] = await db.query('SELECT * FROM system_settings WHERE id = 1');
            return res.json(newRows[0]);
        }
        res.json(rows[0]);
    } catch (err) {
        console.error("Error fetching system settings:", err);
        res.status(500).json({ error: 'Failed to fetch settings', details: err.message });
    }
};

// อัปเดตข้อมูลการตั้งค่า
exports.updateSettings = async (req, res) => {
    try {
        const body = req.body || {};
        const toDB = (val) => (val === '' || val === undefined || val === 'null' || val === null) ? null : val;

        const fields = [];
        const params = [];

        const addField = (col, val) => {
            fields.push(`${col} = ?`);
            params.push(toDB(val));
        };

        // ข้อมูลพื้นฐาน
        addField('system_name', body.system_name);
        addField('agency_name', body.agency_name);
        
        // การแจ้งเตือน (Master Toggles)
        fields.push('enable_line = ?'); params.push(body.enable_line === '1' || body.enable_line === 1 || body.enable_line === true ? 1 : 0);
        fields.push('enable_email = ?'); params.push(body.enable_email === '1' || body.enable_email === 1 || body.enable_email === true ? 1 : 0);
        
        // การแจ้งเตือน (Events)
        fields.push('notify_new_ticket = ?'); params.push(body.notify_new_ticket === '1' || body.notify_new_ticket === 1 || body.notify_new_ticket === true ? 1 : 0);
        fields.push('notify_status_change = ?'); params.push(body.notify_status_change === '1' || body.notify_status_change === 1 || body.notify_status_change === true ? 1 : 0);

        // ช่องทางการส่ง
        addField('line_notify_token', body.line_notify_token);
        addField('line_group_id', body.line_group_id);
        addField('smtp_host', body.smtp_host);
        addField('smtp_port', body.smtp_port);
        addField('smtp_user', body.smtp_user);
        addField('smtp_pass', body.smtp_pass);
        addField('admin_email', body.admin_email);
        
        // ความปลอดภัยและ SLA
        addField('allowed_file_types', body.allowed_file_types);
        fields.push('default_sla_hours = ?'); params.push(toInt(body.default_sla_hours, 2));
        fields.push('default_penalty_rate = ?'); params.push(toFloat(body.default_penalty_rate, 0.001));
        fields.push('max_file_size_mb = ?'); params.push(toInt(body.max_file_size_mb, 5));
        fields.push('security_strict_mode = ?'); params.push(toInt(body.security_strict_mode, 1));

        // ✅ ฟิลด์ใหม่ระดับ Full Function
        fields.push('sla_hardware_hours = ?'); params.push(toInt(body.sla_hardware_hours, 6));
        fields.push('sla_software_hours = ?'); params.push(toInt(body.sla_software_hours, 6));
        fields.push('sla_app_hours = ?'); params.push(toInt(body.sla_app_hours, 12));
        fields.push('ack_limit_hours = ?'); params.push(toFloat(body.ack_limit_hours, 2));
        fields.push('maintenance_mode = ?'); params.push(body.maintenance_mode === '1' || body.maintenance_mode === 1 || body.maintenance_mode === true ? 1 : 0);
        
        addField('msg_template_new', body.msg_template_new);
        addField('msg_template_update', body.msg_template_update);

        // ✅ เพิ่มฟิลด์สำหรับ Themes & UI
        addField('theme_mode', body.theme_mode);
        addField('primary_color', body.primary_color);
        addField('system_font', body.system_font);

        // จัดการไฟล์ (Logo และ Favicon)
        // หมายเหตุ: กรณีใช้ upload.fields() ใน routes จะได้ req.files
        if (req.file) {
            // กรณี upload.single('system_logo')
            fields.push('system_logo = ?');
            params.push(req.file.filename);
        } else if (req.files) {
            // กรณี upload.fields([{ name: 'system_logo' }, { name: 'system_favicon' }])
            if (req.files['system_logo']) {
                fields.push('system_logo = ?');
                params.push(req.files['system_logo'][0].filename);
            }
            if (req.files['system_favicon']) {
                fields.push('system_favicon = ?');
                params.push(req.files['system_favicon'][0].filename);
            }
        }

        if (fields.length === 0) return res.json({ success: true, message: 'ไม่มีข้อมูลเปลี่ยนแปลง' });

        const sql = `UPDATE system_settings SET ${fields.join(', ')} WHERE id = 1`;
        await db.query(sql, params);
        
        await logAction(req.user?.user_id, 'SYSTEM_SETTINGS_UPDATED', `User updated system settings`, req);
        res.json({ success: true, message: 'อัปเดตการตั้งค่าระบบเรียบร้อยแล้ว' });
    } catch (err) {
        console.error("🔥 Error in updateSettings:", err);
        res.status(500).json({ error: 'ไม่สามารถบันทึกข้อมูลได้', details: err.message });
    }
};

// ✅ ทดสอบส่งข้อความ LINE
exports.testLineConnection = async (req, res) => {
    try {
        const testMessage = `🔔 [ระบบแจ้งซ่อม] ข้อความทดสอบการเชื่อมต่อ LINE\nสถานะ: 🟢 ใช้งานได้ปกติ\nเวลา: ${new Date().toLocaleString('th-TH')}`;
        await sendLineNotify(testMessage);
        res.json({ success: true, message: 'ส่งข้อความทดสอบเรียบร้อย! (ตรวจสอบว่าคุณเปิดสวิตช์ใช้งาน LINE หรือยัง)' });
    } catch (err) {
        res.status(500).json({ error: 'ล้มเหลว', details: err.message });
    }
};

// ✅ ทดสอบส่ง Email
exports.testEmailConnection = async (req, res) => {
    try {
        const subject = '🔔 ทดสอบระบบ Email (LMIS)';
        const text = `นี่คือข้อความทดสอบ SMTP\nสถานะ: 🟢 ถูกต้อง\nเวลา: ${new Date().toLocaleString('th-TH')}`;
        await sendEmail(subject, text);
        res.json({ success: true, message: 'ส่งอีเมลทดสอบเรียบร้อย! (ตรวจสอบว่าคุณเปิดสวิตช์ใช้งาน Email หรือยัง)' });
    } catch (err) {
        res.status(500).json({ error: 'ล้มเหลว', details: err.message });
    }
};

// ✅ ตรวจสอบสุขภาพระบบ (System Health)
exports.getSystemHealth = async (req, res) => {
    try {
        const health = {
            database: 'Connected',
            folders: [],
            server_time: new Date().toLocaleString('th-TH'),
            node_version: process.version,
            platform: process.platform
        };

        // เช็ค Folders
        const targetDirs = ['uploads', 'uploads/avatars', 'backups', 'backups/database', 'backups/source'];
        targetDirs.forEach(dir => {
            const fullPath = path.join(__dirname, '../../', dir);
            let status = 'Readable';
            try {
                fs.accessSync(fullPath, fs.constants.W_OK);
                status = 'Writable';
            } catch (e) {
                status = 'Read-Only / No Access';
            }
            health.folders.push({ name: dir, status });
        });

        res.json(health);
    } catch (err) {
        res.status(500).json({ error: 'Failed to get health info' });
    }
};
