const db = require('../config/db');

exports.getAuditLogs = async (req, res) => {
    try {
        const sql = `
            SELECT a.*, u.username, CONCAT(u.first_name, ' ', u.last_name) as fullname 
            FROM audit_logs a 
            LEFT JOIN users u ON a.user_id = u.user_id 
            ORDER BY a.created_at DESC 
            LIMIT 500
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        console.error("Error fetching audit logs:", err);
        res.status(500).json({ error: 'Failed to fetch audit logs' });
    }
};
