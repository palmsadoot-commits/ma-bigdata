const db = require('../config/db');

exports.getEquipments = async (req, res) => {
    try {
        const sql = `
            SELECT e.*, c.category_name, c.project_id 
            FROM equipments e 
            LEFT JOIN categories c ON e.category_id = c.category_id 
            ORDER BY e.equipment_id DESC`;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'Failed to fetch equipments' }); 
    }
};

exports.createEquipment = async (req, res) => {
    const { category_id, equipment_name, serial_number } = req.body;
    try {
        await db.query(
            `INSERT INTO equipments (category_id, equipment_name, serial_number) VALUES (?, ?, ?)`, 
            [category_id, equipment_name, serial_number || null]
        );
        res.json({ success: true, message: 'เพิ่มอุปกรณ์เรียบร้อยแล้ว' });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'ไม่สามารถเพิ่มข้อมูลได้' }); 
    }
};

exports.updateEquipment = async (req, res) => {
    const { category_id, equipment_name, serial_number } = req.body;
    try {
        await db.query(
            `UPDATE equipments SET category_id=?, equipment_name=?, serial_number=? WHERE equipment_id=?`, 
            [category_id, equipment_name, serial_number || null, req.params.id]
        );
        res.json({ success: true, message: 'อัปเดตอุปกรณ์สำเร็จ' });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'ไม่สามารถอัปเดตได้' }); 
    }
};

exports.updateEquipmentStatus = async (req, res) => {
    try {
        await db.query(`UPDATE equipments SET status = ? WHERE equipment_id = ?`, [req.body.status, req.params.id]);
        res.json({ success: true, message: 'อัปเดตสถานะสำเร็จ' });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'ไม่สามารถอัปเดตสถานะได้' }); 
    }
};

exports.deleteEquipment = async (req, res) => {
    try {
        await db.query('DELETE FROM equipments WHERE equipment_id = ?', [req.params.id]);
        res.json({ success: true, message: 'ลบอุปกรณ์สำเร็จ' });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'ไม่สามารถลบได้ เนื่องจากมีการอ้างอิงในใบงาน' }); 
    }
};
