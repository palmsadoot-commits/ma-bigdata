const db = require('../config/db');
const { simpleSanitize } = require('../utils/dataHelper');
const { logAction } = require('../utils/logger');
const { sendLineNotify, sendEmail } = require('../services/notificationService');

// ฟังก์ชันช่วยดึงการตั้งค่าระบบที่จำเป็นสำหรับการแจ้งเตือน
const getNotifySettings = async () => {
    const [rows] = await db.query('SELECT * FROM system_settings WHERE id = 1');
    return rows[0] || {};
};

// ฟังก์ชันแทนที่ Placeholder ใน Template
const parseTemplate = (template, data) => {
    if (!template) return '';
    return template
        .replace(/{no}/g, data.no || '')
        .replace(/{cat}/g, data.cat || '')
        .replace(/{detail}/g, data.detail || '')
        .replace(/{status}/g, data.status || '')
        .replace(/{by}/g, data.by || '');
};

exports.createTicket = async (req, res) => {
    try {
        let { reporter_id, category_id, equipment_no, software_no, problem_detail, is_cm } = req.body;
        const attachment = req.file ? req.file.filename : null;

        if (!reporter_id || !category_id || !problem_detail) {
            return res.status(400).json({ error: 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน' });
        }

        const settings = await getNotifySettings();
        if (settings.maintenance_mode === 1) {
            return res.status(503).json({ error: 'ระบบปิดปรับปรุงชั่วคราว กรุณาลองใหม่ภายหลัง' });
        }

        problem_detail = simpleSanitize(problem_detail);

        const currentYearBE = new Date().getFullYear() + 543; 
        const [rows] = await db.query('SELECT COUNT(*) as count FROM tickets WHERE ticket_number LIKE ?', [`%/${currentYearBE}`]);
        const ticket_number = `${rows[0].count + 1}/${currentYearBE}`; 

        const [catRows] = await db.query('SELECT project_id, category_name, category_type FROM categories WHERE category_id = ?', [category_id]);
        const projectId = catRows[0]?.project_id;
        const categoryName = catRows[0]?.category_name;
        const categoryType = catRows[0]?.category_type;
        
        // 🌟 คำนวณ SLA อัตโนมัติจาก Policy
        let slaHours = settings.default_sla_hours || 24;
        if (Number(is_cm) === 1) {
            if (categoryType === 'Hardware') slaHours = settings.sla_hardware_hours || 6;
            else if (categoryType === 'Software') slaHours = settings.sla_software_hours || 6;
            else if (categoryType === 'Application') slaHours = settings.sla_app_hours || 12;
        }

        let vendorId = null;
        if (projectId) {
            const [contractRows] = await db.query('SELECT vendor_id FROM contracts WHERE project_id = ? AND is_active = 1 ORDER BY contract_id DESC LIMIT 1', [projectId]);
            if (contractRows.length > 0) vendorId = contractRows[0].vendor_id;
        }

        await db.query(
            `INSERT INTO tickets (ticket_number, reporter_id, category_id, equipment_no, software_no, problem_detail, status, attachment, is_cm, sla_hours, sla_deadline, vendor_id, created_at) 
             VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?, IF(? = '1', DATE_ADD(NOW(), INTERVAL ? HOUR), NULL), ?, NOW())`, 
            [ticket_number, reporter_id, category_id, equipment_no, software_no, problem_detail, attachment, is_cm || 0, slaHours, is_cm || 0, slaHours, vendorId]
        );

        await logAction(reporter_id, 'TICKET_CREATED', `Ticket ${ticket_number} created`, req);

        // ✅ ระบบแจ้งเตือนอัจฉริยะ (Message Template)
        if (settings.notify_new_ticket === 1) {
            const cleanText = problem_detail.replace(/<[^>]*>?/gm, '').substring(0, 50);
            const msg = parseTemplate(settings.msg_template_new, {
                no: ticket_number,
                cat: categoryName,
                detail: cleanText
            });
            
            if (settings.enable_line === 1) sendLineNotify(msg);
            if (settings.enable_email === 1 && settings.admin_email) sendEmail(`🔔 แจ้งซ่อมใหม่: ${ticket_number}`, msg);
        }

        res.status(201).json({ message: 'บันทึกใบแจ้งซ่อมสำเร็จ!', ticket_number: ticket_number });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'เกิดข้อผิดพลาดในการบันทึกข้อมูล' }); 
    }
};

exports.updateTicketStatus = async (req, res) => {
    const ticket_id = req.params.id;
    let { status, technician_id, root_cause_and_solution } = req.body;

    try {
        if (root_cause_and_solution) root_cause_and_solution = simpleSanitize(root_cause_and_solution);
        
        const [ticketRows] = await db.query(`
            SELECT t.*, c.project_id 
            FROM tickets t 
            LEFT JOIN categories c ON t.category_id = c.category_id 
            WHERE t.ticket_id = ?`, [ticket_id]
        );
        const ticket = ticketRows[0];
        const settings = await getNotifySettings();

        let penaltyAmount = 0.00;
        let isBreached = 0;

        if (status === 'Resolved' && ticket.is_cm === 1 && ticket.sla_deadline) {
            const [timeCheck] = await db.query('SELECT NOW() as current_time_db');
            const resolvedAt = new Date(timeCheck[0].current_time_db);
            const deadline = new Date(ticket.sla_deadline);

            if (resolvedAt > deadline) {
                isBreached = 1;
                const delayMs = resolvedAt - deadline;
                const delayDays = Math.ceil(delayMs / (1000 * 60 * 60 * 24));
                
                // 🌟 ดึงข้อมูลจากตาราง Contracts แทน Projects
                const [contractRows] = await db.query(`SELECT contract_value, penalty_rate FROM contracts WHERE project_id = ? AND vendor_id = ? AND is_active = 1 ORDER BY contract_id DESC LIMIT 1`, [ticket.project_id, ticket.vendor_id]);
                const [eqRows] = await db.query(`SELECT weighting_factor FROM equipments WHERE serial_number = ? LIMIT 1`, [ticket.equipment_no]);
                const weight = eqRows.length > 0 ? parseFloat(eqRows[0].weighting_factor) : 1.0;
                const [totalWeightRows] = await db.query(`SELECT SUM(weighting_factor) as total_weight FROM equipments e JOIN categories c ON e.category_id = c.category_id WHERE c.project_id = ?`, [ticket.project_id]);
                const totalWeight = totalWeightRows[0].total_weight || 1.0;

                if (contractRows.length > 0) {
                    const contractValue = parseFloat(contractRows[0].contract_value);
                    const penaltyRate = parseFloat(contractRows[0].penalty_rate); 
                    penaltyAmount = (contractValue * (weight / totalWeight)) * penaltyRate * delayDays;
                }
            }
            await db.query(`UPDATE tickets SET status = ?, resolved_at = NOW(), is_sla_breached = ?, penalty_amount = ? WHERE ticket_id = ?`, [status, isBreached, penaltyAmount, ticket_id]);
        } else {
            await db.query('UPDATE tickets SET status = ? WHERE ticket_id = ?', [status, ticket_id]);
        }

        if (status === 'Resolved' && root_cause_and_solution) {
            await db.query(`INSERT INTO ticket_resolutions (ticket_id, technician_id, root_cause_and_solution, resolved_at) VALUES (?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE root_cause_and_solution = VALUES(root_cause_and_solution), resolved_at = NOW()`, [ticket_id, technician_id, root_cause_and_solution]);
        }

        await logAction(technician_id || req.user?.user_id, 'TICKET_STATUS_UPDATED', `Ticket ${ticket.ticket_number} status changed to ${status}`, req);

        // ✅ แจ้งเตือนสถานะ (Message Template)
        if (settings.notify_status_change === 1) {
            const msg = parseTemplate(settings.msg_template_update, {
                no: ticket.ticket_number,
                status: status,
                by: req.user?.username || 'ช่าง'
            });
            if (settings.enable_line === 1) sendLineNotify(msg);
            if (settings.enable_email === 1 && settings.admin_email) sendEmail(`🔧 อัปเดตใบงาน: ${ticket.ticket_number}`, msg);
        }

        res.json({ success: true, message: isBreached ? `สำเร็จล่าช้า! ค่าปรับ: ${penaltyAmount.toLocaleString()} บาท` : 'อัปเดตสำเร็จ' });
    } catch (err) { 
        console.error(err);
        res.status(500).json({ error: 'เกิดข้อผิดพลาดในการอัปเดตข้อมูล' }); 
    }
};

exports.getTickets = async (req, res) => {
    const project_id = req.query.project_id; 
    try {
        let sql = `
            SELECT 
                t.ticket_id, t.ticket_number, t.equipment_no, t.software_no, 
                LEFT(REGEXP_REPLACE(t.problem_detail, '<[^>]*>?', ''), 100) AS problem_detail, 
                t.status, t.created_at, t.attachment, t.is_cm, t.sla_deadline, 
                t.is_sla_breached, t.penalty_amount, t.acknowledged_at,
                c.category_name, c.category_type, 
                CONCAT(u.first_name, ' ', u.last_name) AS reporter_name 
            FROM tickets t 
            LEFT JOIN categories c ON t.category_id = c.category_id 
            LEFT JOIN users u ON t.reporter_id = u.user_id
        `;
        let params = [];
        if (project_id && project_id !== 'null' && project_id !== 'undefined') { sql += ' WHERE c.project_id = ?'; params.push(project_id); }
        sql += ' ORDER BY t.created_at DESC LIMIT 100';
        const [rows] = await db.query(sql, params);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch tickets' }); }
};

exports.getTicketById = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT t.*, c.category_name, CONCAT(u.first_name, ' ', u.last_name) AS reporter_name 
            FROM tickets t 
            LEFT JOIN categories c ON t.category_id = c.category_id 
            LEFT JOIN users u ON t.reporter_id = u.user_id 
            WHERE t.ticket_id = ?`, [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'ไม่พบข้อมูล' });
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Error' }); }
};

exports.deleteTicket = async (req, res) => {
    try {
        await db.query('DELETE FROM tickets WHERE ticket_id = ?', [req.params.id]);
        res.json({ success: true, message: 'ลบข้อมูลสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'Error' }); }
};

exports.getTicketLogs = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM ticket_logs WHERE ticket_id = ? ORDER BY created_at DESC', [req.params.id]);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Failed to fetch logs' }); }
};

exports.createTicketLog = async (req, res) => {
    const { action, actor_name, detail } = req.body;
    try {
        await db.query(
            'INSERT INTO ticket_logs (ticket_id, action, actor_name, detail, created_at) VALUES (?, ?, ?, ?, NOW())',
            [req.params.id, action, actor_name, detail]
        );
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: 'Failed to create log' }); }
};
