const db = require('../config/db');

exports.getStatuses = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM ticket_statuses ORDER BY sort_order');
        res.json(rows);
    } catch (err) { 
        res.status(500).json({ error: 'ดึงข้อมูลไม่สำเร็จ' }); 
    }
};

exports.createStatus = async (req, res) => {
    const { status_name, status_color, sort_order } = req.body;
    try {
        await db.query(
            'INSERT INTO ticket_statuses (status_name, status_color, sort_order) VALUES (?, ?, ?)', 
            [status_name, status_color || '#1890ff', sort_order || 0]
        );
        res.json({ success: true, message: 'เพิ่มสถานะเรียบร้อยแล้ว' });
    } catch (err) { 
        res.status(500).json({ error: 'ไม่สามารถเพิ่มสถานะได้' }); 
    }
};

exports.updateStatus = async (req, res) => {
    const { status_name, status_color, sort_order } = req.body;
    const statusId = req.params.id;
    try {
        await db.query(
            'UPDATE ticket_statuses SET status_name = ?, status_color = ?, sort_order = ? WHERE status_id = ?', 
            [status_name, status_color, sort_order, statusId]
        );
        res.json({ success: true, message: 'อัปเดตสถานะเรียบร้อยแล้ว' });
    } catch (err) { 
        res.status(500).json({ error: 'ไม่สามารถอัปเดตสถานะได้' }); 
    }
};

exports.deleteStatus = async (req, res) => {
    const statusId = req.params.id;
    try {
        await db.query('DELETE FROM ticket_statuses WHERE status_id = ?', [statusId]);
        res.json({ success: true, message: 'ลบสถานะเรียบร้อยแล้ว' });
    } catch (err) { 
        res.status(500).json({ error: 'ไม่สามารถลบสถานะได้' }); 
    }
};
