const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const db = require('../config/db');
const backupService = require('../services/backupService');

exports.manualBackup = async (req, res) => {
    try {
        const fileName = await backupService.performBackup('Admin (Manual)');
        res.json({ success: true, message: 'สำรองข้อมูลสำเร็จ', file_name: fileName });
    } catch (error) { res.status(500).json({ error: 'การสำรองข้อมูลล้มเหลว', details: error.message }); }
};

exports.getBackupLogs = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM backup_logs ORDER BY created_at DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'ดึงข้อมูลไม่สำเร็จ' }); }
};

exports.getBackupSettings = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM backup_settings LIMIT 1');
        res.json(rows[0] || null);
    } catch (err) { res.status(500).json({ error: 'ดึงการตั้งค่าไม่สำเร็จ' }); }
};

exports.updateBackupSettings = async (req, res) => {
    const { schedule_type, schedule_days, schedule_time, is_active } = req.body;
    try {
        await db.query(`UPDATE backup_settings SET schedule_type=?, schedule_days=?, schedule_time=?, is_active=? WHERE id=1`, 
            [schedule_type, schedule_days, schedule_time, is_active]);
        // setupCronJob logic should be triggered here, but for now we'll just return success
        res.json({ success: true, message: 'บันทึกการตั้งค่าสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'บันทึกไม่สำเร็จ' }); }
};

exports.deleteBackup = async (req, res) => {
    const fileName = req.params.fileName;
    const filePath = path.join(__dirname, '../backups', 'database', fileName);
    try {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath); 
        await db.query('DELETE FROM backup_logs WHERE file_name = ?', [fileName]); 
        res.json({ success: true, message: 'ลบไฟล์สำรองข้อมูลเรียบร้อยแล้ว' });
    } catch (error) { res.status(500).json({ error: 'ไม่สามารถลบไฟล์ได้', details: error.message }); }
};

exports.restoreBackup = async (req, res) => {
    const { file_name } = req.body;
    const filePath = path.join(__dirname, '../backups', 'database', file_name);

    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'ไม่พบไฟล์แบ็คอัพนี้' });

    const dbUser = process.env.DB_USER;
    const dbPass = process.env.DB_PASSWORD ? `-p"${process.env.DB_PASSWORD}"` : '';
    const dbName = process.env.DB_NAME;
    const dbHost = process.env.DB_HOST;

    const mysqlPath = process.env.MYSQL_PATH || 'mysql';
    const restoreCmd = `"${mysqlPath}" -h ${dbHost} -u ${dbUser} ${dbPass} ${dbName} < "${filePath}"`;

    exec(restoreCmd, async (error) => {
        if (error) return res.status(500).json({ error: 'การกู้คืนล้มเหลว ตรวจสอบ Path ใน .env', details: error.message });
        await db.query(`INSERT INTO backup_logs (file_name, file_size, status, created_by) VALUES (?, 'Restore', 'Success', 'Admin (Restore)')`, [file_name]);
        res.json({ success: true, message: 'กู้คืนฐานข้อมูลเรียบร้อยแล้ว' });
    });
};

exports.manualSourceBackup = async (req, res) => {
    try {
        const { target_folders } = req.body;
        const foldersToBackup = (target_folders && target_folders.length > 0) ? target_folders : ['frontend', 'backend'];
        const fileName = await backupService.performSourceBackup('Admin (Manual)', foldersToBackup);
        res.json({ success: true, message: 'บีบอัด Source Code สำเร็จ', file_name: fileName });
    } catch (error) { 
        res.status(500).json({ error: 'การสำรองข้อมูลล้มเหลว', details: error.message }); 
    }
};

exports.getSourceBackupLogs = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM source_backup_logs ORDER BY created_at DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'ดึงข้อมูลไม่สำเร็จ' }); }
};

exports.getSourceBackupSettings = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM source_backup_settings LIMIT 1');
        res.json(rows[0] || null);
    } catch (err) { res.status(500).json({ error: 'ดึงการตั้งค่าไม่สำเร็จ' }); }
};

exports.updateSourceBackupSettings = async (req, res) => {
    const { target_folders, schedule_type, schedule_days, schedule_time, is_active } = req.body;
    try {
        await db.query(`UPDATE source_backup_settings SET target_folders=?, schedule_type=?, schedule_days=?, schedule_time=?, is_active=? WHERE id=1`, 
            [target_folders, schedule_type, schedule_days, schedule_time, is_active]);
        res.json({ success: true, message: 'บันทึกการตั้งค่าสำเร็จ' });
    } catch (err) { res.status(500).json({ error: 'บันทึกไม่สำเร็จ' }); }
};

exports.deleteSourceBackup = async (req, res) => {
    const fileName = req.params.fileName;
    const filePath = path.join(__dirname, '../backups', 'source', fileName);
    try {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath); 
        await db.query('DELETE FROM source_backup_logs WHERE file_name = ?', [fileName]); 
        res.json({ success: true, message: 'ลบไฟล์ Zip เรียบร้อยแล้ว' });
    } catch (error) { 
        res.status(500).json({ error: 'ไม่สามารถลบไฟล์ได้', details: error.message }); 
    }
};

exports.manualGithubSync = async (req, res) => {
    try {
        const syncTargets = req.body.sync_targets || ['database', 'source'];
        await backupService.performGithubSync('Admin (Manual)', syncTargets);
        res.json({ success: true, message: 'Push ข้อมูลขึ้น GitHub สำเร็จ' });
    } catch (error) { 
        res.status(500).json({ error: error.message }); 
    }
};

exports.getGithubLogs = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM github_sync_logs ORDER BY created_at DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.getGithubSettings = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM github_settings LIMIT 1');
        res.json(rows[0] || null);
    } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.updateGithubSettings = async (req, res) => {
    const { github_token, repo_url, branch_name, sync_targets, schedule_type, schedule_days, schedule_time, is_active } = req.body;
    try {
        await db.query(`UPDATE github_settings SET github_token=?, repo_url=?, branch_name=?, sync_targets=?, schedule_type=?, schedule_days=?, schedule_time=?, is_active=? WHERE id=1`, 
            [github_token, repo_url, branch_name, sync_targets, schedule_type, schedule_days, schedule_time, is_active]);
        res.json({ success: true, message: 'บันทึกการตั้งค่า GitHub สำเร็จ' });
    } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.deleteGithubLog = async (req, res) => {
    const logId = req.params.id;
    try {
        const [result] = await db.query('DELETE FROM github_sync_logs WHERE log_id = ?', [logId]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'ไม่พบประวัตินี้ในระบบ' });
        res.json({ success: true, message: 'ลบประวัติการ Push เรียบร้อยแล้ว' });
    } catch (error) { 
        res.status(500).json({ error: 'ไม่สามารถลบประวัติได้', details: error.message }); 
    }
};
