const axios = require('axios');
const nodemailer = require('nodemailer');
const db = require('../config/db');

/**
 * Send a notification via Email (SMTP)
 */
const sendEmail = async (subject, text, overrideTo = null) => {
    try {
        const [rows] = await db.query('SELECT smtp_host, smtp_port, smtp_user, smtp_pass, system_name, admin_email, enable_email FROM system_settings WHERE id = 1');
        const config = rows[0];

        // ✅ ตรวจสอบสวิตช์เปิด-ปิด Email
        if (!config || config.enable_email !== 1) {
            console.log('🔇 Email notification is DISABLED by global setting.');
            return;
        }

        if (!config.smtp_host || !config.smtp_user) {
            console.log('⚠️ Email settings incomplete. Skipping.');
            return;
        }

        let recipients = overrideTo || config.admin_email || config.smtp_user;
        const toList = recipients.split(',').map(email => email.trim()).filter(email => email !== '');

        const transporter = nodemailer.createTransport({
            host: config.smtp_host,
            port: parseInt(config.smtp_port) || 587,
            secure: config.smtp_port == 465,
            auth: { user: config.smtp_user, pass: config.smtp_pass },
            tls: { rejectUnauthorized: false }
        });

        await transporter.sendMail({
            from: `"${config.system_name || 'LMIS'}" <${config.smtp_user}>`,
            to: toList.join(', '),
            subject: subject,
            text: text
        });

        console.log(`✅ Email sent to: ${toList.join(', ')}`);
    } catch (err) {
        console.error('❌ Failed to send Email:', err.message);
    }
};

/**
 * Send a notification via LINE Messaging API
 */
const sendLineNotify = async (message) => {
    try {
        const [rows] = await db.query('SELECT line_notify_token, line_group_id, enable_line FROM system_settings WHERE id = 1');
        const config = rows[0];

        // ✅ ตรวจสอบสวิตช์เปิด-ปิด LINE
        if (!config || config.enable_line !== 1) {
            console.log('🔇 LINE notification is DISABLED by global setting.');
            return;
        }

        const token = config.line_notify_token;
        const groupId = config.line_group_id;

        if (!token || !groupId) {
            console.log('⚠️ LINE settings incomplete. Skipping.');
            return;
        }

        await axios.post('https://api.line.me/v2/bot/message/push', {
            to: groupId,
            messages: [{ type: 'text', text: message }]
        }, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });
        
        console.log('✅ LINE Notification sent');
    } catch (err) {
        console.error('❌ Failed to send LINE:', err.response?.data || err.message);
    }
};

module.exports = { sendLineNotify, sendEmail };
