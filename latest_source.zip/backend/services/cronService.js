const cron = require('node-cron');
const db = require('../config/db');
const backupService = require('./backupService');

let activeCronJob = null; 
const setupCronJob = async () => {
    try {
        if (activeCronJob) { activeCronJob.stop(); }

        const [rows] = await db.query('SELECT * FROM backup_settings WHERE id = 1 AND is_active = 1');
        if (rows.length === 0) return;

        const setting = rows[0];
        const [hour, minute] = setting.schedule_time.split(':');
        
        let cronExp = `${minute} ${hour} * * *`;
        if (setting.schedule_type === 'weekly' && setting.schedule_days) {
            cronExp = `${minute} ${hour} * * ${setting.schedule_days}`; 
        } else if (setting.schedule_type === 'monthly' && setting.schedule_days) {
            cronExp = `${minute} ${hour} ${setting.schedule_days} * *`; 
        }

        activeCronJob = cron.schedule(cronExp, () => {
            backupService.performBackup('Auto Schedule');
        });
        console.log(`⏱️ Auto DB Backup Scheduled: ${cronExp}`);

    } catch (err) { console.error('❌ Failed to setup DB Cron Job:', err.message); }
};

let activeSourceCronJob = null; 
const setupSourceCronJob = async () => {
    try {
        if (activeSourceCronJob) { activeSourceCronJob.stop(); }

        const [rows] = await db.query('SELECT * FROM source_backup_settings WHERE id = 1 AND is_active = 1');
        if (rows.length === 0) return;

        const setting = rows[0];
        const [hour, minute] = setting.schedule_time.split(':');
        
        let cronExp = `${minute} ${hour} * * *`;
        if (setting.schedule_type === 'weekly' && setting.schedule_days) {
            cronExp = `${minute} ${hour} * * ${setting.schedule_days}`; 
        } else if (setting.schedule_type === 'monthly' && setting.schedule_days) {
            cronExp = `${minute} ${hour} ${setting.schedule_days} * *`; 
        }

        activeSourceCronJob = cron.schedule(cronExp, () => {
            const folders = setting.target_folders ? setting.target_folders.split(',') : ['frontend', 'backend'];
            backupService.performSourceBackup('Auto Schedule', folders);
        });
        console.log(`⏱️ Auto Source Backup Scheduled: ${cronExp}`);

    } catch (err) { console.error('❌ Failed to setup Source Cron Job:', err.message); }
};

let activeGithubCronJob = null; 
const setupGithubCronJob = async () => {
    try {
        if (activeGithubCronJob) { activeGithubCronJob.stop(); }
        const [rows] = await db.query('SELECT * FROM github_settings WHERE id = 1 AND is_active = 1');
        if (rows.length === 0) return;
        const setting = rows[0];
        const [hour, minute] = setting.schedule_time.split(':');
        let cronExp = `${minute} ${hour} * * *`;
        if (setting.schedule_type === 'weekly' && setting.schedule_days) cronExp = `${minute} ${hour} * * ${setting.schedule_days}`; 
        else if (setting.schedule_type === 'monthly' && setting.schedule_days) cronExp = `${minute} ${hour} ${setting.schedule_days} * *`; 
        
        activeGithubCronJob = cron.schedule(cronExp, () => {
            const targets = setting.sync_targets ? setting.sync_targets.split(',') : ['database', 'source'];
            backupService.performGithubSync('Auto Schedule', targets);
        });
        console.log(`⏱️ Auto GitHub Sync Scheduled: ${cronExp}`);
    } catch (err) { console.error('❌ Failed to setup GitHub Cron Job:', err.message); }
};

module.exports = { setupCronJob, setupSourceCronJob, setupGithubCronJob };
