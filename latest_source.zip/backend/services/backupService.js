const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const archiver = require('archiver');
const simpleGit = require('simple-git');
const db = require('../config/db');

// ✅ ตรวจหา Path ของ mysqldump อัตโนมัติสำหรับ Windows/XAMPP
const getDumpPath = () => {
    const xamppPath = 'C:\\xampp\\mysql\\bin\\mysqldump.exe';
    if (fs.existsSync(xamppPath)) return xamppPath; // ห้ามใส่ฟันหนูครอบที่นี่ เดี๋ยว spawn พัง
    return 'mysqldump';
};

const performBackup = async (triggerBy = 'System') => {
    return new Promise((resolve, reject) => {
        try {
            const thaiTime = new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Bangkok"}));
            const dd = String(thaiTime.getDate()).padStart(2, '0');
            const mm = String(thaiTime.getMonth() + 1).padStart(2, '0');
            const yyyy = thaiTime.getFullYear();
            const hh = String(thaiTime.getHours()).padStart(2, '0');
            const min = String(thaiTime.getMinutes()).padStart(2, '0');
            const ss = String(thaiTime.getSeconds()).padStart(2, '0');
            
            const fileName = `backup_${dd}-${mm}-${yyyy}_${hh}-${min}-${ss}.sql`;
            const backupDir = path.resolve(__dirname, '../backups/database');
            
            if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
            const filePath = path.join(backupDir, fileName);

            const dbUser = process.env.DB_USER;
            const dbPass = process.env.DB_PASSWORD || '';
            const dbName = process.env.DB_NAME;
            const dbHost = process.env.DB_HOST;
            const dumpPath = getDumpPath();
            
            // ✅ รวมทุกตารางตามความต้องการของผู้ใช้งาน (รวมทั้ง settings และ logs)
            const args = [
                '-h', dbHost,
                '-u', dbUser,
                dbPass ? `-p${dbPass}` : '', 
                dbName
            ].filter(Boolean);

            console.log(`🚀 Professional Spawn Executing: ${dumpPath} ${args.join(' ')}`);

            const dumpProcess = spawn(dumpPath, args);
            const writeStream = fs.createWriteStream(filePath);

            dumpProcess.stdout.pipe(writeStream);

            let stderrData = '';
            dumpProcess.stderr.on('data', (data) => {
                stderrData += data.toString();
            });

            dumpProcess.on('error', async (err) => {
                console.error("❌ Spawn Error (รันโปรแกรมไม่ได้):", err.message);
                if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
                await db.query(`INSERT INTO backup_logs (file_name, status, created_by) VALUES (?, 'Failed (System Error)', ?)`, [fileName, triggerBy]);
                reject(new Error(`Failed to start backup: ${err.message}`));
            });

            dumpProcess.on('close', async (code) => {
                if (code !== 0) {
                    console.error("❌ Backup Process Error (รหัสจบการทำงาน):", code, "Msg:", stderrData);
                    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
                    await db.query(`INSERT INTO backup_logs (file_name, status, created_by) VALUES (?, 'Failed (Error Code ${code})', ?)`, [fileName, triggerBy]);
                    return reject(new Error(stderrData || `mysqldump exited with code ${code}`));
                }

                const stats = fs.statSync(filePath);
                if (stats.size === 0) {
                    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
                    return reject(new Error('Backup produced an empty file'));
                }

                const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2) + ' MB';
                await db.query(`INSERT INTO backup_logs (file_name, file_size, status, created_by) VALUES (?, ?, 'Success', ?)`, [fileName, fileSizeMB, triggerBy]);
                console.log(`✅ Professional Backup Success: ${fileName}`);
                resolve(fileName);
            });

        } catch (e) {
            console.error("❌ Professional Service Fatal Error:", e);
            reject(e);
        }
    });
};

const performSourceBackup = async (triggerBy = 'System', targetFolders = ['frontend', 'backend']) => {
    return new Promise((resolve, reject) => {
        try {
            const thaiTime = new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Bangkok"}));
            const dd = String(thaiTime.getDate()).padStart(2, '0');
            const mm = String(thaiTime.getMonth() + 1).padStart(2, '0');
            const yyyy = thaiTime.getFullYear();
            
            const fileName = `src_${dd}-${mm}-${yyyy}_${Date.now()}.zip`;
            const backupDir = path.resolve(__dirname, '../backups/source');
            if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
            
            const filePath = path.join(backupDir, fileName);
            const output = fs.createWriteStream(filePath);
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('close', async () => {
                const stats = fs.statSync(filePath);
                const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2) + ' MB';
                const foldersStr = targetFolders.join(',');
                await db.query(`INSERT INTO source_backup_logs (file_name, target_folders, file_size, status, created_by) VALUES (?, ?, ?, 'Success', ?)`, [fileName, foldersStr, fileSizeMB, triggerBy]);
                resolve(fileName);
            });

            archive.on('error', async (err) => {
                console.error("❌ Archive Stream Error:", err.message);
                if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
                await db.query(`INSERT INTO source_backup_logs (file_name, status, created_by) VALUES (?, 'Failed', ?)`, [fileName, triggerBy]);
                reject(err);
            });

            archive.pipe(output);

            const ignorePattern = ['**/node_modules/**', 'backups/**', 'uploads/**', '.git/**', 'dist/**', 'build/**'];
            const backendPath = path.resolve(__dirname, '..');
            const frontendPath = path.resolve(__dirname, '../../frontend');

            if (targetFolders.includes('backend')) {
                archive.glob('**/*', { cwd: backendPath, ignore: ignorePattern }, { prefix: 'backend' });
            }

            if (targetFolders.includes('frontend') && fs.existsSync(frontendPath)) {
                archive.glob('**/*', { cwd: frontendPath, ignore: ignorePattern }, { prefix: 'frontend' });
            }

            archive.finalize();
        } catch (e) {
            console.error("❌ Source Backup Fatal Error:", e.message);
            reject(e);
        }
    });
};

const performGithubSync = async (triggerBy = 'System', syncTargets = ['database', 'source']) => {
    try {
        const [rows] = await db.query('SELECT * FROM github_settings WHERE id = 1');
        if (rows.length === 0 || !rows[0].github_token || !rows[0].repo_url) {
            throw new Error('กรุณาตั้งค่า GitHub Token และ Repository URL ให้ครบถ้วนก่อน');
        }
        const settings = rows[0];
        
        let cleanUrl = settings.repo_url.trim();
        if (cleanUrl.endsWith('/')) cleanUrl = cleanUrl.slice(0, -1);
        if (!cleanUrl.endsWith('.git')) cleanUrl += '.git';

        const repoUrlWithAuth = cleanUrl.replace('https://', `https://${settings.github_token}@`);
        const branchName = settings.branch_name || 'main';
        
        const syncDir = path.resolve(__dirname, '../backups/github_sync');
        if (!fs.existsSync(syncDir)) fs.mkdirSync(syncDir, { recursive: true });

        const git = simpleGit(syncDir);
        const isRepo = await git.checkIsRepo();
        if (!isRepo) {
            await git.init();
            await git.addRemote('origin', repoUrlWithAuth);
        } else {
            await git.remote(['set-url', 'origin', repoUrlWithAuth]);
        }

        await git.addConfig('user.name', 'LMIS Auto Backup Bot');
        await git.addConfig('user.email', 'backup@lmis.local');

        const dbBackupDir = path.resolve(__dirname, '../backups/database');
        const sourceBackupDir = path.resolve(__dirname, '../backups/source');

        if (syncTargets.includes('database') && fs.existsSync(dbBackupDir)) {
            const files = fs.readdirSync(dbBackupDir).filter(f => f.endsWith('.sql'));
            if (files.length > 0) {
                files.sort((a, b) => fs.statSync(path.join(dbBackupDir, b)).mtimeMs - fs.statSync(path.join(dbBackupDir, a)).mtimeMs);
                fs.copyFileSync(path.join(dbBackupDir, files[0]), path.join(syncDir, 'latest_database.sql'));
            }
        }
        
        if (syncTargets.includes('source') && fs.existsSync(sourceBackupDir)) {
            const files = fs.readdirSync(sourceBackupDir).filter(f => f.endsWith('.zip'));
            if (files.length > 0) {
                files.sort((a, b) => fs.statSync(path.join(sourceBackupDir, b)).mtimeMs - fs.statSync(path.join(sourceBackupDir, a)).mtimeMs);
                fs.copyFileSync(path.join(sourceBackupDir, files[0]), path.join(syncDir, 'latest_source.zip'));
            }
        }

        fs.writeFileSync(path.join(syncDir, 'sync_info.txt'), `Last Sync: ${new Date().toLocaleString()}\nBy: ${triggerBy}`);

        await git.add('-A');
        const status = await git.status();

        if (status.isClean()) {
            await db.query(`INSERT INTO github_sync_logs (sync_targets, status, created_by) VALUES (?, 'สำเร็จ (ไม่มีไฟล์เปลี่ยนแปลง)', ?)`, [syncTargets.join(','), triggerBy]);
            return 'No Changes';
        }

        const now = new Date().toLocaleString('th-TH');
        await git.commit(`Backup Update: ${now}`);
        await git.push('origin', branchName, { '--force': null }); 


        await db.query(`INSERT INTO github_sync_logs (sync_targets, status, created_by) VALUES (?, 'สำเร็จ', ?)`, [syncTargets.join(','), triggerBy]);
        return 'Sync Success';
        
    } catch (error) {
        const errMsg = error.message.substring(0, 150);
        await db.query(`INSERT INTO github_sync_logs (sync_targets, status, created_by) VALUES (?, ?, ?)`, [syncTargets.join(','), `ล้มเหลว: ${errMsg}`, triggerBy]);
        throw error;
    }
};

module.exports = { performBackup, performSourceBackup, performGithubSync };
